import {
  PRODUCT_MAP,
  type GasAppData,
  type GasBridgeStatus,
  type GrainTransaction,
  type ProductCategory,
} from '../types/grain';
import { bnToEnDigits, enToBnDigits, itemNameBnToProduct, parseGasNumber } from './gasBridge';

export interface FortnightlyKhamalRow {
  key: string;
  godownNo: string;
  khamalNo: string;
  product: ProductCategory;
  productNameBn: string;
  khath: string;
  recordBags: number;
  recordMt: number;
  verifiedBags: number;
  verifiedMt: number;
  shortageBags: number;
  shortageMt: number;
  remarks: string;
}

export interface FortnightlyTotals {
  recordBags: number;
  recordMt: number;
  verifiedBags: number;
  verifiedMt: number;
  shortageBags: number;
  shortageMt: number;
}

export interface FortnightlyKhathGroup {
  khath: string;
  rows: FortnightlyKhamalRow[];
  totals: FortnightlyTotals;
}

export interface FortnightlyGrainSection {
  product: ProductCategory;
  productNameBn: string;
  khathGroups: FortnightlyKhathGroup[];
  totals: FortnightlyTotals;
}

export interface FortnightlyBagRow {
  godownNo: string;
  bagTypeLabel: string;
  product: 'bosta_50' | 'bosta_30';
  recordBags: number;
  verifiedBags: number;
}

export interface FortnightlySnapshot {
  endDate: string;
  grainSections: FortnightlyGrainSection[];
  grandTotals: FortnightlyTotals;
  bagRows: FortnightlyBagRow[];
  bagTotals: {
    recordBags: number;
    verifiedBags: number;
  };
}

export function normalizeReportDateToIso(input?: string | null): string {
  if (!input) return '';
  const en = bnToEnDigits(String(input)).trim();
  if (!en) return '';

  // YYYY-MM-DD or ISO datetime
  const isoMatch = en.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
  if (isoMatch) {
    const y = isoMatch[1];
    const m = isoMatch[2].padStart(2, '0');
    const d = isoMatch[3].padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  // DD/MM/YYYY or DD-MM-YYYY
  const dmyMatch = en.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})/);
  if (dmyMatch) {
    const d = dmyMatch[1].padStart(2, '0');
    const m = dmyMatch[2].padStart(2, '0');
    const y = dmyMatch[3];
    return `${y}-${m}-${d}`;
  }

  const parsed = new Date(en);
  if (!Number.isNaN(parsed.getTime())) {
    const y = parsed.getFullYear();
    const m = String(parsed.getMonth() + 1).padStart(2, '0');
    const d = String(parsed.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  return '';
}

export function formatBnDateFromIso(isoDate: string): string {
  const norm = normalizeReportDateToIso(isoDate);
  if (!norm) return enToBnDigits(isoDate);
  const [y, m, d] = norm.split('-');
  return enToBnDigits(`${d}/${m}/${y}`);
}

export function formatBnSerial(num: number): string {
  return enToBnDigits(String(num).padStart(2, '0'));
}

export function formatBnBags(val: number, dashWhenZero = false): string {
  const rounded = Math.round(val);
  if (dashWhenZero && rounded === 0) return '-';
  return enToBnDigits(String(rounded));
}

export function formatBnMt(val: number): string {
  const clean = Math.abs(val) < 0.0005 ? 0 : val;
  return enToBnDigits(clean.toFixed(3));
}

export function formatGodownForReport(rawGodown: string): string {
  const s = String(rawGodown || '').trim();
  if (!s) return '০১';
  // Convert "গুদাম-০১" / "Godown 1" / "1" cleanly to "০১" if purely numeric suffix, otherwise convert digits to Bn
  const match = s.match(/^(?:গুদাম|গোডাউন|godown|g)?[-\s:_]*([0-9০-৯]+)$/i);
  if (match) {
    const digits = bnToEnDigits(match[1]);
    return enToBnDigits(digits.padStart(2, '0'));
  }
  return enToBnDigits(s);
}

export function getFortnightPeriodPhrase(startDateIso: string, endDateIso: string): string {
  const s = normalizeReportDateToIso(startDateIso);
  const e = normalizeReportDateToIso(endDateIso);
  if (!s || !e) return 'পাক্ষিক';
  const [, sm, sd] = s.split('-').map(Number);
  const [, em, ed] = e.split('-').map(Number);
  if (sm === em) {
    if (sd === 1 && ed <= 16) return '১ম পক্ষের';
    if (sd >= 15 && ed >= 25) return '২য় পক্ষের';
  }
  return `${formatBnDateFromIso(s)} হইতে ${formatBnDateFromIso(e)} তারিখের`;
}

export function defaultFortnightDates(todayIso: string): {
  startDate: string;
  endDate: string;
} {
  const norm = normalizeReportDateToIso(todayIso);
  if (!norm) {
    return { startDate: todayIso, endDate: todayIso };
  }
  const [y, m, d] = norm.split('-');
  const day = Number(d);
  const startDay = day <= 15 ? '01' : '16';
  return {
    startDate: `${y}-${m}-${startDay}`,
    endDate: norm,
  };
}

function emptyTotals(): FortnightlyTotals {
  return {
    recordBags: 0,
    recordMt: 0,
    verifiedBags: 0,
    verifiedMt: 0,
    shortageBags: 0,
    shortageMt: 0,
  };
}

function addIntoTotals(target: FortnightlyTotals, row: FortnightlyKhamalRow): void {
  target.recordBags += row.recordBags;
  target.recordMt = Number((target.recordMt + row.recordMt).toFixed(4));
  target.verifiedBags += row.verifiedBags;
  target.verifiedMt = Number((target.verifiedMt + row.verifiedMt).toFixed(4));
  target.shortageBags += row.shortageBags;
  target.shortageMt = Number((target.shortageMt + row.shortageMt).toFixed(4));
}

function buildSectionAndTotals(
  rawRows: FortnightlyKhamalRow[],
  bagRows: FortnightlyBagRow[],
  endDate: string
): FortnightlySnapshot {
  const grainOrder: ProductCategory[] = ['rice', 'wheat', 'paddy'];
  const grainSections: FortnightlyGrainSection[] = [];
  const grandTotals = emptyTotals();

  for (const prod of grainOrder) {
    const prodRows = rawRows.filter((r) => r.product === prod);
    if (prodRows.length === 0) continue;

    // Group rows by খাত (khath), preserving stable order
    const khathMap = new Map<string, FortnightlyKhamalRow[]>();
    prodRows
      .slice()
      .sort((a, b) => {
        const kCmp = a.khath.localeCompare(b.khath, 'bn');
        if (kCmp !== 0) return kCmp;
        const gCmp = a.godownNo.localeCompare(b.godownNo, 'bn');
        if (gCmp !== 0) return gCmp;
        return a.khamalNo.localeCompare(b.khamalNo, 'bn');
      })
      .forEach((row) => {
        const key = row.khath || 'অন্যান্য';
        const list = khathMap.get(key) || [];
        list.push(row);
        khathMap.set(key, list);
      });

    const khathGroups: FortnightlyKhathGroup[] = [];
    const secTotals = emptyTotals();

    for (const [khath, rows] of khathMap.entries()) {
      const kTotals = emptyTotals();
      rows.forEach((r) => {
        addIntoTotals(kTotals, r);
        addIntoTotals(secTotals, r);
        addIntoTotals(grandTotals, r);
      });
      khathGroups.push({
        khath,
        rows,
        totals: kTotals,
      });
    }

    grainSections.push({
      product: prod,
      productNameBn: PRODUCT_MAP[prod].shortBn,
      khathGroups,
      totals: secTotals,
    });
  }

  const sortedBagRows = bagRows
    .slice()
    .sort((a, b) => {
      const gCmp = a.godownNo.localeCompare(b.godownNo, 'bn');
      if (gCmp !== 0) return gCmp;
      if (a.product === b.product) return 0;
      return a.product === 'bosta_50' ? -1 : 1;
    });

  const bagTotals = sortedBagRows.reduce(
    (acc, r) => {
      acc.recordBags += r.recordBags;
      acc.verifiedBags += r.verifiedBags;
      return acc;
    },
    { recordBags: 0, verifiedBags: 0 }
  );

  return {
    endDate,
    grainSections,
    grandTotals,
    bagRows: sortedBagRows,
    bagTotals,
  };
}

export function buildFortnightlySnapshot(params: {
  endDate: string;
  transactions: GrainTransaction[];
  gasData: GasAppData | null;
  gasBridgeStatus: GasBridgeStatus;
  includeZeroBalance?: boolean;
}): FortnightlySnapshot {
  const endDateIso = normalizeReportDateToIso(params.endDate) || params.endDate;
  const includeZero = Boolean(params.includeZeroBalance);

  if (params.gasBridgeStatus === 'connected' && params.gasData) {
    const gas = params.gasData;
    const isDateUpToEnd = (rawDate?: string) => {
      const iso = normalizeReportDateToIso(rawDate);
      if (!iso) return true; // If Apps Script row has blank date, include by default
      return iso <= endDateIso;
    };

    const masterList = gas.masterGrain || [];
    const accMap = new Map<
      string,
      {
        godown: string;
        khamalId: string;
        product: ProductCategory;
        khath: string;
        remarks: string;
        initBags: number;
        initMt: number;
        outBags: number;
        outMt: number;
        discBags: number;
        discMt: number;
      }
    >();

    for (const m of masterList) {
      if (!isDateUpToEnd(m.entryDate)) continue;
      const prod = itemNameBnToProduct(m.item);
      if (PRODUCT_MAP[prod].isBagProduct) continue;
      const key = `${String(m.khamalId)}::${prod}`;
      const cur = accMap.get(key) || {
        godown: String(m.godown || '০১'),
        khamalId: String(m.khamalId),
        product: prod,
        khath: String(m.category || 'সাধারণ মজুদ').trim() || 'সাধারণ মজুদ',
        remarks: String(m.remarks || m.category || '').trim(),
        initBags: 0,
        initMt: 0,
        outBags: 0,
        outMt: 0,
        discBags: 0,
        discMt: 0,
      };
      cur.initBags += Math.round(parseGasNumber(m.initBags));
      cur.initMt = Number((cur.initMt + parseGasNumber(m.initWeight)).toFixed(4));
      accMap.set(key, cur);
    }

    // Fallback if grainData contains rows not present in masterGrain
    for (const g of gas.grainData || []) {
      const prod = itemNameBnToProduct(g.item);
      if (PRODUCT_MAP[prod].isBagProduct) continue;
      const key = `${String(g.khamalId)}::${prod}`;
      if (!accMap.has(key) && masterList.length === 0) {
        accMap.set(key, {
          godown: String(g.godown || '০১'),
          khamalId: String(g.khamalId),
          product: prod,
          khath: String(g.category || 'সাধারণ মজুদ').trim() || 'সাধারণ মজুদ',
          remarks: String(g.remarks || g.category || '').trim(),
          initBags: Math.round(parseGasNumber(g.recordBags)) + Math.round(parseGasNumber(g.discrepancyBags)),
          initMt: Number(
            (parseGasNumber(g.recordWeight) + parseGasNumber(g.discrepancyWeight)).toFixed(4)
          ),
          outBags: 0,
          outMt: 0,
          discBags: Math.round(parseGasNumber(g.discrepancyBags)),
          discMt: Number(parseGasNumber(g.discrepancyWeight).toFixed(4)),
        });
      }
    }

    const findAccByKhamalId = (khamalId: string) => {
      for (const item of accMap.values()) {
        if (item.khamalId === String(khamalId)) return item;
      }
      return undefined;
    };

    for (const iss of gas.issueList || []) {
      if (!isDateUpToEnd(iss.date)) continue;
      const target = findAccByKhamalId(iss.khamalId);
      if (!target) continue;
      target.outBags += Math.round(parseGasNumber(iss.bags));
      target.outMt = Number((target.outMt + parseGasNumber(iss.weight)).toFixed(4));
    }

    for (const disp of gas.dispatchList || []) {
      if (!isDateUpToEnd(disp.date)) continue;
      const target = findAccByKhamalId(disp.khamalId);
      if (!target) continue;
      target.outBags += Math.round(parseGasNumber(disp.bags));
      target.outMt = Number((target.outMt + parseGasNumber(disp.weight)).toFixed(4));
    }

    for (const disc of gas.discList || []) {
      if (!isDateUpToEnd(disc.date)) continue;
      const target = findAccByKhamalId(disc.khamalId);
      if (!target) continue;
      target.discBags += Math.round(parseGasNumber(disc.bags));
      target.discMt = Number((target.discMt + parseGasNumber(disc.weight)).toFixed(4));
      if (disc.remarks && !target.remarks) {
        target.remarks = String(disc.remarks);
      }
    }

    const grainRows: FortnightlyKhamalRow[] = [];
    for (const [key, item] of accMap.entries()) {
      const recordBags = Math.max(0, item.initBags - item.outBags);
      const recordMt = Math.max(0, Number((item.initMt - item.outMt).toFixed(4)));
      const verifiedBags = Math.max(0, recordBags - item.discBags);
      const verifiedMt = Math.max(0, Number((recordMt - item.discMt).toFixed(4)));
      const shortageBags = Math.max(0, item.discBags);
      const shortageMt = Math.max(0, Number(item.discMt.toFixed(4)));

      if (
        !includeZero &&
        recordBags === 0 &&
        recordMt === 0 &&
        verifiedBags === 0 &&
        verifiedMt === 0 &&
        shortageBags === 0 &&
        shortageMt === 0
      ) {
        continue;
      }

      grainRows.push({
        key,
        godownNo: formatGodownForReport(item.godown),
        khamalNo: enToBnDigits(item.khamalId),
        product: item.product,
        productNameBn: PRODUCT_MAP[item.product].shortBn,
        khath: item.khath,
        recordBags,
        recordMt,
        verifiedBags,
        verifiedMt,
        shortageBags,
        shortageMt,
        remarks: item.remarks || item.khath,
      });
    }

    // Empty Bags snapshot up to endDate
    const bagMap = new Map<string, FortnightlyBagRow>();
    const masterBags = gas.masterEmptyBags || [];
    if (masterBags.length > 0) {
      for (const mb of masterBags) {
        if (!isDateUpToEnd(mb.entryDate)) continue;
        const prod = itemNameBnToProduct(mb.bagType) === 'bosta_30' ? 'bosta_30' : 'bosta_50';
        const godown = formatGodownForReport(mb.godown);
        const key = `${godown}::${prod}`;
        const cur = bagMap.get(key) || {
          godownNo: godown,
          bagTypeLabel: prod === 'bosta_30' ? '৩০ কেজির বস্তা' : '৫০ কেজির বস্তা',
          product: prod,
          recordBags: 0,
          verifiedBags: 0,
        };
        const qty = Math.round(parseGasNumber(mb.initialBags));
        cur.recordBags += qty;
        cur.verifiedBags += qty;
        bagMap.set(key, cur);
      }
      for (const bi of gas.bagIssueList || []) {
        if (!isDateUpToEnd(bi.issueDate)) continue;
        const prod = itemNameBnToProduct(bi.bagType) === 'bosta_30' ? 'bosta_30' : 'bosta_50';
        const godown = formatGodownForReport(bi.godown);
        const key = `${godown}::${prod}`;
        const cur = bagMap.get(key);
        if (cur) {
          const qty = Math.round(parseGasNumber(bi.bags));
          cur.recordBags = Math.max(0, cur.recordBags - qty);
          cur.verifiedBags = Math.max(0, cur.verifiedBags - qty);
        }
      }
    } else {
      for (const eb of gas.emptyBagData || []) {
        const prod = itemNameBnToProduct(eb.bagType) === 'bosta_30' ? 'bosta_30' : 'bosta_50';
        const godown = formatGodownForReport(eb.godown);
        const key = `${godown}::${prod}`;
        const rec = Math.round(parseGasNumber(eb.recordBags));
        const ver =
          eb.actualBags !== undefined ? Math.round(parseGasNumber(eb.actualBags)) : rec;
        const cur = bagMap.get(key) || {
          godownNo: godown,
          bagTypeLabel: prod === 'bosta_30' ? '৩০ কেজির বস্তা' : '৫০ কেজির বস্তা',
          product: prod,
          recordBags: 0,
          verifiedBags: 0,
        };
        cur.recordBags += rec;
        cur.verifiedBags += ver;
        bagMap.set(key, cur);
      }
    }

    return buildSectionAndTotals(grainRows, Array.from(bagMap.values()), endDateIso);
  }

  // Local Mode: aggregate transactions where tx.date <= endDateIso
  const grainAcc = new Map<
    string,
    {
      godownNo: string;
      khamalNo: string;
      product: ProductCategory;
      khath: string;
      remarks: string;
      receiptBags: number;
      receiptMt: number;
      distBags: number;
      distMt: number;
      shortBags: number;
      shortMt: number;
    }
  >();

  const bagAcc = new Map<string, FortnightlyBagRow>();

  const sortedTx = params.transactions
    .filter((tx) => {
      const txDate = normalizeReportDateToIso(tx.date);
      if (!txDate) return true;
      return txDate <= endDateIso;
    })
    .slice()
    .sort((a, b) => a.date.localeCompare(b.date) || a.createdAt.localeCompare(b.createdAt));

  for (const tx of sortedTx) {
    const meta = PRODUCT_MAP[tx.product];
    if (meta.isBagProduct) {
      const prod: 'bosta_50' | 'bosta_30' = tx.product === 'bosta_30' ? 'bosta_30' : 'bosta_50';
      const godown = formatGodownForReport(tx.godownNo);
      const bKey = `${godown}::${prod}`;
      const cur = bagAcc.get(bKey) || {
        godownNo: godown,
        bagTypeLabel: prod === 'bosta_30' ? '৩০ কেজির বস্তা' : '৫০ কেজির বস্তা',
        product: prod,
        recordBags: 0,
        verifiedBags: 0,
      };
      if (tx.type === 'receipt') {
        cur.recordBags += tx.bags;
        cur.verifiedBags += tx.bags;
      } else if (tx.type === 'distribution') {
        cur.recordBags = Math.max(0, cur.recordBags - tx.bags);
        cur.verifiedBags = Math.max(0, cur.verifiedBags - tx.bags);
      } else if (tx.type === 'shortage') {
        cur.verifiedBags = Math.max(0, cur.verifiedBags - tx.bags);
      }
      bagAcc.set(bKey, cur);
      continue;
    }

    const key = `${tx.godownNo.trim()}::${tx.khamalNo.trim()}::${tx.product}`;
    const cur = grainAcc.get(key) || {
      godownNo: tx.godownNo.trim(),
      khamalNo: tx.khamalNo.trim(),
      product: tx.product,
      khath: '',
      remarks: '',
      receiptBags: 0,
      receiptMt: 0,
      distBags: 0,
      distMt: 0,
      shortBags: 0,
      shortMt: 0,
    };

    if (tx.type === 'receipt') {
      cur.receiptBags += tx.bags;
      cur.receiptMt = Number((cur.receiptMt + tx.metricTons).toFixed(4));
      if (!cur.khath && tx.channel.trim()) cur.khath = tx.channel.trim();
      if (!cur.remarks && tx.note.trim()) cur.remarks = tx.note.trim();
    } else if (tx.type === 'distribution') {
      cur.distBags += tx.bags;
      cur.distMt = Number((cur.distMt + tx.metricTons).toFixed(4));
    } else if (tx.type === 'shortage') {
      cur.shortBags += tx.bags;
      cur.shortMt = Number((cur.shortMt + tx.metricTons).toFixed(4));
      if (tx.note.trim()) cur.remarks = tx.note.trim();
    }

    grainAcc.set(key, cur);
  }

  const grainRows: FortnightlyKhamalRow[] = [];
  for (const [key, item] of grainAcc.entries()) {
    const recordBags = Math.max(0, item.receiptBags - item.distBags);
    const recordMt = Math.max(0, Number((item.receiptMt - item.distMt).toFixed(4)));
    const verifiedBags = Math.max(0, item.receiptBags - item.distBags - item.shortBags);
    const verifiedMt = Math.max(
      0,
      Number((item.receiptMt - item.distMt - item.shortMt).toFixed(4))
    );
    const shortageBags = Math.max(0, item.shortBags);
    const shortageMt = Math.max(0, Number(item.shortMt.toFixed(4)));

    if (
      !includeZero &&
      recordBags === 0 &&
      recordMt === 0 &&
      verifiedBags === 0 &&
      verifiedMt === 0 &&
      shortageBags === 0 &&
      shortageMt === 0
    ) {
      continue;
    }

    grainRows.push({
      key,
      godownNo: formatGodownForReport(item.godownNo),
      khamalNo: enToBnDigits(item.khamalNo),
      product: item.product,
      productNameBn: PRODUCT_MAP[item.product].shortBn,
      khath: item.khath || 'সাধারণ মজুদ',
      recordBags,
      recordMt,
      verifiedBags,
      verifiedMt,
      shortageBags,
      shortageMt,
      remarks: item.remarks || item.khath || '-',
    });
  }

  const finalBagRows = Array.from(bagAcc.values()).filter(
    (b) => includeZero || b.recordBags > 0 || b.verifiedBags > 0
  );

  return buildSectionAndTotals(grainRows, finalBagRows, endDateIso);
}
