import type {
  DriveSpreadsheetFile,
  GasAppData,
  GasAvailableDO,
  GasBagIssue,
  GasDiscrepancy,
  GasDispatchRecord,
  GasEmptyBagRow,
  GasEmptyBagSummaryItem,
  GasFiscalYear,
  GasGrainRow,
  GasIssueRecord,
  GasItemSummary,
  GasMasterEmptyBag,
  GasMasterGrain,
  GoogleSheetsConfig,
} from '../types/grain';
import { bnToEnDigits, enToBnDigits, parseGasNumber } from './gasBridge';

const SHEETS_API_BASE = 'https://sheets.googleapis.com/v4/spreadsheets';
const DRIVE_API_BASE = 'https://www.googleapis.com/drive/v3/files';

export const SHEET_DEFS = {
  settings: { name: 'Settings', headers: ['Key', 'Value'] },
  master: {
    name: 'Khamal_Master',
    headers: [
      'Khamal_ID',
      'Godown_No',
      'Category',
      'Item_Name',
      'Initial_Bags',
      'Initial_Weight',
      'Remarks',
      'Entry_Date',
      'Source_Type',
      'Unique_ID',
    ],
  },
  trans: {
    name: 'Transactions',
    headers: [
      'ID',
      'Date',
      'Khamal_ID',
      'Type',
      'Bags',
      'Weight_MT',
      'Reference',
      'Khath',
      'DO_No',
      'Disc_Bags',
      'Disc_Weight',
      'Party',
    ],
  },
  emptyBag: {
    name: 'Empty_Bags',
    headers: ['ID', 'Godown_No', 'Bag_Type', 'Initial_Bags', 'Khamal_No', 'Entry_Date'],
  },
  bagTrans: {
    name: 'Bag_Transactions',
    headers: ['ID', 'Godown_No', 'Bag_Type', 'Issued_Bags', 'Khamal_No', 'Issue_Date'],
  },
  ext: {
    name: 'External_DOs',
    headers: ['DO_No', 'Khath', 'Total_Bags', 'Total_Weight'],
  },
} as const;

const ITEM_NAMES = ['চাল', 'ধান', 'গম'];
const DEFAULT_CATS = ['ইনভয়েসে প্রাপ্তি', 'সংগ্রহ বাবদ প্রাপ্তি', 'খলিত বাবদ প্রাপ্তি'];

export class GoogleAuthExpiredError extends Error {
  constructor(message = 'Google সেশনের মেয়াদ শেষ হয়েছে। অনুগ্রহ করে পুনরায় Google Sign-In করুন।') {
    super(message);
    this.name = 'GoogleAuthExpiredError';
  }
}

export function extractSpreadsheetId(rawInput: string): string {
  const trimmed = String(rawInput || '').trim();
  if (!trimmed) return '';
  const match = trimmed.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
  if (match && match[1]) return match[1];
  return trimmed;
}

async function googleApiFetch<T>(
  url: string,
  accessToken: string,
  init: RequestInit = {}
): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: {
      Authorization: `Bearer ${accessToken}`,
      Accept: 'application/json',
      ...(init.body ? { 'Content-Type': 'application/json' } : {}),
      ...(init.headers || {}),
    },
  });

  if (res.status === 401) {
    throw new GoogleAuthExpiredError();
  }

  const text = await res.text();
  let parsed: Record<string, unknown> = {};
  try {
    parsed = text ? (JSON.parse(text) as Record<string, unknown>) : {};
  } catch {
    throw new Error(`Google API HTTP ${res.status}`);
  }

  if (!res.ok) {
    const errObj = parsed.error as { message?: string } | undefined;
    throw new Error(errObj?.message || `Google API ত্রুটি (HTTP ${res.status})`);
  }

  return parsed as T;
}

export async function listUserSpreadsheets(
  accessToken: string
): Promise<DriveSpreadsheetFile[]> {
  const q = encodeURIComponent(
    "mimeType='application/vnd.google-apps.spreadsheet' and trashed=false"
  );
  const url = `${DRIVE_API_BASE}?q=${q}&fields=files(id,name,modifiedTime)&orderBy=modifiedTime%20desc&pageSize=30`;
  const data = await googleApiFetch<{ files?: DriveSpreadsheetFile[] }>(url, accessToken);
  return data.files || [];
}

export interface SpreadsheetMetadata {
  spreadsheetId: string;
  title: string;
  sheetTitles: string[];
  sheetIdMap: Record<string, number>;
}

export async function getSpreadsheetMetadata(
  accessToken: string,
  rawSpreadsheetId: string
): Promise<SpreadsheetMetadata> {
  const spreadsheetId = extractSpreadsheetId(rawSpreadsheetId);
  if (!spreadsheetId) {
    throw new Error('Spreadsheet ID খালি রয়েছে।');
  }
  const url = `${SHEETS_API_BASE}/${encodeURIComponent(
    spreadsheetId
  )}?fields=properties.title,sheets(properties(sheetId,title))`;
  const data = await googleApiFetch<{
    properties?: { title?: string };
    sheets?: Array<{ properties?: { sheetId?: number; title?: string } }>;
  }>(url, accessToken);

  const sheetTitles: string[] = [];
  const sheetIdMap: Record<string, number> = {};
  for (const s of data.sheets || []) {
    const title = s.properties?.title;
    const sheetId = s.properties?.sheetId;
    if (title) {
      sheetTitles.push(title);
      if (typeof sheetId === 'number') {
        sheetIdMap[title] = sheetId;
      }
    }
  }

  return {
    spreadsheetId,
    title: data.properties?.title || spreadsheetId,
    sheetTitles,
    sheetIdMap,
  };
}

export async function autoDetectUserSpreadsheets(
  accessToken: string,
  files: DriveSpreadsheetFile[]
): Promise<{
  main?: { file: DriveSpreadsheetFile; meta: SpreadsheetMetadata };
  externalDo?: { file: DriveSpreadsheetFile; meta: SpreadsheetMetadata };
}> {
  let main: { file: DriveSpreadsheetFile; meta: SpreadsheetMetadata } | undefined;
  let externalDo: { file: DriveSpreadsheetFile; meta: SpreadsheetMetadata } | undefined;

  const sample = files.slice(0, 12);
  for (let i = 0; i < sample.length; i += 4) {
    const chunk = sample.slice(i, i + 4);
    const metas = await Promise.all(
      chunk.map(async (file) => {
        try {
          const meta = await getSpreadsheetMetadata(accessToken, file.id);
          return { file, meta };
        } catch {
          return null;
        }
      })
    );
    for (const item of metas) {
      if (!item) continue;
      const titles = new Set(item.meta.sheetTitles);
      if (!main && (titles.has('Khamal_Master') || titles.has('Transactions'))) {
        main = item;
      }
      if (!externalDo && titles.has('DO_Issue')) {
        externalDo = item;
      }
    }
    if (main && externalDo) break;
  }

  return { main, externalDo };
}

function getDefaultFY(): GasFiscalYear {
  const now = new Date();
  const y = now.getFullYear();
  const m = now.getMonth() + 1;
  const s = m >= 7 ? y : y - 1;
  return {
    name: `${enToBnDigits(s)}-${enToBnDigits(String((s + 1) % 100).padStart(2, '0'))}`,
    start: `${s}-07-01`,
    end: `${s + 1}-06-30`,
  };
}

function parseSheetDateStr(val: unknown): string {
  if (val === null || val === undefined || val === '') return '';
  if (typeof val === 'number' && val > 20000 && val < 80000) {
    // Google Sheets serial date (days since 1899-12-30)
    const ms = Math.round((val - 25569) * 86400 * 1000);
    const d = new Date(ms);
    if (!Number.isNaN(d.getTime())) {
      return d.toISOString().slice(0, 10);
    }
  }
  const s = bnToEnDigits(val).trim();
  if (!s) return '';
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) {
    return s.slice(0, 10);
  }
  const slashMatch = s.match(/^(\d{1,2})[/-](\d{1,2})[/-](\d{4})/);
  if (slashMatch) {
    const a = Number(slashMatch[1]);
    const b = Number(slashMatch[2]);
    const yr = slashMatch[3];
    // Handle dd/mm/yyyy vs mm/dd/yyyy heuristically
    const day = a > 12 ? a : b > 12 ? b : a;
    const mon = a > 12 ? b : b > 12 ? a : b;
    return `${yr}-${String(mon).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  }
  const parsed = new Date(s);
  if (!Number.isNaN(parsed.getTime())) {
    return parsed.toISOString().slice(0, 10);
  }
  return s;
}

function parseDateObj(val: unknown): Date | null {
  if (val === null || val === undefined || val === '') return null;
  if (typeof val === 'number' && val > 20000 && val < 80000) {
    const ms = Math.round((val - 25569) * 86400 * 1000);
    const d = new Date(ms);
    return Number.isNaN(d.getTime()) ? null : d;
  }
  const s = bnToEnDigits(val).trim();
  if (!s) return null;
  const d = new Date(s);
  return Number.isNaN(d.getTime()) ? null : d;
}

function a1SheetRef(sheetName: string, range: string): string {
  const escaped = sheetName.replace(/'/g, "''");
  return `'${escaped}'!${range}`;
}

async function batchGetRanges(
  accessToken: string,
  spreadsheetId: string,
  ranges: string[]
): Promise<Map<string, unknown[][]>> {
  const out = new Map<string, unknown[][]>();
  if (ranges.length === 0) return out;

  const params = new URLSearchParams();
  for (const r of ranges) {
    params.append('ranges', r);
  }
  params.set('majorDimension', 'ROWS');
  params.set('valueRenderOption', 'UNFORMATTED_VALUE');
  params.set('dateTimeRenderOption', 'FORMATTED_STRING');

  const url = `${SHEETS_API_BASE}/${encodeURIComponent(
    spreadsheetId
  )}/values:batchGet?${params.toString()}`;
  const resp = await googleApiFetch<{
    valueRanges?: Array<{ range?: string; values?: unknown[][] }>;
  }>(url, accessToken);

  (resp.valueRanges || []).forEach((vr, idx) => {
    const reqRange = ranges[idx] || vr.range || '';
    const sheetPart = reqRange.split('!')[0].replace(/^'|'$/g, '').replace(/''/g, "'");
    out.set(sheetPart, vr.values || []);
  });

  return out;
}

export async function fetchGasAppDataFromSheets(
  accessToken: string,
  config: GoogleSheetsConfig,
  fyName?: string | null
): Promise<{ data: GasAppData; meta: SpreadsheetMetadata }> {
  const mainId = extractSpreadsheetId(config.mainSpreadsheetId);
  if (!mainId) {
    throw new Error('মেইন Google Spreadsheet ID দেওয়া হয়নি।');
  }

  const meta = await getSpreadsheetMetadata(accessToken, mainId);
  const existingSet = new Set(meta.sheetTitles);

  const wantedTabs = [
    SHEETS_API_BASE ? SHEET_DEFS.settings.name : 'Settings',
    SHEET_DEFS.master.name,
    SHEET_DEFS.trans.name,
    SHEET_DEFS.emptyBag.name,
    SHEET_DEFS.bagTrans.name,
    SHEET_DEFS.ext.name,
  ].filter((t) => existingSet.has(t));

  const rangeMap = await batchGetRanges(
    accessToken,
    mainId,
    wantedTabs.map((t) => a1SheetRef(t, 'A1:Z'))
  );

  const settingsRows = rangeMap.get(SHEET_DEFS.settings.name) || [];
  const masterData = rangeMap.get(SHEET_DEFS.master.name) || [];
  const transData = rangeMap.get(SHEET_DEFS.trans.name) || [];
  const emptyBagDataRows = rangeMap.get(SHEET_DEFS.emptyBag.name) || [];
  const bagTransDataRows = rangeMap.get(SHEET_DEFS.bagTrans.name) || [];
  const extData = rangeMap.get(SHEET_DEFS.ext.name) || [];

  // 1. Parse Settings
  const settingsMap: Record<string, string> = {};
  for (let i = 1; i < settingsRows.length; i++) {
    const k = String(settingsRows[i]?.[0] || '').trim();
    if (k) settingsMap[k] = String(settingsRows[i]?.[1] ?? '');
  }

  let cats: Record<string, string[]> = {};
  try {
    if (settingsMap.categories) cats = JSON.parse(settingsMap.categories);
  } catch {
    cats = {};
  }
  for (const it of ITEM_NAMES) {
    if (!Array.isArray(cats[it]) || cats[it].length === 0) {
      cats[it] = [...DEFAULT_CATS];
    }
  }

  let fys: GasFiscalYear[] = [];
  try {
    if (settingsMap.fiscalYears) fys = JSON.parse(settingsMap.fiscalYears);
  } catch {
    fys = [];
  }
  if (!Array.isArray(fys) || fys.length === 0) {
    fys = [getDefaultFY()];
  }

  let activeFY = settingsMap.activeFY || '';
  if (!fys.some((f) => f.name === activeFY)) {
    const todayStr = new Date().toISOString().slice(0, 10);
    const cur = fys.find((f) => todayStr >= f.start && todayStr <= f.end);
    activeFY = (cur || fys[fys.length - 1]).name;
  }

  const settings = {
    lsdName: settingsMap.lsdName || 'শিকারপুর',
    upazila: settingsMap.upazila || 'উজিরপুর',
    district: settingsMap.district || 'বরিশাল',
    officer: settingsMap.officer || 'মোঃ মেহেদী হাসান',
    categories: cats,
    fiscalYears: fys,
    activeFY,
  };

  // Resolve active FY filter
  let fy: GasFiscalYear | null = null;
  if (fyName !== 'ALL') {
    fy =
      fys.find((f) => f.name === fyName) ||
      fys.find((f) => f.name === settings.activeFY) ||
      null;
  }
  const fStart = fy?.start || '';
  const fEnd = fy?.end || '9999-12-31';
  const isBefore = (d: string) => Boolean(fy && d && d < fStart);
  const upTo = (d: string) => !d || d <= fEnd;

  // 2. External DOs (optional second spreadsheet + External_DOs tab)
  const externalDoList: Array<{
    doNo: string;
    khath: string;
    totalBags: number;
    totalMT: number;
    recipient: string;
    union: string;
    grain: string;
    date?: string;
  }> = [];

  const extSpreadsheetId = extractSpreadsheetId(config.externalDoSpreadsheetId);
  const extSheetName = config.externalDoSheetName?.trim() || 'DO_Issue';
  if (extSpreadsheetId) {
    try {
      const extMap = await batchGetRanges(accessToken, extSpreadsheetId, [
        a1SheetRef(extSheetName, 'A1:Z'),
      ]);
      const rows = extMap.get(extSheetName) || [];
      if (rows.length > 1) {
        const head = rows[0].map((h) => String(h || '').trim());
        const ix = (n: string) => head.indexOf(n);
        const iDo = ix('doNo');
        const iCat = ix('category');
        const iQty = ix('quantity');
        const iRec = ix('recipientName');
        const iUni = ix('unionName');
        const iGr = ix('grain');
        const iDt = ix('createdAt') >= 0 ? ix('createdAt') : ix('issueDate');
        const cutoff = parseDateObj(config.cutoffDate || '2026-11-01');
        const bagKg = Number(config.bagKg) > 0 ? Number(config.bagKg) : 50;
        const seenDo = new Set<string>();

        if (iDo >= 0 && iQty >= 0) {
          for (let i = 1; i < rows.length; i++) {
            const r = rows[i] || [];
            const doNo = String(r[iDo] ?? '').trim();
            if (!doNo || seenDo.has(doNo)) continue;
            if (iDt >= 0 && cutoff) {
              const d = parseDateObj(r[iDt]);
              if (!d || d < cutoff) continue;
            }
            const mt = parseGasNumber(r[iQty]);
            seenDo.add(doNo);
            externalDoList.push({
              doNo,
              khath: iCat >= 0 ? String(r[iCat] ?? '') : '',
              totalMT: mt,
              totalBags: Math.round((mt * 1000) / bagKg),
              recipient: iRec >= 0 ? String(r[iRec] ?? '') : '',
              union: iUni >= 0 ? String(r[iUni] ?? '') : '',
              grain: iGr >= 0 ? String(r[iGr] ?? '') : '',
              date: iDt >= 0 ? parseSheetDateStr(r[iDt]) : undefined,
            });
          }
        }
      }
    } catch {
      // External DO sheet is optional; don't block main stock load if inaccessible
    }
  }

  for (let i = 1; i < extData.length; i++) {
    const r = extData[i] || [];
    const doNo = String(r[0] ?? '').trim();
    if (!doNo) continue;
    externalDoList.push({
      doNo,
      khath: String(r[1] ?? ''),
      totalBags: Math.round(parseGasNumber(r[2])),
      totalMT: parseGasNumber(r[3]),
      recipient: '',
      union: '',
      grain: '',
    });
  }

  const skipDos = new Set(
    (config.excludeDoNos && config.excludeDoNos.length > 0
      ? config.excludeDoNos
      : ['240319', '240320']
    ).map((n) => String(n).trim())
  );
  const allDOs = externalDoList.filter((d) => !skipDos.has(d.doNo));

  // 3. Process Transactions (Exact parity with Code.gs getAppData)
  const issuedBags: Record<string, number> = {};
  const issuedWeight: Record<string, number> = {};
  const carryBags: Record<string, number> = {};
  const carryWeight: Record<string, number> = {};
  const discrepancies: Record<string, { bags: number; weight: number }> = {};
  const issuedDOWeight: Record<string, number> = {};
  let totalGrainIssuedBags = 0;
  let totalGrainIssuedWeight = 0;
  let totalDiscrepancyBags = 0;
  let totalDiscrepancyWeight = 0;

  const discList: GasDiscrepancy[] = [];
  const issueList: GasIssueRecord[] = [];
  const dispatchList: GasDispatchRecord[] = [];

  for (let i = 1; i < transData.length; i++) {
    const row = transData[i] || [];
    const rowId = String(row[0] ?? '').trim();
    const dt = parseSheetDateStr(row[1]);
    const kId = String(row[2] ?? '').trim();
    const type = String(row[3] ?? '').trim();
    const bags = parseGasNumber(row[4]);
    const weight = parseGasNumber(row[5]);
    const ref = String(row[6] ?? '');
    const khath = String(row[7] ?? '');
    const dNo = String(row[8] ?? '').trim();
    const discBags = parseGasNumber(row[9]);
    const discWeight = parseGasNumber(row[10]);
    const party = String(row[11] ?? '');

    if (type === 'Issue' && dNo) {
      issuedDOWeight[dNo] = (issuedDOWeight[dNo] || 0) + weight;
    }

    if (!upTo(dt)) continue;

    if (type === 'Discrepancy') {
      if (!discrepancies[kId]) discrepancies[kId] = { bags: 0, weight: 0 };
      discrepancies[kId].bags += discBags;
      discrepancies[kId].weight += discWeight;
      totalDiscrepancyBags += discBags;
      totalDiscrepancyWeight += discWeight;
      discList.push({
        rowIdx: i + 1,
        id: rowId,
        date: dt,
        khamalId: kId,
        bags: discBags,
        weight: Number(discWeight.toFixed(3)),
        remarks: ref,
      });
      continue;
    }

    if (type === 'Issue' || type === 'Invoice' || type === 'Mill') {
      if (isBefore(dt)) {
        if (kId) {
          carryBags[kId] = (carryBags[kId] || 0) + bags;
          carryWeight[kId] = (carryWeight[kId] || 0) + weight;
        }
        continue;
      }
      if (kId) {
        issuedBags[kId] = (issuedBags[kId] || 0) + bags;
        issuedWeight[kId] = (issuedWeight[kId] || 0) + weight;
      }
      totalGrainIssuedBags += bags;
      totalGrainIssuedWeight += weight;

      if (type !== 'Issue') {
        dispatchList.push({
          rowIdx: i + 1,
          id: rowId,
          type,
          date: dt,
          khamalId: kId,
          docNo: dNo,
          party,
          bags,
          weight: Number(weight.toFixed(3)),
          reference: ref,
        });
        continue;
      }

      issueList.push({
        rowIdx: i + 1,
        id: rowId,
        date: dt,
        khamalId: kId,
        doNo: dNo,
        khath,
        bags,
        weight: Number(weight.toFixed(3)),
        reference: ref,
      });
    }
  }

  // 4. Process Khamal_Master
  const masterList: GasMasterGrain[] = [];
  const reportGrainList: GasGrainRow[] = [];
  const khathSummary: Record<string, { deliveredBags: number; deliveredWeight: number }> = {};
  const itemSummary: Record<string, GasItemSummary> = {};
  let totalInitialBags = 0;
  let totalInitialWeight = 0;

  for (let i = 1; i < masterData.length; i++) {
    const row = masterData[i] || [];
    const kId = String(row[0] ?? '').trim();
    if (!kId) continue;

    const entryDate = parseSheetDateStr(row[7]);
    if (entryDate && entryDate > fEnd) continue;

    const godown = String(row[1] ?? '');
    const category = String(row[2] ?? '');
    const item = String(row[3] ?? '');
    const initBags = parseGasNumber(row[4]);
    const initWeight = parseGasNumber(row[5]);
    const remarks = String(row[6] ?? '');
    const uniqueId = String(row[9] ?? '-');

    const openBags = initBags - (carryBags[kId] || 0);
    const openWeight = initWeight - (carryWeight[kId] || 0);

    totalInitialBags += openBags;
    totalInitialWeight += openWeight;

    const totIssBags = issuedBags[kId] || 0;
    const totIssWeight = issuedWeight[kId] || 0;
    const disc = discrepancies[kId] || { bags: 0, weight: 0 };
    const currentBags = openBags - totIssBags - disc.bags;
    const currentWeight = openWeight - totIssWeight - disc.weight;

    if (!khathSummary[category]) {
      khathSummary[category] = { deliveredBags: 0, deliveredWeight: 0 };
    }
    khathSummary[category].deliveredBags += totIssBags;
    khathSummary[category].deliveredWeight += totIssWeight;

    if (!itemSummary[item]) {
      itemSummary[item] = {
        initBags: 0,
        initWeight: 0,
        issuedBags: 0,
        issuedWeight: 0,
        discBags: 0,
        discWeight: 0,
      };
    }
    itemSummary[item].initBags += openBags;
    itemSummary[item].initWeight += openWeight;
    itemSummary[item].issuedBags += totIssBags;
    itemSummary[item].issuedWeight += totIssWeight;
    itemSummary[item].discBags += disc.bags;
    itemSummary[item].discWeight += disc.weight;

    masterList.push({
      rowIdx: i + 1,
      khamalId: kId,
      uniqueId,
      godown,
      category,
      item,
      initBags,
      initWeight: Number(initWeight.toFixed(3)),
      currentWeight: Number(currentWeight.toFixed(3)),
      entryDate,
      remarks,
    });

    if (currentBags > 0 || currentWeight > 0.0005) {
      reportGrainList.push({
        godown,
        khamalId: kId,
        item,
        category,
        recordBags: Math.max(0, Math.round(currentBags)),
        recordWeight: Math.max(0, Number(currentWeight.toFixed(3))),
        discrepancyBags: Math.round(disc.bags),
        discrepancyWeight: Number(disc.weight.toFixed(3)),
        remarks,
      });
    }
  }

  // Recompute khathSummary across FY Issues (matching Code.gs dashboard breakdown by distribution khath)
  for (const iss of issueList) {
    const k = iss.khath || 'অন্যান্য';
    if (!khathSummary[k]) {
      khathSummary[k] = { deliveredBags: 0, deliveredWeight: 0 };
    }
    khathSummary[k].deliveredBags += iss.bags;
    khathSummary[k].deliveredWeight += iss.weight;
  }

  // 5. Empty Bags & Bag Transactions
  const masterEmptyBags: GasMasterEmptyBag[] = [];
  const bagIssueList: GasBagIssue[] = [];
  const emptyAgg = new Map<
    string,
    { godown: string; bagType: string; initBags: number; issuedBags: number }
  >();
  const emptySummaryMap = new Map<string, GasEmptyBagSummaryItem>();

  for (let i = 1; i < emptyBagDataRows.length; i++) {
    const r = emptyBagDataRows[i] || [];
    const id = String(r[0] ?? '').trim();
    if (!id) continue;
    const godown = String(r[1] ?? '');
    const bagType = String(r[2] ?? '');
    const initB = parseGasNumber(r[3]);
    const khamalNo = String(r[4] ?? '');
    const entryDate = parseSheetDateStr(r[5]);
    if (entryDate && entryDate > fEnd) continue;

    masterEmptyBags.push({
      rowIdx: i + 1,
      id,
      godown,
      bagType,
      initialBags: initB,
      khamalNo,
      entryDate,
    });

    const key = `${godown}::${bagType}`;
    const cur = emptyAgg.get(key) || { godown, bagType, initBags: 0, issuedBags: 0 };
    cur.initBags += initB;
    emptyAgg.set(key, cur);

    const sumCur = emptySummaryMap.get(bagType) || {
      bagType,
      initBags: 0,
      issuedBags: 0,
      balanceBags: 0,
      recordBags: 0,
    };
    sumCur.initBags = (sumCur.initBags || 0) + initB;
    emptySummaryMap.set(bagType, sumCur);
  }

  for (let i = 1; i < bagTransDataRows.length; i++) {
    const r = bagTransDataRows[i] || [];
    const id = String(r[0] ?? '').trim();
    if (!id) continue;
    const godown = String(r[1] ?? '');
    const bagType = String(r[2] ?? '');
    const bags = parseGasNumber(r[3]);
    const khamalNo = String(r[4] ?? '');
    const issueDate = parseSheetDateStr(r[5]);
    if (!upTo(issueDate)) continue;

    bagIssueList.push({
      rowIdx: i + 1,
      id,
      godown,
      bagType,
      bags,
      khamalNo,
      issueDate,
    });

    const key = `${godown}::${bagType}`;
    const cur = emptyAgg.get(key) || { godown, bagType, initBags: 0, issuedBags: 0 };
    cur.issuedBags += bags;
    emptyAgg.set(key, cur);

    const sumCur = emptySummaryMap.get(bagType) || {
      bagType,
      initBags: 0,
      issuedBags: 0,
      balanceBags: 0,
      recordBags: 0,
    };
    sumCur.issuedBags = (sumCur.issuedBags || 0) + bags;
    emptySummaryMap.set(bagType, sumCur);
  }

  const emptyBagData: GasEmptyBagRow[] = Array.from(emptyAgg.values()).map((e) => ({
    godown: e.godown,
    bagType: e.bagType,
    recordBags: Math.max(0, Math.round(e.initBags - e.issuedBags)),
  }));

  const emptyBagSummary: GasEmptyBagSummaryItem[] = Array.from(emptySummaryMap.values()).map(
    (s) => {
      const bal = Math.max(0, Math.round((s.initBags || 0) - (s.issuedBags || 0)));
      return { ...s, balanceBags: bal, recordBags: bal };
    }
  );

  // 6. Available DOs
  const availableDOs: GasAvailableDO[] = allDOs
    .map((d) => {
      const used = issuedDOWeight[d.doNo] || 0;
      const rem = Number((d.totalMT - used).toFixed(3));
      return {
        doNo: d.doNo,
        khath: d.khath,
        union: d.union,
        recipient: d.recipient,
        remainingMT: rem,
        totalMT: d.totalMT,
        bags: d.totalBags,
        date: d.date,
      };
    })
    .filter((d) => d.remainingMT > 0.001);

  const balanceBags = Math.round(
    totalInitialBags - totalGrainIssuedBags - totalDiscrepancyBags
  );
  const balanceWeight = Number(
    (totalInitialWeight - totalGrainIssuedWeight - totalDiscrepancyWeight).toFixed(3)
  );

  return {
    meta,
    data: {
      fy: fy || { name: 'সকল অর্থবছর' },
      settings,
      dashboard: {
        totalInitialBags: Math.round(totalInitialBags),
        totalInitialWeight: Number(totalInitialWeight.toFixed(3)),
        totalGrainIssuedBags: Math.round(totalGrainIssuedBags),
        totalGrainIssuedWeight: Number(totalGrainIssuedWeight.toFixed(3)),
        totalDiscrepancyBags: Math.round(totalDiscrepancyBags),
        totalDiscrepancyWeight: Number(totalDiscrepancyWeight.toFixed(3)),
        balanceBags,
        balanceWeight,
        khathSummary,
        itemSummary,
        emptyBagSummary,
      },
      availableDOs,
      masterGrain: masterList,
      grainData: reportGrainList,
      emptyBagData,
      masterEmptyBags,
      bagIssueList,
      discList,
      issueList,
      dispatchList,
    },
  };
}

async function ensureSheetExists(
  accessToken: string,
  spreadsheetId: string,
  sheetName: string,
  headers: readonly string[]
): Promise<number> {
  const meta = await getSpreadsheetMetadata(accessToken, spreadsheetId);
  if (meta.sheetIdMap[sheetName] !== undefined) {
    // Check if header row exists
    const existing = await batchGetRanges(accessToken, spreadsheetId, [
      a1SheetRef(sheetName, 'A1:A1'),
    ]);
    const rows = existing.get(sheetName) || [];
    if (rows.length === 0) {
      await appendRows(accessToken, spreadsheetId, sheetName, [[...headers]]);
    }
    return meta.sheetIdMap[sheetName];
  }

  const createRes = await googleApiFetch<{
    replies?: Array<{ addSheet?: { properties?: { sheetId?: number } } }>;
  }>(`${SHEETS_API_BASE}/${encodeURIComponent(spreadsheetId)}:batchUpdate`, accessToken, {
    method: 'POST',
    body: JSON.stringify({
      requests: [{ addSheet: { properties: { title: sheetName } } }],
    }),
  });

  const newSheetId = createRes.replies?.[0]?.addSheet?.properties?.sheetId ?? 0;
  await appendRows(accessToken, spreadsheetId, sheetName, [[...headers]]);
  return newSheetId;
}

async function appendRows(
  accessToken: string,
  spreadsheetId: string,
  sheetName: string,
  rows: Array<Array<string | number>>
): Promise<void> {
  const range = encodeURIComponent(a1SheetRef(sheetName, 'A1'));
  const url = `${SHEETS_API_BASE}/${encodeURIComponent(
    spreadsheetId
  )}/values/${range}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`;
  await googleApiFetch(url, accessToken, {
    method: 'POST',
    body: JSON.stringify({ values: rows }),
  });
}

async function updateRowRange(
  accessToken: string,
  spreadsheetId: string,
  sheetName: string,
  rowIdx: number,
  expectedId: string,
  values: Array<string | number>
): Promise<void> {
  if (rowIdx <= 1) {
    throw new Error('অবৈধ সারি নম্বর (Row Index)।');
  }
  const checkMap = await batchGetRanges(accessToken, spreadsheetId, [
    a1SheetRef(sheetName, `A${rowIdx}:A${rowIdx}`),
  ]);
  const cellVal = String(checkMap.get(sheetName)?.[0]?.[0] ?? '').trim();
  if (expectedId && cellVal !== String(expectedId).trim()) {
    throw new Error('তালিকা পুরনো হয়ে গেছে। অনুগ্রহ করে রিফ্রেশ করে আবার চেষ্টা করুন।');
  }

  const endCol = String.fromCharCode(64 + Math.max(1, values.length));
  const range = encodeURIComponent(a1SheetRef(sheetName, `A${rowIdx}:${endCol}${rowIdx}`));
  const url = `${SHEETS_API_BASE}/${encodeURIComponent(
    spreadsheetId
  )}/values/${range}?valueInputOption=USER_ENTERED`;
  await googleApiFetch(url, accessToken, {
    method: 'PUT',
    body: JSON.stringify({ values: [values] }),
  });
}

async function writeSettingsPairs(
  accessToken: string,
  spreadsheetId: string,
  pairs: Record<string, string>
): Promise<void> {
  await ensureSheetExists(
    accessToken,
    spreadsheetId,
    SHEET_DEFS.settings.name,
    SHEET_DEFS.settings.headers
  );
  const data = await batchGetRanges(accessToken, spreadsheetId, [
    a1SheetRef(SHEET_DEFS.settings.name, 'A1:B200'),
  ]);
  const rows = data.get(SHEET_DEFS.settings.name) || [];
  const rowMap = new Map<string, number>();
  for (let i = 1; i < rows.length; i++) {
    const k = String(rows[i]?.[0] ?? '').trim();
    if (k) rowMap.set(k, i + 1);
  }

  const toAppend: Array<Array<string>> = [];
  for (const [k, v] of Object.entries(pairs)) {
    const existingRow = rowMap.get(k);
    if (existingRow) {
      const range = encodeURIComponent(
        a1SheetRef(SHEET_DEFS.settings.name, `B${existingRow}:B${existingRow}`)
      );
      await googleApiFetch(
        `${SHEETS_API_BASE}/${encodeURIComponent(
          spreadsheetId
        )}/values/${range}?valueInputOption=USER_ENTERED`,
        accessToken,
        {
          method: 'PUT',
          body: JSON.stringify({ values: [[v]] }),
        }
      );
    } else {
      toAppend.push([k, v]);
    }
  }

  if (toAppend.length > 0) {
    await appendRows(accessToken, spreadsheetId, SHEET_DEFS.settings.name, toAppend);
  }
}

export async function writeActionToSheets(
  accessToken: string,
  rawSpreadsheetId: string,
  action: string,
  p: Record<string, unknown>
): Promise<{ ok: boolean; message?: string; error?: string }> {
  const spreadsheetId = extractSpreadsheetId(rawSpreadsheetId);
  if (!spreadsheetId) {
    return { ok: false, error: 'Google Spreadsheet ID নির্বাচন করা হয়নি।' };
  }

  try {
    switch (action) {
      case 'addMasterKhamal': {
        await ensureSheetExists(
          accessToken,
          spreadsheetId,
          SHEET_DEFS.master.name,
          SHEET_DEFS.master.headers
        );
        await appendRows(accessToken, spreadsheetId, SHEET_DEFS.master.name, [
          [
            String(p.khamalId || '').trim(),
            String(p.godown || '').trim(),
            String(p.category || '').trim(),
            String(p.item || '').trim(),
            Number(p.bags) || 0,
            Number(p.weight) || 0,
            String(p.remarks || ''),
            String(p.entryDate || ''),
            String(p.sourceType || p.category || ''),
            String(p.uniqueId || ''),
          ],
        ]);
        return { ok: true, message: 'নতুন খামাল সরাসরি Google Sheet-এ সংরক্ষিত হয়েছে!' };
      }

      case 'addTransactionsBatch': {
        await ensureSheetExists(
          accessToken,
          spreadsheetId,
          SHEET_DEFS.trans.name,
          SHEET_DEFS.trans.headers
        );
        const items = Array.isArray(p.items)
          ? (p.items as Array<{ doNo: string; khath: string; bags: number; weight: number }>)
          : [];
        const baseTs = Date.now();
        const rows = items.map((it, idx) => [
          `TX-${baseTs}-${idx}`,
          String(p.issueDate || ''),
          String(p.khamalId || '').trim(),
          'Issue',
          Number(it.bags) || 0,
          Number(it.weight) || 0,
          String(p.reference || ''),
          String(it.khath || ''),
          String(it.doNo || '').trim(),
          0,
          0,
          '',
        ]);
        if (rows.length > 0) {
          await appendRows(accessToken, spreadsheetId, SHEET_DEFS.trans.name, rows);
        }
        return { ok: true, message: 'ডিও বিতরণ সরাসরি Google Sheet-এ সংরক্ষিত হয়েছে!' };
      }

      case 'updateTransaction': {
        await updateRowRange(
          accessToken,
          spreadsheetId,
          SHEET_DEFS.trans.name,
          Number(p.rowIdx),
          String(p.id || ''),
          [
            String(p.id || ''),
            String(p.issueDate || ''),
            String(p.khamalId || '').trim(),
            'Issue',
            Number(p.bags) || 0,
            Number(p.weight) || 0,
            String(p.reference || ''),
            String(p.khath || ''),
            String(p.doNo || '').trim(),
          ]
        );
        return { ok: true, message: 'বিতরণ রেকর্ড আপডেট হয়েছে।' };
      }

      case 'addDispatch': {
        await ensureSheetExists(
          accessToken,
          spreadsheetId,
          SHEET_DEFS.trans.name,
          SHEET_DEFS.trans.headers
        );
        await appendRows(accessToken, spreadsheetId, SHEET_DEFS.trans.name, [
          [
            `DSP-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            String(p.issueDate || ''),
            String(p.khamalId || '').trim(),
            String(p.type || 'Invoice'),
            Number(p.bags) || 0,
            Number(p.weight) || 0,
            String(p.reference || ''),
            '',
            String(p.docNo || '').trim(),
            0,
            0,
            String(p.party || '').trim(),
          ],
        ]);
        return { ok: true, message: 'ইনভয়েস/মিল প্রেরণ Google Sheet-এ সংরক্ষিত হয়েছে!' };
      }

      case 'updateDispatch': {
        await updateRowRange(
          accessToken,
          spreadsheetId,
          SHEET_DEFS.trans.name,
          Number(p.rowIdx),
          String(p.id || ''),
          [
            String(p.id || ''),
            String(p.issueDate || ''),
            String(p.khamalId || '').trim(),
            String(p.type || 'Invoice'),
            Number(p.bags) || 0,
            Number(p.weight) || 0,
            String(p.reference || ''),
            '',
            String(p.docNo || '').trim(),
            0,
            0,
            String(p.party || '').trim(),
          ]
        );
        return { ok: true, message: 'প্রেরণ রেকর্ড আপডেট হয়েছে।' };
      }

      case 'addDiscrepancy': {
        await ensureSheetExists(
          accessToken,
          spreadsheetId,
          SHEET_DEFS.trans.name,
          SHEET_DEFS.trans.headers
        );
        await appendRows(accessToken, spreadsheetId, SHEET_DEFS.trans.name, [
          [
            `DISC-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            String(p.discDate || ''),
            String(p.khamalId || '').trim(),
            'Discrepancy',
            0,
            0,
            String(p.remarks || ''),
            '',
            '',
            Number(p.bags) || 0,
            Number(p.weight) || 0,
            '',
          ],
        ]);
        return { ok: true, message: 'খামাল ঘাটতি Google Sheet-এ সংরক্ষিত হয়েছে!' };
      }

      case 'addEmptyBagMaster': {
        await ensureSheetExists(
          accessToken,
          spreadsheetId,
          SHEET_DEFS.emptyBag.name,
          SHEET_DEFS.emptyBag.headers
        );
        await appendRows(accessToken, spreadsheetId, SHEET_DEFS.emptyBag.name, [
          [
            `EB-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            String(p.godown || '').trim(),
            String(p.bagType || '').trim(),
            Number(p.bags) || 0,
            String(p.khamalNo || '').trim(),
            String(p.entryDate || ''),
          ],
        ]);
        return { ok: true, message: 'খালি বস্তা প্রাপ্তি Google Sheet-এ সংরক্ষিত হয়েছে!' };
      }

      case 'addEmptyBagIssue': {
        await ensureSheetExists(
          accessToken,
          spreadsheetId,
          SHEET_DEFS.bagTrans.name,
          SHEET_DEFS.bagTrans.headers
        );
        await appendRows(accessToken, spreadsheetId, SHEET_DEFS.bagTrans.name, [
          [
            `BTX-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            String(p.godown || '').trim(),
            String(p.bagType || '').trim(),
            Number(p.bags) || 0,
            String(p.khamalNo || '').trim(),
            String(p.issueDate || ''),
          ],
        ]);
        return { ok: true, message: 'খালি বস্তা বিতরণ Google Sheet-এ সংরক্ষিত হয়েছে!' };
      }

      case 'deleteRecord': {
        const sheetName = String(p.sheetName || '').trim();
        const rowIdx = Number(p.rowIdx);
        const expectedId = String(p.expectedId || '').trim();
        if (!sheetName || !(rowIdx > 1)) {
          throw new Error('রেকর্ড মুছে ফেলার তথ্য সঠিক নয়।');
        }
        const meta = await getSpreadsheetMetadata(accessToken, spreadsheetId);
        const sheetId = meta.sheetIdMap[sheetName];
        if (sheetId === undefined) {
          throw new Error(`শিট "${sheetName}" পাওয়া যায়নি।`);
        }
        if (expectedId) {
          const checkMap = await batchGetRanges(accessToken, spreadsheetId, [
            a1SheetRef(sheetName, `A${rowIdx}:A${rowIdx}`),
          ]);
          const cellVal = String(checkMap.get(sheetName)?.[0]?.[0] ?? '').trim();
          if (cellVal !== expectedId) {
            throw new Error('তালিকা পুরনো হয়ে গেছে। রিফ্রেশ করে আবার চেষ্টা করুন।');
          }
        }
        await googleApiFetch(
          `${SHEETS_API_BASE}/${encodeURIComponent(spreadsheetId)}:batchUpdate`,
          accessToken,
          {
            method: 'POST',
            body: JSON.stringify({
              requests: [
                {
                  deleteDimension: {
                    range: {
                      sheetId,
                      dimension: 'ROWS',
                      startIndex: rowIdx - 1,
                      endIndex: rowIdx,
                    },
                  },
                },
              ],
            }),
          }
        );
        return { ok: true, message: 'রেকর্ড Google Sheet থেকে মুছে ফেলা হয়েছে।' };
      }

      case 'saveInstitution': {
        const lsdName = String(p.lsdName || '').trim();
        const upazila = String(p.upazila || '').trim();
        const district = String(p.district || '').trim();
        const officer = String(p.officer || '').trim();
        if (!lsdName || !upazila || !district || !officer) {
          throw new Error('সব ঘর পূরণ করুন!');
        }
        await writeSettingsPairs(accessToken, spreadsheetId, {
          lsdName,
          upazila,
          district,
          officer,
        });
        return { ok: true, message: 'প্রতিষ্ঠানের তথ্য Google Sheet-এ সংরক্ষণ করা হয়েছে!' };
      }

      case 'saveCategories': {
        const clean: Record<string, string[]> = {};
        for (const it of ITEM_NAMES) {
          const raw = Array.isArray(p[it]) ? (p[it] as string[]) : [];
          const uniq = Array.from(new Set(raw.map((c) => String(c || '').trim()).filter(Boolean)));
          if (uniq.length === 0) {
            throw new Error(`${it}-এর জন্য কমপক্ষে একটি ক্যাটাগরি রাখুন!`);
          }
          clean[it] = uniq;
        }
        await writeSettingsPairs(accessToken, spreadsheetId, {
          categories: JSON.stringify(clean),
        });
        return { ok: true, message: 'ক্যাটাগরি তালিকা Google Sheet-এ সংরক্ষণ করা হয়েছে!' };
      }

      case 'addFiscalYear':
      case 'setActiveFY':
      case 'deleteFiscalYear': {
        const current = await fetchGasAppDataFromSheets(
          accessToken,
          {
            enabled: true,
            mainSpreadsheetId: spreadsheetId,
            mainSpreadsheetName: '',
            externalDoSpreadsheetId: '',
            externalDoSpreadsheetName: '',
            externalDoSheetName: 'DO_Issue',
            cutoffDate: '2026-11-01',
            excludeDoNos: [],
            bagKg: 50,
          },
          'ALL'
        );
        const st = current.data.settings;
        if (action === 'addFiscalYear') {
          const name = String(p.name || '').trim();
          const start = String(p.start || '');
          const end = String(p.end || '');
          if (!name || !start || !end) throw new Error('অর্থবছরের নাম ও দুটি তারিখ দিন!');
          if (start >= end) throw new Error('শুরুর তারিখ শেষের তারিখের আগে হতে হবে!');
          const list = [...st.fiscalYears];
          if (list.some((f) => f.name === name)) throw new Error('এই নামে অর্থবছর আগে থেকেই আছে!');
          list.push({ name, start, end });
          list.sort((a, b) => (a.start < b.start ? -1 : 1));
          const pairs: Record<string, string> = { fiscalYears: JSON.stringify(list) };
          if (p.makeActive) pairs.activeFY = name;
          await writeSettingsPairs(accessToken, spreadsheetId, pairs);
          return { ok: true, message: 'অর্থবছর যুক্ত করা হয়েছে!' };
        }
        if (action === 'setActiveFY') {
          const name = String(p.name || '');
          if (!st.fiscalYears.some((f) => f.name === name)) {
            throw new Error('অর্থবছর পাওয়া যায়নি!');
          }
          await writeSettingsPairs(accessToken, spreadsheetId, { activeFY: name });
          return { ok: true, message: 'ডিফল্ট অর্থবছর সেট করা হয়েছে!' };
        }
        const delName = String(p.name || '');
        if (st.fiscalYears.length <= 1) {
          throw new Error('কমপক্ষে একটি অর্থবছর থাকতে হবে!');
        }
        const filtered = st.fiscalYears.filter((f) => f.name !== delName);
        const pairs: Record<string, string> = { fiscalYears: JSON.stringify(filtered) };
        if (st.activeFY === delName) {
          pairs.activeFY = filtered[filtered.length - 1].name;
        }
        await writeSettingsPairs(accessToken, spreadsheetId, pairs);
        return { ok: true, message: 'অর্থবছর মুছে ফেলা হয়েছে (ডেটা অক্ষত আছে)!' };
      }

      default:
        return { ok: false, error: `অজানা অ্যাকশন: ${action}` };
    }
  } catch (err) {
    return {
      ok: false,
      error: err instanceof Error ? err.message : 'Google Sheet-এ সংরক্ষণ ব্যর্থ হয়েছে।',
    };
  }
}
