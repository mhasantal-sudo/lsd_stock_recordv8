import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  ArrowRight,
  Check,
  CheckCircle2,
  CheckSquare,
  FileText,
  Loader2,
  Minus,
  MinusSquare,
  PackageMinus,
  Plus,
  RefreshCw,
  Settings2,
  Square,
  Trash2,
  Truck,
  X,
} from 'lucide-react';
import {
  PRODUCTS,
  PRODUCT_MAP,
  inferDefaultProductFromCategory,
  type ChannelConfig,
  type ChannelMode,
  type DeliveryOrder,
  type GasBridgeStatus,
  type KhamalStockItem,
  type ProductCategory,
} from '../types/grain';
import {
  ProductIcon,
  formatBags,
  formatMetricTons,
  todayIsoDate,
} from './GrainIcons';
import type { DoDistributionPayload } from '../store/useGrainStore';
import { allocateBagsByWeight } from '../shared/gasBridge';

interface ActionResult {
  ok: boolean;
  error?: string;
  message?: string;
  khamalCount?: number;
  doCount?: number;
}

export interface ShortageCascadePreviewPlan {
  sourceKey: string;
  sourceGodown: string;
  sourceKhamalNo: string;
  product: ProductCategory;
  currentStockBags: number;
  currentStockMt: number;
  requestedShortageBags: number;
  requestedShortageMt: number;
  overdrawBags: number;
  overdrawMt: number;
  shifts: Array<{
    kind: 'do' | 'dispatch' | 'local_dist';
    recordId: string;
    label: string;
    originalBags: number;
    originalMt: number;
    shiftBags: number;
    shiftMt: number;
    targetGodown: string;
    targetKhamalNo: string;
    date: string;
  }>;
  unallocatedMt: number;
  unallocatedBags: number;
  candidateNextKhamals: KhamalStockItem[];
}

interface DistributionDoModalProps {
  isOpen: boolean;
  initialProduct?: ProductCategory;
  initialGodown?: string;
  initialKhamal?: string;
  initialModalMode?: 'existing' | 'distributed' | 'new' | 'dispatch' | 'shortage' | 'empty_bag';
  pendingDos: DeliveryOrder[];
  distributedDos: DeliveryOrder[];
  khamalStocks: KhamalStockItem[];
  godownList?: string[];
  channels: ChannelConfig;
  gasBridgeStatus?: GasBridgeStatus;
  isSyncingDos?: boolean;
  onSyncExternalDos?: () => void;
  onClose: () => void;
  onSwitchToReceipt: (product: ProductCategory) => void;
  onOpenChannelSettings: (product: ProductCategory, mode: ChannelMode) => void;
  onExecuteDoDistribution: (
    payload: DoDistributionPayload
  ) => ActionResult | Promise<ActionResult>;
  onSubmitDispatch?: (input: {
    type: 'Invoice' | 'Mill';
    khamalId: string;
    docNo: string;
    party: string;
    bags: number;
    weight: number;
    issueDate: string;
    reference: string;
    allocations?: Array<{ godownNo?: string; khamalId: string; bags: number; weight: number }>;
  }) => Promise<ActionResult>;
  onSubmitEmptyBagIssue?: (input: {
    godown: string;
    bagType: string;
    bags: number;
    khamalNo: string;
    issueDate: string;
  }) => Promise<ActionResult>;
  onPreviewShortageCascade?: (
    khamalKeyOrId: string,
    shortBags: number,
    shortWeight: number,
    preferredNextKeys?: string[]
  ) => ShortageCascadePreviewPlan | null;
  onSubmitDiscrepancy?: (input: {
    khamalKey?: string;
    khamalId: string;
    bags: number;
    weight: number;
    discDate: string;
    remarks: string;
    preferredNextKeys?: string[];
    autoCascade?: boolean;
  }) => Promise<ActionResult>;
}

interface AllocatedKhamalDraft {
  key: string;
  godownNo: string;
  khamalNo: string;
  availBags: number;
  availMt: number;
  hasShortage: boolean;
  shortageUnit: 'kg' | 'mt';
  shortageValue: string;
  shortageBags: string;
  deliveredMt: string;
  deliveredBags: string;
  manualOverride: boolean;
}

type ModalMode = 'existing' | 'distributed' | 'new' | 'dispatch' | 'bag_shortage';

export const DistributionDoModal: React.FC<DistributionDoModalProps> = ({
  isOpen,
  initialProduct = 'rice',
  initialGodown,
  initialKhamal,
  initialModalMode,
  pendingDos,
  distributedDos,
  khamalStocks,
  godownList = ['০১', '০২', '০৩', '০৪'],
  channels,
  gasBridgeStatus = 'idle',
  isSyncingDos = false,
  onSyncExternalDos,
  onClose,
  onSwitchToReceipt,
  onOpenChannelSettings,
  onExecuteDoDistribution,
  onSubmitDispatch,
  onSubmitEmptyBagIssue,
  onPreviewShortageCascade,
  onSubmitDiscrepancy,
}) => {
  const [doSourceMode, setDoSourceMode] = useState<ModalMode>('existing');
  const [selectedDoIds, setSelectedDoIds] = useState<string[]>([]);
  const [doProductFilter, setDoProductFilter] = useState<'all' | ProductCategory>('all');

  // New / Custom DO fields
  const [newDoNumber, setNewDoNumber] = useState<string>('');
  const [product, setProduct] = useState<ProductCategory>(initialProduct);
  const [category, setCategory] = useState<string>('');
  const [targetMtInput, setTargetMtInput] = useState<string>('');
  const [targetBagsInput, setTargetBagsInput] = useState<string>('');
  const [recipient, setRecipient] = useState<string>('');
  const [date, setDate] = useState<string>(todayIsoDate());
  const [note, setNote] = useState<string>('');
  const [forceMarkCompleted, setForceMarkCompleted] = useState<boolean>(false);

  // Proportional auto bag splitter input
  const [autoTotalBagsInput, setAutoTotalBagsInput] = useState<string>('');

  // Allocated khamals stack for DO
  const [allocations, setAllocations] = useState<AllocatedKhamalDraft[]>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState<boolean>(false);

  // Dispatch (Invoice / Mill) multi-khamal state
  const [dispatchType, setDispatchType] = useState<'Invoice' | 'Mill'>('Invoice');
  const [dispatchDocNo, setDispatchDocNo] = useState<string>('');
  const [dispatchParty, setDispatchParty] = useState<string>('');
  const [dispatchTotalBags, setDispatchTotalBags] = useState<string>('');
  const [dispatchTotalWeight, setDispatchTotalWeight] = useState<string>('');
  const [dispatchRef, setDispatchRef] = useState<string>('');
  const [dispatchAllocations, setDispatchAllocations] = useState<AllocatedKhamalDraft[]>([]);

  // Empty Bag Issue / Discrepancy (with Cascade) state
  const [otherSubMode, setOtherSubMode] = useState<'empty_bag' | 'shortage'>('empty_bag');
  const [bagGodown, setBagGodown] = useState<string>(godownList[0] || '০১');
  const [bagType, setBagType] = useState<string>('৫০ কেজির বস্তা');
  const [bagQty, setBagQty] = useState<string>('');
  const [bagKhamalNo, setBagKhamalNo] = useState<string>('');

  const [discKhamalKey, setDiscKhamalKey] = useState<string>('');
  const [discBags, setDiscBags] = useState<string>('');
  const [discWeight, setDiscWeight] = useState<string>('');
  const [discRemarks, setDiscRemarks] = useState<string>('');
  const [preferredNextKeys, setPreferredNextKeys] = useState<string[]>([]);
  const [autoCascadeEnabled, setAutoCascadeEnabled] = useState<boolean>(true);

  const selectedDos = useMemo(
    () => pendingDos.filter((d) => selectedDoIds.includes(d.id)),
    [pendingDos, selectedDoIds]
  );

  const selectedCategoryCount = useMemo(
    () => new Set(selectedDos.map((d) => d.category)).size,
    [selectedDos]
  );

  const activeProduct: ProductCategory =
    doSourceMode === 'existing' && selectedDos.length > 0 ? selectedDos[0].product : product;
  const activeMeta = PRODUCT_MAP[activeProduct];

  const doRemainingTargetMt = useMemo(() => {
    if (doSourceMode === 'existing') {
      return selectedDos.reduce(
        (acc, d) => Number((acc + Math.max(0, d.totalMt - d.deliveredMt)).toFixed(4)),
        0
      );
    }
    return Math.max(0, Number(targetMtInput) || 0);
  }, [doSourceMode, selectedDos, targetMtInput]);

  const doRemainingTargetBags = useMemo(() => {
    if (doSourceMode === 'existing') {
      return selectedDos.reduce(
        (acc, d) => acc + Math.max(0, d.totalBags - d.deliveredBags),
        0
      );
    }
    return Math.max(0, Math.round(Number(targetBagsInput) || 0));
  }, [doSourceMode, selectedDos, targetBagsInput]);

  const availableDistCategories = useMemo(
    () => channels[product]?.distribution || [],
    [channels, product]
  );

  useEffect(() => {
    if (!availableDistCategories.includes(category)) {
      setCategory(availableDistCategories[0] || '');
    }
  }, [availableDistCategories, category]);

  const getShortageMt = (row: AllocatedKhamalDraft): number => {
    if (!row.hasShortage) return 0;
    const val = Number(row.shortageValue) || 0;
    if (val <= 0) return 0;
    return row.shortageUnit === 'kg' ? Number((val / 1000).toFixed(4)) : Number(val.toFixed(4));
  };

  const getShortageBags = (row: AllocatedKhamalDraft): number => {
    if (!row.hasShortage) return 0;
    return Math.max(0, Math.round(Number(row.shortageBags) || 0));
  };

  const recomputeAllocations = (
    drafts: AllocatedKhamalDraft[],
    targetMt: number,
    targetBags: number,
    tracksWeight: boolean
  ): AllocatedKhamalDraft[] => {
    let remMt = targetMt;
    let remBags = targetBags;

    return drafts.map((row) => {
      const shMt = getShortageMt(row);
      const shBags = getShortageBags(row);
      const netMt = Math.max(0, Number((row.availMt - shMt).toFixed(4)));
      const netBags = Math.max(0, row.availBags - shBags);

      if (row.manualOverride) {
        const usedMt = Math.min(netMt, Number(row.deliveredMt) || 0);
        const usedBags = Math.min(netBags, Math.round(Number(row.deliveredBags) || 0));
        if (targetMt > 0) remMt = Math.max(0, Number((remMt - usedMt).toFixed(4)));
        if (targetBags > 0) remBags = Math.max(0, remBags - usedBags);
        return row;
      }

      if (tracksWeight) {
        const takeMt = targetMt > 0 ? Math.min(netMt, remMt) : netMt;
        const ratio = row.availMt > 0 ? takeMt / row.availMt : 0;
        const estBags =
          targetBags > 0
            ? Math.min(netBags, remBags)
            : Math.min(netBags, Math.round(row.availBags * ratio));

        if (targetMt > 0) remMt = Math.max(0, Number((remMt - takeMt).toFixed(4)));
        if (targetBags > 0) remBags = Math.max(0, remBags - estBags);

        return {
          ...row,
          deliveredMt: takeMt > 0 ? takeMt.toFixed(3) : '0.000',
          deliveredBags: String(estBags),
        };
      } else {
        const takeBags = targetBags > 0 ? Math.min(netBags, remBags) : netBags;
        if (targetBags > 0) remBags = Math.max(0, remBags - takeBags);
        return {
          ...row,
          deliveredMt: '0',
          deliveredBags: String(takeBags),
        };
      }
    });
  };

  // All grain khamals (INCLUDING 0-balance exhausted khamals so shortage can be entered anytime!)
  const grainKhamals = useMemo(
    () =>
      khamalStocks.filter(
        (k) =>
          !PRODUCT_MAP[k.product].isBagProduct &&
          (k.receiptBags > 0 ||
            k.receiptMt > 0 ||
            k.distBags > 0 ||
            k.distMt > 0 ||
            k.currentBags > 0 ||
            k.currentMt > 0)
      ),
    [khamalStocks]
  );

  // Reset on modal open
  useEffect(() => {
    if (!isOpen) return;
    setErrorMsg(null);
    setIsSaving(false);
    setDate(todayIsoDate());
    setNote('');
    setNewDoNumber('');
    setTargetMtInput('');
    setTargetBagsInput('');
    setAutoTotalBagsInput('');
    setRecipient('');
    setForceMarkCompleted(false);
    setProduct(initialProduct);
    setDoProductFilter('all');

    // Reset dispatch & bag/shortage fields
    setDispatchType(initialProduct === 'paddy' ? 'Mill' : 'Invoice');
    setDispatchDocNo('');
    setDispatchParty('');
    setDispatchTotalBags('');
    setDispatchTotalWeight('');
    setDispatchRef('');
    setDispatchAllocations([]);

    setBagGodown(initialGodown || godownList[0] || '০১');
    setBagType(initialProduct === 'bosta_30' ? '৩০ কেজির বস্তা' : '৫০ কেজির বস্তা');
    setBagQty('');
    setBagKhamalNo(initialKhamal || '');

    // Preselect matching khamal key for shortage
    const matchGrain = grainKhamals.find(
      (k) =>
        (!initialProduct || PRODUCT_MAP[initialProduct].isBagProduct || k.product === initialProduct) &&
        (!initialGodown || k.godownNo === initialGodown) &&
        (!initialKhamal || k.khamalNo === initialKhamal)
    );
    setDiscKhamalKey(matchGrain?.key || grainKhamals[0]?.key || '');
    setDiscBags('');
    setDiscWeight('');
    setDiscRemarks('');
    setPreferredNextKeys([]);
    setAutoCascadeEnabled(true);

    if (initialModalMode === 'shortage') {
      setDoSourceMode('bag_shortage');
      setOtherSubMode('shortage');
      setSelectedDoIds([]);
      setAllocations([]);
      return;
    }
    if (initialModalMode === 'empty_bag') {
      setDoSourceMode('bag_shortage');
      setOtherSubMode('empty_bag');
      setSelectedDoIds([]);
      setAllocations([]);
      return;
    }
    if (initialModalMode === 'dispatch') {
      setDoSourceMode('dispatch');
      setSelectedDoIds([]);
      setAllocations([]);
      return;
    }

    if (initialProduct === 'bosta_50' || initialProduct === 'bosta_30') {
      setDoSourceMode('bag_shortage');
      setOtherSubMode('empty_bag');
      setSelectedDoIds([]);
      setAllocations([]);
      return;
    }

    if (pendingDos.length > 0) {
      setDoSourceMode('existing');
      setSelectedDoIds([]);
      setAllocations([]);
    } else {
      setDoSourceMode('new');
      setSelectedDoIds([]);
      setAllocations([]);
    }
  }, [
    isOpen,
    initialProduct,
    initialGodown,
    initialKhamal,
    initialModalMode,
    pendingDos,
    godownList,
    grainKhamals,
  ]);

  useEffect(() => {
    setSelectedDoIds((prev) => prev.filter((id) => pendingDos.some((d) => d.id === id)));
  }, [pendingDos]);

  useEffect(() => {
    if (!isOpen || !initialGodown || !initialKhamal || initialModalMode === 'shortage') return;
    const match = khamalStocks.find(
      (k) =>
        k.product === activeProduct &&
        k.godownNo === initialGodown &&
        k.khamalNo === initialKhamal &&
        (k.currentBags > 0 || k.currentMt > 0)
    );
    if (match) {
      setAllocations((prev) => {
        if (prev.some((a) => a.key === match.key)) return prev;
        return [
          {
            key: match.key,
            godownNo: match.godownNo,
            khamalNo: match.khamalNo,
            availBags: match.currentBags,
            availMt: match.currentMt,
            hasShortage: false,
            shortageUnit: 'mt',
            shortageValue: '',
            shortageBags: '',
            deliveredMt: activeMeta.tracksWeight ? match.currentMt.toFixed(3) : '0',
            deliveredBags: String(match.currentBags),
            manualOverride: false,
          },
        ];
      });
    }
  }, [
    isOpen,
    initialGodown,
    initialKhamal,
    initialModalMode,
    activeProduct,
    khamalStocks,
    activeMeta.tracksWeight,
  ]);

  const displayedPendingDos = useMemo(() => {
    if (doProductFilter === 'all') return pendingDos;
    return pendingDos.filter((d) => d.product === doProductFilter);
  }, [pendingDos, doProductFilter]);

  // Group displayed pending DOs cleanly by Product + Category (যেন চালের জিআর ও গমের জিআর আলাদা থাকে)
  const groupedPendingDos = useMemo(() => {
    const map = new Map<
      string,
      { groupKey: string; product: ProductCategory; category: string; items: DeliveryOrder[] }
    >();
    for (const d of displayedPendingDos) {
      const cat = d.category || 'অন্যান্য';
      const key = `${d.product}::${cat}`;
      const existing = map.get(key);
      if (existing) {
        existing.items.push(d);
      } else {
        map.set(key, {
          groupKey: key,
          product: d.product,
          category: cat,
          items: [d],
        });
      }
    }
    return Array.from(map.values());
  }, [displayedPendingDos]);

  const availableKhamals = useMemo(
    () =>
      khamalStocks.filter(
        (k) =>
          k.product === activeProduct &&
          (k.currentBags > 0 || k.currentMt > 0) &&
          !allocations.some((a) => a.key === k.key)
      ),
    [khamalStocks, activeProduct, allocations]
  );

  // Dispatch candidate khamals
  const dispatchCandidateKhamals = useMemo(() => {
    const targetProd: ProductCategory = dispatchType === 'Mill' ? 'paddy' : 'rice';
    const preferred = khamalStocks.filter(
      (k) =>
        k.product === targetProd &&
        (k.currentBags > 0 || k.currentMt > 0) &&
        !dispatchAllocations.some((a) => a.key === k.key)
    );
    if (preferred.length > 0) return preferred;
    return khamalStocks.filter(
      (k) =>
        !PRODUCT_MAP[k.product].isBagProduct &&
        (k.currentBags > 0 || k.currentMt > 0) &&
        !dispatchAllocations.some((a) => a.key === k.key)
    );
  }, [khamalStocks, dispatchType, dispatchAllocations]);

  // Pre-fill first dispatch khamal if none selected yet in dispatch mode
  useEffect(() => {
    if (doSourceMode !== 'dispatch') return;
    setDispatchAllocations((prev) => {
      const valid = prev.filter((a) =>
        khamalStocks.some(
          (k) => k.key === a.key && (k.currentBags > 0 || k.currentMt > 0)
        )
      );
      if (valid.length > 0) return valid;
      if (dispatchCandidateKhamals.length > 0) {
        const first = dispatchCandidateKhamals[0];
        return recomputeAllocations(
          [
            {
              key: first.key,
              godownNo: first.godownNo,
              khamalNo: first.khamalNo,
              availBags: first.currentBags,
              availMt: first.currentMt,
              hasShortage: false,
              shortageUnit: 'mt',
              shortageValue: '',
              shortageBags: '',
              deliveredMt: '0',
              deliveredBags: '0',
              manualOverride: false,
            },
          ],
          Number(dispatchTotalWeight) || 0,
          Math.round(Number(dispatchTotalBags) || 0),
          true
        );
      }
      return [];
    });
  }, [doSourceMode, dispatchType, khamalStocks, dispatchCandidateKhamals, dispatchTotalWeight, dispatchTotalBags]);

  useEffect(() => {
    if (grainKhamals.length > 0 && !grainKhamals.some((k) => k.key === discKhamalKey)) {
      setDiscKhamalKey(grainKhamals[0].key);
    }
  }, [grainKhamals, discKhamalKey]);

  const selectedShortageKhamal = useMemo(
    () => grainKhamals.find((k) => k.key === discKhamalKey) || null,
    [grainKhamals, discKhamalKey]
  );

  // Live Shortage + Cascade preview plan
  const shortageCascadePlan = useMemo<ShortageCascadePreviewPlan | null>(() => {
    if (!onPreviewShortageCascade || !discKhamalKey) return null;
    const bNum = Math.round(Number(discBags) || 0);
    const wNum = Number(discWeight) || 0;
    if (bNum <= 0 && wNum <= 0) return null;
    return onPreviewShortageCascade(discKhamalKey, bNum, wNum, preferredNextKeys);
  }, [onPreviewShortageCascade, discKhamalKey, discBags, discWeight, preferredNextKeys]);

  const allocationTotals = useMemo(() => {
    let deliveredMt = 0;
    let deliveredBags = 0;
    let shortageMt = 0;
    let shortageBags = 0;

    allocations.forEach((a) => {
      deliveredMt = Number((deliveredMt + (Number(a.deliveredMt) || 0)).toFixed(4));
      deliveredBags += Math.round(Number(a.deliveredBags) || 0);
      shortageMt = Number((shortageMt + getShortageMt(a)).toFixed(4));
      shortageBags += getShortageBags(a);
    });

    const stillNeededMt =
      doRemainingTargetMt > 0
        ? Math.max(0, Number((doRemainingTargetMt - deliveredMt).toFixed(4)))
        : 0;
    const stillNeededBags =
      doRemainingTargetBags > 0 ? Math.max(0, doRemainingTargetBags - deliveredBags) : 0;

    return {
      deliveredMt,
      deliveredBags,
      shortageMt,
      shortageBags,
      stillNeededMt,
      stillNeededBags,
    };
  }, [allocations, doRemainingTargetMt, doRemainingTargetBags]);

  const dispatchTotals = useMemo(() => {
    let mt = 0;
    let bags = 0;
    dispatchAllocations.forEach((a) => {
      mt = Number((mt + (Number(a.deliveredMt) || 0)).toFixed(4));
      bags += Math.round(Number(a.deliveredBags) || 0);
    });
    return { mt, bags };
  }, [dispatchAllocations]);

  if (!isOpen) return null;

  const lockedProduct = selectedDos.length > 0 ? selectedDos[0].product : null;

  const applySelectedDos = (nextIds: string[]) => {
    const dedup = Array.from(new Set(nextIds));
    setSelectedDoIds(dedup);
    setErrorMsg(null);

    const nextDos = pendingDos.filter((d) => dedup.includes(d.id));
    if (nextDos.length === 0) {
      setAllocations([]);
      return;
    }

    const nextProduct = nextDos[0].product;
    const nextTargetMt = nextDos.reduce(
      (acc, d) => Number((acc + Math.max(0, d.totalMt - d.deliveredMt)).toFixed(4)),
      0
    );
    const nextTargetBags = nextDos.reduce(
      (acc, d) => acc + Math.max(0, d.totalBags - d.deliveredBags),
      0
    );

    if (lockedProduct && lockedProduct !== nextProduct) {
      setAllocations([]);
    } else {
      setAllocations((prev) =>
        recomputeAllocations(
          prev,
          nextTargetMt,
          nextTargetBags,
          PRODUCT_MAP[nextProduct].tracksWeight
        )
      );
    }
  };

  const handleToggleDo = (doItem: DeliveryOrder) => {
    if (selectedDoIds.includes(doItem.id)) {
      applySelectedDos(selectedDoIds.filter((id) => id !== doItem.id));
      return;
    }
    if (lockedProduct && lockedProduct !== doItem.product) {
      setErrorMsg(
        `একসাথে শুধু একই পণ্যের (${PRODUCT_MAP[lockedProduct].shortBn}) বিভিন্ন খাতের ডিও নির্বাচন করা যাবে। অন্য পণ্য নিতে "নির্বাচন বাতিল" চাপুন।`
      );
      return;
    }
    applySelectedDos([...selectedDoIds, doItem.id]);
  };

  const handleToggleCategoryGroup = (itemsInCat: DeliveryOrder[]) => {
    const targetProd = lockedProduct || itemsInCat[0]?.product;
    const compatible = itemsInCat.filter((d) => d.product === targetProd);
    if (compatible.length === 0) {
      setErrorMsg(
        `একসাথে শুধু একই পণ্যের (${lockedProduct ? PRODUCT_MAP[lockedProduct].shortBn : ''}) বিভিন্ন খাতের ডিও নির্বাচন করা যাবে।`
      );
      return;
    }
    const compatIds = compatible.map((d) => d.id);
    const allSelected = compatIds.every((id) => selectedDoIds.includes(id));

    if (allSelected) {
      applySelectedDos(selectedDoIds.filter((id) => !compatIds.includes(id)));
    } else {
      applySelectedDos([...selectedDoIds, ...compatIds]);
    }
  };

  const handleSelectAllMatchingProduct = () => {
    const targetProd =
      lockedProduct || (doProductFilter !== 'all' ? doProductFilter : pendingDos[0]?.product);
    if (!targetProd) return;
    const matchingIds = pendingDos.filter((d) => d.product === targetProd).map((d) => d.id);
    applySelectedDos(matchingIds);
  };

  const handleAddKhamal = (k: KhamalStockItem) => {
    const draft: AllocatedKhamalDraft = {
      key: k.key,
      godownNo: k.godownNo,
      khamalNo: k.khamalNo,
      availBags: k.currentBags,
      availMt: k.currentMt,
      hasShortage: false,
      shortageUnit: 'mt',
      shortageValue: '',
      shortageBags: '',
      deliveredMt: '0',
      deliveredBags: '0',
      manualOverride: false,
    };
    const next = recomputeAllocations(
      [...allocations, draft],
      doRemainingTargetMt,
      doRemainingTargetBags,
      activeMeta.tracksWeight
    );
    setAllocations(next);
    setErrorMsg(null);
  };

  const handleUpdateAllocation = (
    key: string,
    patch: Partial<AllocatedKhamalDraft>,
    recalculateAuto = true
  ) => {
    const updated = allocations.map((a) => (a.key === key ? { ...a, ...patch } : a));
    const finalRows = recalculateAuto
      ? recomputeAllocations(
          updated,
          doRemainingTargetMt,
          doRemainingTargetBags,
          activeMeta.tracksWeight
        )
      : updated;
    setAllocations(finalRows);
    setErrorMsg(null);
  };

  const handleRemoveAllocation = (key: string) => {
    const remaining = allocations.filter((a) => a.key !== key);
    setAllocations(
      recomputeAllocations(
        remaining,
        doRemainingTargetMt,
        doRemainingTargetBags,
        activeMeta.tracksWeight
      )
    );
  };

  const handleSplitBagsProportionally = (rawVal: string) => {
    setAutoTotalBagsInput(rawVal);
    const total = Math.round(Number(rawVal) || 0);
    if (total <= 0 || allocations.length === 0) return;

    const weights = allocations.map((a) => Number(a.deliveredMt) || a.availMt || 1);
    const split = allocateBagsByWeight(total, weights);
    setAllocations((prev) =>
      prev.map((a, idx) => ({
        ...a,
        deliveredBags: String(split[idx] ?? 0),
        manualOverride: true,
      }))
    );
  };

  // Multi-khamal helpers for Invoice / Mill Dispatch
  const handleAddDispatchKhamal = (k: KhamalStockItem) => {
    const draft: AllocatedKhamalDraft = {
      key: k.key,
      godownNo: k.godownNo,
      khamalNo: k.khamalNo,
      availBags: k.currentBags,
      availMt: k.currentMt,
      hasShortage: false,
      shortageUnit: 'mt',
      shortageValue: '',
      shortageBags: '',
      deliveredMt: '0',
      deliveredBags: '0',
      manualOverride: false,
    };
    const next = recomputeAllocations(
      [...dispatchAllocations, draft],
      Number(dispatchTotalWeight) || 0,
      Math.round(Number(dispatchTotalBags) || 0),
      true
    );
    setDispatchAllocations(next);
    setErrorMsg(null);
  };

  const handleUpdateDispatchAlloc = (
    key: string,
    patch: Partial<AllocatedKhamalDraft>,
    recalculateAuto = false
  ) => {
    const updated = dispatchAllocations.map((a) => (a.key === key ? { ...a, ...patch } : a));
    setDispatchAllocations(
      recalculateAuto
        ? recomputeAllocations(
            updated,
            Number(dispatchTotalWeight) || 0,
            Math.round(Number(dispatchTotalBags) || 0),
            true
          )
        : updated
    );
  };

  const handleTogglePreferredNextKhamal = (kKey: string) => {
    setPreferredNextKeys((prev) =>
      prev.includes(kKey) ? prev.filter((x) => x !== kKey) : [...prev, kKey]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSaving) return;
    setErrorMsg(null);

    if (doSourceMode === 'dispatch') {
      if (!dispatchDocNo.trim()) {
        setErrorMsg(
          dispatchType === 'Invoice'
            ? 'ইনভয়েস নম্বর লিখুন।'
            : 'মিল ডেলিভারি / ক্রাশিং নম্বর লিখুন।'
        );
        return;
      }
      if (!dispatchParty.trim()) {
        setErrorMsg(
          dispatchType === 'Invoice' ? 'প্রাপক এলএসডি-এর নাম লিখুন।' : 'মিলারের নাম লিখুন।'
        );
        return;
      }
      const validSplits = dispatchAllocations
        .map((a) => ({
          godownNo: a.godownNo,
          khamalId: a.khamalNo,
          bags: Math.round(Number(a.deliveredBags) || 0),
          weight: Number((Number(a.deliveredMt) || 0).toFixed(3)),
        }))
        .filter((s) => s.bags > 0 || s.weight > 0);

      if (validSplits.length === 0) {
        setErrorMsg('কমপক্ষে একটি খামাল থেকে প্রেরণের বস্তা ও ওজন নির্ধারণ করুন।');
        return;
      }
      if (!onSubmitDispatch) {
        setErrorMsg('ডিসপ্যাচ হ্যান্ডলার কনফিগার করা নেই।');
        return;
      }

      const totBags = validSplits.reduce((s, a) => s + a.bags, 0);
      const totWeight = Number(validSplits.reduce((s, a) => s + a.weight, 0).toFixed(3));

      setIsSaving(true);
      try {
        const res = await onSubmitDispatch({
          type: dispatchType,
          khamalId: validSplits[0].khamalId,
          docNo: dispatchDocNo.trim(),
          party: dispatchParty.trim(),
          bags: totBags,
          weight: totWeight,
          issueDate: date,
          reference: dispatchRef.trim(),
          allocations: validSplits,
        });
        if (!res.ok) {
          setErrorMsg(res.error || 'প্রেরণ তথ্য সংরক্ষণ করা যায়নি।');
          return;
        }
        onClose();
      } finally {
        setIsSaving(false);
      }
      return;
    }

    if (doSourceMode === 'bag_shortage') {
      if (otherSubMode === 'empty_bag') {
        const qty = Math.round(Number(bagQty) || 0);
        if (!bagGodown.trim() || qty <= 0) {
          setErrorMsg('গুদাম ও বস্তার সংখ্যা সঠিকভাবে লিখুন।');
          return;
        }
        if (!onSubmitEmptyBagIssue) {
          setErrorMsg('বস্তা বিতরণ হ্যান্ডলার কনফিগার করা নেই।');
          return;
        }
        setIsSaving(true);
        try {
          const res = await onSubmitEmptyBagIssue({
            godown: bagGodown.trim(),
            bagType,
            bags: qty,
            khamalNo: bagKhamalNo.trim() || '-',
            issueDate: date,
          });
          if (!res.ok) {
            setErrorMsg(res.error || 'বস্তা বিতরণ সংরক্ষণ করা যায়নি।');
            return;
          }
          onClose();
        } finally {
          setIsSaving(false);
        }
        return;
      } else {
        if (!selectedShortageKhamal) {
          setErrorMsg('ঘাটতি এন্ট্রির জন্য খামাল নির্বাচন করুন।');
          return;
        }
        const bNum = Math.round(Number(discBags) || 0);
        const wNum = Number(discWeight) || 0;
        if (bNum <= 0 && wNum <= 0) {
          setErrorMsg('ঘাটতির বস্তা বা ওজন (মে.টন) ০-এর বেশি হতে হবে।');
          return;
        }
        if (!onSubmitDiscrepancy) {
          setErrorMsg('ঘাটতি হ্যান্ডলার কনফিগার করা নেই।');
          return;
        }
        setIsSaving(true);
        try {
          const res = await onSubmitDiscrepancy({
            khamalKey: selectedShortageKhamal.key,
            khamalId: selectedShortageKhamal.khamalNo,
            bags: bNum,
            weight: Number(wNum.toFixed(3)),
            discDate: date,
            remarks: discRemarks.trim() || 'খামাল ঘাটতি',
            preferredNextKeys,
            autoCascade: autoCascadeEnabled,
          });
          if (!res.ok) {
            setErrorMsg(res.error || 'ঘাটতি সংরক্ষণ করা যায়নি।');
            return;
          }
          onClose();
        } finally {
          setIsSaving(false);
        }
        return;
      }
    }

    // Standard DO Distribution (existing across multi-category or new)
    const doItems =
      doSourceMode === 'existing'
        ? selectedDos.map((d) => ({
            doId: d.id,
            doNumber: d.doNumber,
            category: d.category,
            targetBags: Math.max(0, d.totalBags - d.deliveredBags),
            targetMt: Math.max(0, Number((d.totalMt - d.deliveredMt).toFixed(4))),
            recipient: d.recipient,
          }))
        : [
            {
              doNumber: newDoNumber.trim(),
              category,
              targetBags: doRemainingTargetBags,
              targetMt: doRemainingTargetMt,
              recipient,
            },
          ];

    if (doItems.length === 0 || !doItems[0].doNumber) {
      setErrorMsg('অনুগ্রহ করে কমপক্ষে একটি ডিও নম্বর নির্বাচন করুন অথবা নতুন ডিও নম্বর লিখুন।');
      return;
    }
    if (allocations.length === 0) {
      setErrorMsg('নিচের তালিকা থেকে কমপক্ষে একটি খামাল নির্বাচন করুন।');
      return;
    }

    setIsSaving(true);
    try {
      const res = await Promise.resolve(
        onExecuteDoDistribution({
          doItems,
          product: activeProduct,
          date,
          note,
          markCompleted: forceMarkCompleted,
          allocations: allocations.map((a) => ({
            godownNo: a.godownNo,
            khamalNo: a.khamalNo,
            deliveredBags: Math.round(Number(a.deliveredBags) || 0),
            deliveredMt: Number((Number(a.deliveredMt) || 0).toFixed(4)),
            shortageBags: getShortageBags(a),
            shortageMt: getShortageMt(a),
          })),
        })
      );

      if (!res.ok) {
        setErrorMsg(res.error || 'বিতরণ সংরক্ষণ করা যায়নি।');
        return;
      }

      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  const showAllocationWorkspace = doSourceMode === 'existing' || doSourceMode === 'new';
  const showFormSubmit =
    showAllocationWorkspace || doSourceMode === 'dispatch' || doSourceMode === 'bag_shortage';

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/55 backdrop-blur-xs sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="do-dist-title"
    >
      <div className="w-full sm:max-w-3xl max-h-[94dvh] flex flex-col bg-white rounded-t-3xl sm:rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Grab handle on mobile */}
        <div className="sm:hidden pt-2.5 pb-1 flex justify-center bg-white shrink-0">
          <div className="w-10 h-1.5 rounded-full bg-slate-300" aria-hidden="true" />
        </div>

        {/* Header */}
        <div className="px-4 sm:px-6 py-3.5 border-b border-slate-200 flex items-center justify-between gap-3 shrink-0 bg-white">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="h-9 w-9 rounded-xl bg-rose-100 text-rose-800 flex items-center justify-center shrink-0">
              <Minus className="h-5 w-5 stroke-[2.5]" />
            </div>
            <div className="min-w-0">
              <h2 id="do-dist-title" className="text-base sm:text-lg font-bold text-slate-900 truncate">
                ডিও বিতরণ, ইনভয়েস / মিল ও খামাল ঘাটতি
              </h2>
              <p className="text-xs text-slate-500 truncate">
                {gasBridgeStatus === 'connected'
                  ? 'একাধিক খাতের ডিও ও খামাল সিলেক্ট করুন · ঘাটতি পরের খামালে অটো-অ্যাডজাস্ট হবে'
                  : 'একাধিক খাতের ডিও একসাথে নির্বাচন করুন ও ঘাটতি পরের খামালে সমন্বয় করুন'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => onSwitchToReceipt(activeProduct)}
              className="hidden sm:inline-flex items-center gap-1 rounded-lg border border-emerald-200 bg-emerald-50 px-2.5 py-1.5 text-xs font-bold text-emerald-800 hover:bg-emerald-100 cursor-pointer"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>প্রাপ্তিতে যান</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-100 hover:text-slate-800 cursor-pointer"
              aria-label="বন্ধ করুন"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        <form onSubmit={(e) => void handleSubmit(e)} className="flex-1 overflow-y-auto px-4 sm:px-6 py-4 space-y-5">
          {/* Top Mode Switcher */}
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5 p-1 rounded-xl bg-slate-100 border border-slate-200">
            <button
              type="button"
              onClick={() => {
                setDoSourceMode('existing');
                setErrorMsg(null);
              }}
              className={`min-h-[40px] rounded-lg px-2 py-1.5 text-[11px] sm:text-xs font-bold transition-colors cursor-pointer ${
                doSourceMode === 'existing'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              পেন্ডিং ডিও ({pendingDos.length})
            </button>
            <button
              type="button"
              onClick={() => {
                setDoSourceMode('distributed');
                setErrorMsg(null);
              }}
              className={`min-h-[40px] rounded-lg px-2 py-1.5 text-[11px] sm:text-xs font-bold transition-colors cursor-pointer ${
                doSourceMode === 'distributed'
                  ? 'bg-white text-emerald-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              বিতরণকৃত ({distributedDos.length})
            </button>
            <button
              type="button"
              onClick={() => {
                setDoSourceMode('new');
                setSelectedDoIds([]);
                setAllocations([]);
                setErrorMsg(null);
              }}
              className={`min-h-[40px] rounded-lg px-2 py-1.5 text-[11px] sm:text-xs font-bold transition-colors cursor-pointer ${
                doSourceMode === 'new'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              + নতুন ডিও
            </button>
            <button
              type="button"
              onClick={() => {
                setDoSourceMode('dispatch');
                setErrorMsg(null);
              }}
              className={`min-h-[40px] rounded-lg px-2 py-1.5 text-[11px] sm:text-xs font-bold transition-colors cursor-pointer ${
                doSourceMode === 'dispatch'
                  ? 'bg-white text-indigo-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              ইনভয়েস / মিল
            </button>
            <button
              type="button"
              onClick={() => {
                setDoSourceMode('bag_shortage');
                setErrorMsg(null);
              }}
              className={`col-span-2 sm:col-span-1 min-h-[40px] rounded-lg px-2 py-1.5 text-[11px] sm:text-xs font-bold transition-colors cursor-pointer ${
                doSourceMode === 'bag_shortage'
                  ? 'bg-white text-amber-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              বস্তা / ঘাটতি
            </button>
          </div>

          {/* MODE A: Category-Grouped Multi-Select Pending DO List */}
          {doSourceMode === 'existing' && (
            <div className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-bold text-slate-700">
                  খাত ও ডিও নির্বাচন — খাতের বক্সে টিক দিলে ওই খাতের সব ডিও মার্ক হবে, অথবা আলাদা আলাদা টিক দিন
                </span>
                <div className="flex items-center gap-2">
                  {onSyncExternalDos && (
                    <button
                      type="button"
                      onClick={onSyncExternalDos}
                      disabled={isSyncingDos}
                      className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 px-2.5 py-1 text-[11px] font-bold text-slate-700 cursor-pointer"
                    >
                      <RefreshCw className={`h-3 w-3 ${isSyncingDos ? 'animate-spin' : ''}`} />
                      <span>{isSyncingDos ? 'সিঙ্ক হচ্ছে...' : 'সিঙ্ক করুন'}</span>
                    </button>
                  )}
                  {pendingDos.length > 0 && (
                    <button
                      type="button"
                      onClick={
                        selectedDoIds.length > 0
                          ? () => applySelectedDos([])
                          : handleSelectAllMatchingProduct
                      }
                      className="text-[11px] font-bold text-emerald-800 hover:underline cursor-pointer"
                    >
                      {selectedDoIds.length > 0 ? 'সব মার্ক বাতিল' : 'একই পণ্যের সব খাত মার্ক করুন'}
                    </button>
                  )}
                </div>
              </div>

              {pendingDos.length > 0 && (
                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setDoProductFilter('all')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border transition-colors cursor-pointer ${
                      doProductFilter === 'all'
                        ? 'bg-slate-900 text-white border-slate-900'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    সব ({pendingDos.length})
                  </button>
                  {PRODUCTS.map((p) => {
                    const count = pendingDos.filter((d) => d.product === p.id).length;
                    if (count === 0) return null;
                    return (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => {
                          setDoProductFilter(p.id);
                          setErrorMsg(null);
                          if (lockedProduct && lockedProduct !== p.id && allocations.length === 0) {
                            setSelectedDoIds([]);
                          }
                        }}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border transition-colors cursor-pointer ${
                          doProductFilter === p.id
                            ? 'bg-slate-900 text-white border-slate-900'
                            : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        {p.shortBn} ({count})
                      </button>
                    );
                  })}
                </div>
              )}

              {displayedPendingDos.length === 0 ? (
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-5 text-center space-y-2">
                  <FileText className="h-7 w-7 text-slate-300 mx-auto" />
                  <p className="text-xs font-semibold text-slate-700">
                    কোনো অপেক্ষমাণ (পেন্ডিং) ডিও নেই
                  </p>
                  <button
                    type="button"
                    onClick={() => setDoSourceMode('new')}
                    className="inline-flex items-center gap-1 rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-bold text-white cursor-pointer"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    <span>নতুন ডিও এন্ট্রি দিন</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {groupedPendingDos.map((grp) => {
                    const compatItems = lockedProduct
                      ? grp.items.filter((d) => d.product === lockedProduct)
                      : grp.items;
                    const selectedInCat = compatItems.filter((d) =>
                      selectedDoIds.includes(d.id)
                    ).length;
                    const allCatSelected =
                      compatItems.length > 0 && selectedInCat === compatItems.length;
                    const someCatSelected = selectedInCat > 0 && !allCatSelected;
                    const grpProductMeta = PRODUCT_MAP[grp.product];
                    const isOtherProductGroup = Boolean(
                      lockedProduct && lockedProduct !== grp.product
                    );

                    const catTotalRemMt = grp.items.reduce(
                      (s, d) => Number((s + Math.max(0, d.totalMt - d.deliveredMt)).toFixed(3)),
                      0
                    );
                    const catTotalRemBags = grp.items.reduce(
                      (s, d) => s + Math.max(0, d.totalBags - d.deliveredBags),
                      0
                    );

                    return (
                      <div
                        key={grp.groupKey}
                        className={`rounded-2xl border overflow-hidden transition-colors ${
                          selectedInCat > 0
                            ? 'border-[#B91C1C]/60 bg-rose-50/20'
                            : isOtherProductGroup
                              ? 'border-slate-200 bg-slate-50/50 opacity-75'
                              : 'border-slate-200 bg-white'
                        }`}
                      >
                        {/* Category Checkbox Header */}
                        <button
                          type="button"
                          onClick={() => handleToggleCategoryGroup(grp.items)}
                          className="w-full px-3.5 py-2.5 bg-slate-50/90 hover:bg-slate-100/90 border-b border-slate-200 flex items-center justify-between gap-2 text-left cursor-pointer"
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <span
                              className={
                                allCatSelected || someCatSelected
                                  ? 'text-[#B91C1C]'
                                  : 'text-slate-400'
                              }
                            >
                              {allCatSelected ? (
                                <CheckSquare className="h-4.5 w-4.5" />
                              ) : someCatSelected ? (
                                <MinusSquare className="h-4.5 w-4.5" />
                              ) : (
                                <Square className="h-4.5 w-4.5" />
                              )}
                            </span>
                            <span className="text-xs sm:text-sm font-extrabold text-slate-900 truncate">
                              {grp.category}
                            </span>
                            <span
                              className={`text-[10px] font-bold px-1.5 py-0.5 rounded border shrink-0 ${grpProductMeta.softBgClass} ${grpProductMeta.textColorClass} ${grpProductMeta.borderColorClass}`}
                            >
                              {grpProductMeta.shortBn}
                            </span>
                            <span className="text-[11px] font-semibold text-slate-500 shrink-0 tabular-nums">
                              ({selectedInCat > 0 ? `${selectedInCat}/` : ''}
                              {grp.items.length}টি ডিও)
                            </span>
                          </div>

                          <div className="text-right text-[11px] font-bold text-slate-800 tabular-nums shrink-0">
                            {catTotalRemMt > 0
                              ? `${formatMetricTons(catTotalRemMt)} মে.টন`
                              : `${formatBags(catTotalRemBags)} বস্তা`}
                          </div>
                        </button>

                        {/* Individual DO Checkboxes inside this Category */}
                        <div className="p-2.5 grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {grp.items.map((d) => {
                            const meta = PRODUCT_MAP[d.product];
                            const remMt = Math.max(0, Number((d.totalMt - d.deliveredMt).toFixed(4)));
                            const remBags = Math.max(0, d.totalBags - d.deliveredBags);
                            const isSelected = selectedDoIds.includes(d.id);
                            const isDifferentProduct = Boolean(
                              lockedProduct && lockedProduct !== d.product
                            );

                            return (
                              <button
                                key={d.id}
                                type="button"
                                onClick={() => handleToggleDo(d)}
                                className={`text-left rounded-xl border p-3 transition-all cursor-pointer ${
                                  isSelected
                                    ? 'border-[#B91C1C] bg-rose-50/70 ring-1 ring-[#B91C1C]'
                                    : isDifferentProduct
                                      ? 'border-slate-200 bg-slate-50/70 opacity-55'
                                      : 'border-slate-200 bg-white hover:border-slate-300'
                                }`}
                              >
                                <div className="flex items-start justify-between gap-2">
                                  <div className="flex items-start gap-2 min-w-0">
                                    <span
                                      className={`mt-0.5 shrink-0 ${
                                        isSelected ? 'text-[#B91C1C]' : 'text-slate-400'
                                      }`}
                                    >
                                      {isSelected ? (
                                        <CheckSquare className="h-4 w-4" />
                                      ) : (
                                        <Square className="h-4 w-4" />
                                      )}
                                    </span>
                                    <div className="min-w-0">
                                      <div className="font-mono text-xs font-extrabold text-slate-900 truncate">
                                        {d.doNumber}
                                      </div>
                                      <div className="text-[11px] font-medium text-slate-600 truncate">
                                        {meta.shortBn}
                                        {d.recipient ? ` · ${d.recipient}` : ''}
                                      </div>
                                    </div>
                                  </div>

                                  <div className="text-right shrink-0 tabular-nums">
                                    <div className="text-xs font-extrabold text-rose-800">
                                      {meta.tracksWeight
                                        ? `${formatMetricTons(remMt)} মে.টন`
                                        : `${formatBags(remBags)} বস্তা`}
                                    </div>
                                    <div className="text-[10px] text-slate-500">
                                      {formatBags(remBags)} বস্তা
                                    </div>
                                  </div>
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* MODE B: Distributed DOs List (বিতরণকৃত ডিও) */}
          {doSourceMode === 'distributed' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-xs sm:text-sm font-bold text-slate-900">
                  বিতরণকৃত ডিও তালিকা ({distributedDos.length}টি)
                </h3>
                <span className="text-[11px] text-slate-500">
                  বিতরণ সম্পন্ন হওয়া ডিও এখানে দেখাবে, পেন্ডিংয়ে আসবে না
                </span>
              </div>

              {distributedDos.length === 0 ? (
                <div className="rounded-xl border border-slate-200 bg-slate-50 p-6 text-center space-y-1.5">
                  <CheckCircle2 className="h-7 w-7 text-slate-300 mx-auto" />
                  <p className="text-xs font-semibold text-slate-700">
                    এখনও কোনো ডিও বিতরণ সম্পন্ন হয়নি
                  </p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  {distributedDos.map((d) => {
                    const meta = PRODUCT_MAP[d.product];
                    return (
                      <div
                        key={d.id}
                        className="rounded-xl border border-emerald-200 bg-emerald-50/35 p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
                      >
                        <div className="flex items-start gap-2.5 min-w-0">
                          <div
                            className={`h-8 w-8 rounded-lg ${meta.softBgClass} ${meta.textColorClass} flex items-center justify-center shrink-0`}
                          >
                            <ProductIcon product={d.product} className="h-4.5 w-4.5" />
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-xs font-extrabold text-slate-900">
                                {d.doNumber}
                              </span>
                              <span className="text-[11px] font-bold text-emerald-800">
                                বিতরণকৃত
                              </span>
                            </div>
                            <div className="text-[11px] text-slate-600 mt-0.5">
                              {meta.nameBn} · {d.category}
                              {d.recipient ? ` · ${d.recipient}` : ''}
                            </div>
                            {d.distributedFrom && d.distributedFrom.length > 0 && (
                              <div className="text-[11px] text-slate-500 mt-0.5 truncate">
                                {d.distributedFrom.join(', ')}
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="text-left sm:text-right shrink-0 tabular-nums">
                          <div className="text-xs font-extrabold text-emerald-800">
                            {meta.tracksWeight
                              ? `${formatMetricTons(d.deliveredMt)} মে.টন`
                              : `${formatBags(d.deliveredBags)} বস্তা`}
                          </div>
                          <div className="text-[10px] font-mono text-slate-500">
                            {d.distributedAt ? d.distributedAt.slice(0, 10) : d.date}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* MODE C: New / Ad-hoc DO Entry */}
          {doSourceMode === 'new' && (
            <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-4 space-y-4">
              <div>
                <div className="text-xs font-semibold text-slate-700 mb-2">
                  পণ্য নির্বাচন করুন
                </div>
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                  {PRODUCTS.map((item) => {
                    const active = product === item.id;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => {
                          setProduct(item.id);
                          setAllocations([]);
                        }}
                        className={`min-h-[58px] rounded-xl border p-2 flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer ${
                          active
                            ? 'border-slate-900 bg-slate-900 text-white'
                            : 'border-slate-200 bg-white text-slate-800 hover:bg-slate-50'
                        }`}
                      >
                        <ProductIcon
                          product={item.id}
                          className={`h-5 w-5 ${active ? 'text-white' : item.textColorClass}`}
                        />
                        <span className="text-[11px] font-bold text-center leading-tight">
                          {item.shortBn}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="new-do-no" className="block text-xs font-semibold text-slate-700 mb-1">
                    ডিও নম্বর (DO No.) <span className="text-rose-600">*</span>
                  </label>
                  <input
                    id="new-do-no"
                    type="text"
                    value={newDoNumber}
                    onChange={(e) => setNewDoNumber(e.target.value)}
                    placeholder="যেমন: DO-2026-0510"
                    className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 font-mono text-xs text-slate-900 focus:border-rose-700 focus:outline-none"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <label htmlFor="new-do-cat" className="block text-xs font-semibold text-slate-700">
                      বিতরণ ক্যাটাগরি / খাত <span className="text-rose-600">*</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => onOpenChannelSettings(product, 'distribution')}
                      className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 hover:underline cursor-pointer"
                    >
                      <Settings2 className="h-3 w-3" />
                      <span>সেটিংস</span>
                    </button>
                  </div>
                  <select
                    id="new-do-cat"
                    value={category}
                    onChange={(e) => {
                      const chosen = e.target.value;
                      setCategory(chosen);
                      if (product === 'rice' || product === 'wheat') {
                        const inferred = inferDefaultProductFromCategory(chosen);
                        if (inferred !== product) {
                          setProduct(inferred);
                          setAllocations([]);
                        }
                      }
                    }}
                    className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-900 focus:border-rose-700 focus:outline-none"
                  >
                    {availableDistCategories.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                {activeMeta.tracksWeight && (
                  <div>
                    <label htmlFor="new-do-mt" className="block text-xs font-semibold text-slate-700 mb-1">
                      ডিও মোট পরিমাণ (মেট্রিক টন)
                    </label>
                    <input
                      id="new-do-mt"
                      type="number"
                      inputMode="decimal"
                      step="0.001"
                      min="0"
                      value={targetMtInput}
                      onChange={(e) => {
                        setTargetMtInput(e.target.value);
                        const mtVal = Number(e.target.value) || 0;
                        setAllocations((prev) =>
                          recomputeAllocations(
                            prev,
                            mtVal,
                            Number(targetBagsInput) || 0,
                            activeMeta.tracksWeight
                          )
                        );
                      }}
                      placeholder="যেমন: 10.000"
                      className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 font-mono tabular-nums text-sm text-slate-900 focus:border-rose-700 focus:outline-none"
                    />
                  </div>
                )}

                <div>
                  <label htmlFor="new-do-bags" className="block text-xs font-semibold text-slate-700 mb-1">
                    ডিও মোট বস্তা
                  </label>
                  <input
                    id="new-do-bags"
                    type="number"
                    inputMode="numeric"
                    min="0"
                    value={targetBagsInput}
                    onChange={(e) => {
                      setTargetBagsInput(e.target.value);
                      const bVal = Math.round(Number(e.target.value) || 0);
                      setAllocations((prev) =>
                        recomputeAllocations(
                          prev,
                          Number(targetMtInput) || 0,
                          bVal,
                          activeMeta.tracksWeight
                        )
                      );
                    }}
                    placeholder="যেমন: 200"
                    className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 font-mono tabular-nums text-sm text-slate-900 focus:border-rose-700 focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="new-do-rec" className="block text-xs font-semibold text-slate-700 mb-1">
                    প্রাপক / ইউনিয়ন / ডিলার (ঐচ্ছিক)
                  </label>
                  <input
                    id="new-do-rec"
                    type="text"
                    value={recipient}
                    onChange={(e) => setRecipient(e.target.value)}
                    placeholder="যেমন: সদর ইউনিয়ন"
                    className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-rose-700 focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="new-do-date" className="block text-xs font-semibold text-slate-700 mb-1">
                    বিতরণের তারিখ
                  </label>
                  <input
                    id="new-do-date"
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 font-mono text-xs text-slate-900 focus:border-rose-700 focus:outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Date & Note strip when using Existing Pending DO */}
          {doSourceMode === 'existing' && selectedDos.length > 0 && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 rounded-xl border border-slate-200 bg-slate-50/70 p-3.5">
              <div>
                <label htmlFor="existing-do-date" className="block text-[11px] font-semibold text-slate-600 mb-1">
                  বিতরণের তারিখ
                </label>
                <input
                  id="existing-do-date"
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full min-h-[40px] rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-mono text-xs text-slate-900 focus:border-rose-700 focus:outline-none"
                />
              </div>
              <div>
                <label htmlFor="existing-do-note" className="block text-[11px] font-semibold text-slate-600 mb-1">
                  রেফারেন্স / মন্তব্য (ঐচ্ছিক)
                </label>
                <input
                  id="existing-do-note"
                  type="text"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="যেমন: চালান বা প্রাপকের নাম"
                  className="w-full min-h-[40px] rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs text-slate-900 focus:border-rose-700 focus:outline-none"
                />
              </div>
            </div>
          )}

          {/* LIVE MULTI-CATEGORY DO PROGRESS STRIP */}
          {showAllocationWorkspace && (doSourceMode === 'new' || selectedDos.length > 0) && (
            <div className="rounded-2xl border border-slate-200 bg-slate-900 text-white p-4 space-y-2.5">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="font-bold">
                  {doSourceMode === 'existing'
                    ? `${selectedCategoryCount}টি খাত · ${selectedDos.length}টি ডিও (${selectedDos.map((d) => d.doNumber).join(', ')})`
                    : newDoNumber
                      ? `ডিও: ${newDoNumber}`
                      : 'নতুন ডিও'}{' '}
                  <span className="text-slate-400">·</span>{' '}
                  <span className="text-emerald-300">{activeMeta.nameBn}</span>
                </div>
                {doRemainingTargetMt > 0 && (
                  <div className="font-mono tabular-nums text-xs">
                    আরও প্রয়োজন:{' '}
                    <strong
                      className={
                        allocationTotals.stillNeededMt > 0 ? 'text-amber-300' : 'text-emerald-300'
                      }
                    >
                      {allocationTotals.stillNeededMt > 0
                        ? `${formatMetricTons(allocationTotals.stillNeededMt)} মে.টন`
                        : '✓ সম্পূর্ণ কভার'}
                    </strong>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-3 gap-2 pt-1 text-xs tabular-nums border-t border-slate-800">
                <div>
                  <div className="text-[11px] text-slate-400">মোট ডিও প্রাপ্য</div>
                  <div className="font-bold">
                    {activeMeta.tracksWeight
                      ? `${formatMetricTons(doRemainingTargetMt)} মে.টন (${formatBags(doRemainingTargetBags)} বস্তা)`
                      : `${formatBags(doRemainingTargetBags)} বস্তা`}
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-400">খামাল থেকে কভার</div>
                  <div className="font-bold text-emerald-300">
                    {activeMeta.tracksWeight
                      ? `${formatMetricTons(allocationTotals.deliveredMt)} মে.টন (${formatBags(allocationTotals.deliveredBags)} বস্তা)`
                      : `${formatBags(allocationTotals.deliveredBags)} বস্তা`}
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-slate-400">খামাল শর্টেজ (ঘাটতি)</div>
                  <div className="font-bold text-amber-300">
                    {activeMeta.tracksWeight
                      ? `${formatMetricTons(allocationTotals.shortageMt)} মে.টন`
                      : `${formatBags(allocationTotals.shortageBags)} বস্তা`}
                  </div>
                </div>
              </div>

              {allocations.length > 0 && (
                <div className="pt-2.5 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2">
                  <span className="text-[11px] text-slate-300">
                    মোট বস্তা দিলে খামাল অনুযায়ী স্বয়ংক্রিয় ভাগ হবে:
                  </span>
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      inputMode="numeric"
                      min="0"
                      value={autoTotalBagsInput}
                      onChange={(e) => handleSplitBagsProportionally(e.target.value)}
                      placeholder="যেমন: 200"
                      className="w-28 min-h-[34px] rounded-lg border border-slate-700 bg-slate-950 px-2.5 py-1 font-mono tabular-nums text-xs font-bold text-white focus:border-emerald-400 focus:outline-none"
                    />
                    <span className="text-[11px] text-slate-400">বস্তা</span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ALLOCATED KHAMALS */}
          {showAllocationWorkspace && allocations.length > 0 && (
            <div className="space-y-3">
              <div className="text-xs font-bold text-slate-800">
                মার্ককৃত খামালসমূহ ({allocations.length}টি খামাল)
              </div>

              {allocations.map((alloc, idx) => {
                const shMt = getShortageMt(alloc);
                const shBags = getShortageBags(alloc);
                const netAvailMt = Math.max(0, Number((alloc.availMt - shMt).toFixed(4)));
                const netAvailBags = Math.max(0, alloc.availBags - shBags);

                return (
                  <div
                    key={alloc.key}
                    className="rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 space-y-3 shadow-xs"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="text-sm font-extrabold text-slate-900">
                          {idx + 1}. {alloc.godownNo} / {alloc.khamalNo}
                        </div>
                        <div className="text-xs text-slate-500 tabular-nums mt-0.5">
                          খামালের বই-মজুদ:{' '}
                          <strong className="text-slate-800">
                            {activeMeta.tracksWeight
                              ? `${formatMetricTons(alloc.availMt)} মে.টন`
                              : `${formatBags(alloc.availBags)} বস্তা`}
                          </strong>
                          {activeMeta.tracksWeight && ` (${formatBags(alloc.availBags)} বস্তা)`}
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleRemoveAllocation(alloc.key)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer"
                        aria-label="খামাল বাদ দিন"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>

                    {/* Shortage Toggle & Inputs */}
                    <div className="rounded-xl border border-amber-200/80 bg-amber-50/50 p-3 space-y-2.5">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 text-xs font-bold text-amber-950">
                          <AlertTriangle className="h-3.5 w-3.5 text-amber-700" />
                          <span>এই খামালে শর্টেজ (ঘাটতি) আছে কি?</span>
                        </div>

                        <div className="flex items-center gap-1 p-0.5 rounded-lg bg-white border border-amber-200">
                          <button
                            type="button"
                            onClick={() =>
                              handleUpdateAllocation(alloc.key, {
                                hasShortage: false,
                                shortageValue: '',
                                shortageBags: '',
                                manualOverride: false,
                              })
                            }
                            className={`px-2.5 py-1 rounded-md text-[11px] font-bold cursor-pointer ${
                              !alloc.hasShortage
                                ? 'bg-slate-900 text-white'
                                : 'text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            শর্টেজ নেই
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              handleUpdateAllocation(alloc.key, {
                                hasShortage: true,
                                manualOverride: false,
                              })
                            }
                            className={`px-2.5 py-1 rounded-md text-[11px] font-bold cursor-pointer ${
                              alloc.hasShortage
                                ? 'bg-amber-600 text-white'
                                : 'text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            শর্টেজ আছে
                          </button>
                        </div>
                      </div>

                      {alloc.hasShortage && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                          {activeMeta.tracksWeight && (
                            <div>
                              <div className="flex items-center justify-between mb-1">
                                <label className="text-[11px] font-semibold text-amber-950">
                                  শর্টেজ ওজন ({alloc.shortageUnit === 'kg' ? 'কেজি' : 'মে.টন'})
                                </label>
                                <div className="flex items-center gap-1 text-[10px]">
                                  <button
                                    type="button"
                                    onClick={() =>
                                      handleUpdateAllocation(alloc.key, { shortageUnit: 'kg' })
                                    }
                                    className={`px-1.5 py-0.5 rounded font-bold cursor-pointer ${
                                      alloc.shortageUnit === 'kg'
                                        ? 'bg-amber-700 text-white'
                                        : 'bg-white text-amber-900 border border-amber-200'
                                    }`}
                                  >
                                    কেজি
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() =>
                                      handleUpdateAllocation(alloc.key, { shortageUnit: 'mt' })
                                    }
                                    className={`px-1.5 py-0.5 rounded font-bold cursor-pointer ${
                                      alloc.shortageUnit === 'mt'
                                        ? 'bg-amber-700 text-white'
                                        : 'bg-white text-amber-900 border border-amber-200'
                                    }`}
                                  >
                                    মে.টন
                                  </button>
                                </div>
                              </div>
                              <input
                                type="number"
                                inputMode="decimal"
                                min="0"
                                step={alloc.shortageUnit === 'kg' ? '1' : '0.001'}
                                value={alloc.shortageValue}
                                onChange={(e) =>
                                  handleUpdateAllocation(alloc.key, {
                                    shortageValue: e.target.value,
                                    manualOverride: false,
                                  })
                                }
                                placeholder={alloc.shortageUnit === 'kg' ? 'যেমন: 500' : 'যেমন: 0.500'}
                                className="w-full min-h-[38px] rounded-lg border border-amber-300 bg-white px-2.5 py-1.5 font-mono tabular-nums text-xs text-slate-900 focus:border-amber-700 focus:outline-none"
                              />
                              {shMt > 0 && (
                                <div className="mt-1 text-[11px] font-semibold text-amber-900 tabular-nums">
                                  শর্টেজ: {formatMetricTons(shMt)} মে.টন · নিট প্রাপ্য:{' '}
                                  {formatMetricTons(netAvailMt)} মে.টন (বাকি অংশ পরের খামাল থেকে নিন)
                                </div>
                              )}
                            </div>
                          )}

                          <div>
                            <label className="block text-[11px] font-semibold text-amber-950 mb-1">
                              শর্টেজ বস্তা (যদি থাকে)
                            </label>
                            <input
                              type="number"
                              inputMode="numeric"
                              min="0"
                              value={alloc.shortageBags}
                              onChange={(e) =>
                                handleUpdateAllocation(alloc.key, {
                                  shortageBags: e.target.value,
                                  manualOverride: false,
                                })
                              }
                              placeholder="0"
                              className="w-full min-h-[38px] rounded-lg border border-amber-300 bg-white px-2.5 py-1.5 font-mono tabular-nums text-xs text-slate-900 focus:border-amber-700 focus:outline-none"
                            />
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Deliverable Amount from this Khamal */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {activeMeta.tracksWeight && (
                        <div>
                          <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                            এই খামাল থেকে ডিও-তে ডেলিভারি (মে.টন)
                          </label>
                          <input
                            type="number"
                            inputMode="decimal"
                            min="0"
                            max={netAvailMt}
                            step="0.001"
                            value={alloc.deliveredMt}
                            onChange={(e) =>
                              handleUpdateAllocation(
                                alloc.key,
                                { deliveredMt: e.target.value, manualOverride: true },
                                false
                              )
                            }
                            className="w-full min-h-[40px] rounded-lg border border-slate-300 bg-slate-50/40 px-2.5 py-1.5 font-mono tabular-nums text-sm font-bold text-slate-900 focus:bg-white focus:border-rose-700 focus:outline-none"
                          />
                        </div>
                      )}

                      <div>
                        <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                          এই খামাল থেকে ডেলিভারি (বস্তা)
                        </label>
                        <input
                          type="number"
                          inputMode="numeric"
                          min="0"
                          max={netAvailBags}
                          value={alloc.deliveredBags}
                          onChange={(e) =>
                            handleUpdateAllocation(
                              alloc.key,
                              { deliveredBags: e.target.value, manualOverride: true },
                              false
                            )
                          }
                          className="w-full min-h-[40px] rounded-lg border border-slate-300 bg-slate-50/40 px-2.5 py-1.5 font-mono tabular-nums text-sm font-bold text-slate-900 focus:bg-white focus:border-rose-700 focus:outline-none"
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Available Khamals Picker Below DO */}
          {showAllocationWorkspace && (
            <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-slate-900">
                    {activeMeta.nameBn}-এর মজুদ থাকা খামালসমূহ (প্রয়োজন অনুযায়ী একাধিক খামাল মার্ক করুন)
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    {allocationTotals.stillNeededMt > 0
                      ? `আরও ${formatMetricTons(allocationTotals.stillNeededMt)} মে.টন (${formatBags(allocationTotals.stillNeededBags)} বস্তা) প্রয়োজন — পরবর্তী খামাল মার্ক করুন`
                      : 'বিতরণের জন্য নিচের তালিকা থেকে এক বা একাধিক খামাল নির্বাচন করুন'}
                  </p>
                </div>
              </div>

              {availableKhamals.length === 0 ? (
                <div className="rounded-xl border border-slate-200 bg-white p-4 text-center text-xs text-slate-500">
                  এই পণ্যের কোনো অবশিষ্ট খামাল মজুদ নেই।
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {availableKhamals.map((k) => (
                    <button
                      key={k.key}
                      type="button"
                      onClick={() => handleAddKhamal(k)}
                      className="rounded-xl border border-slate-200 bg-white hover:border-[#0D6E4E] hover:bg-emerald-50/30 p-3 flex items-center justify-between gap-2 text-left transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <Square className="h-4 w-4 text-slate-400 shrink-0" />
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-slate-900 truncate">
                            {k.godownNo} / {k.khamalNo}
                          </div>
                          <div className="text-[11px] text-slate-500 tabular-nums">
                            {activeMeta.tracksWeight
                              ? `${formatMetricTons(k.currentMt)} মে.টন · ${formatBags(k.currentBags)} বস্তা`
                              : `${formatBags(k.currentBags)} বস্তা`}
                          </div>
                        </div>
                      </div>
                      <span className="px-2.5 py-1 rounded-lg bg-slate-900 text-white text-[11px] font-bold whitespace-nowrap shrink-0">
                        + মার্ক করুন
                      </span>
                    </button>
                  ))}
                </div>
              )}

              {doSourceMode === 'existing' && selectedDos.length > 0 && allocations.length > 0 && (
                <label className="pt-2 border-t border-slate-200 flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={forceMarkCompleted}
                    onChange={(e) => setForceMarkCompleted(e.target.checked)}
                    className="h-4 w-4 rounded border-slate-300 accent-emerald-700"
                  />
                  <span>
                    আংশিক ডেলিভারি হলেও নির্বাচিত ডিওগুলো পেন্ডিং থেকে সরিয়ে বিতরণকৃত তালিকায় নিন
                  </span>
                </label>
              )}
            </div>
          )}

          {/* MODE D: MULTI-KHAMAL DISPATCH (ইনভয়েস চাল / মিল ধান ক্রাশিং) */}
          {doSourceMode === 'dispatch' && (
            <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-4 space-y-4">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                <Truck className="h-4 w-4 text-indigo-700" />
                <span>ইনভয়েস (অন্য কেন্দ্রে প্রেরণ) ও মিল (ধান ক্রাশিং) — একাধিক খামাল থেকে</span>
              </div>

              <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-white border border-slate-200">
                <button
                  type="button"
                  onClick={() => {
                    setDispatchType('Invoice');
                    setDispatchAllocations([]);
                  }}
                  className={`min-h-[40px] rounded-lg text-xs font-bold cursor-pointer ${
                    dispatchType === 'Invoice'
                      ? 'bg-indigo-700 text-white'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  ইনভয়েস প্রেরণ (চাল / গম)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setDispatchType('Mill');
                    setDispatchAllocations([]);
                  }}
                  className={`min-h-[40px] rounded-lg text-xs font-bold cursor-pointer ${
                    dispatchType === 'Mill'
                      ? 'bg-amber-700 text-white'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  মিলে প্রেরণ / ক্রাশিং (ধান)
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="disp-doc" className="block text-xs font-semibold text-slate-700 mb-1">
                    {dispatchType === 'Invoice' ? 'ইনভয়েস নম্বর' : 'মিল ডেলিভারি / ক্রাশিং নং'}{' '}
                    <span className="text-rose-600">*</span>
                  </label>
                  <input
                    id="disp-doc"
                    type="text"
                    value={dispatchDocNo}
                    onChange={(e) => setDispatchDocNo(e.target.value)}
                    placeholder={dispatchType === 'Invoice' ? 'যেমন: INV-2026-09' : 'যেমন: MILL-04'}
                    className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 font-mono text-xs text-slate-900 focus:border-indigo-700 focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="disp-party" className="block text-xs font-semibold text-slate-700 mb-1">
                    {dispatchType === 'Invoice' ? 'প্রাপক কেন্দ্র / এলএসডি' : 'মিলারের / রাইস মিলের নাম'}{' '}
                    <span className="text-rose-600">*</span>
                  </label>
                  <input
                    id="disp-party"
                    type="text"
                    value={dispatchParty}
                    onChange={(e) => setDispatchParty(e.target.value)}
                    placeholder={
                      dispatchType === 'Invoice' ? 'যেমন: সদর এলএসডি' : 'যেমন: মেসার্স পদ্মা অটো রাইস মিল'
                    }
                    className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs text-slate-900 focus:border-indigo-700 focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="disp-tot-mt" className="block text-xs font-semibold text-slate-700 mb-1">
                    মোট প্রেরণ পরিমাণ (মে.টন)
                  </label>
                  <input
                    id="disp-tot-mt"
                    type="number"
                    inputMode="decimal"
                    step="0.001"
                    min="0"
                    value={dispatchTotalWeight}
                    onChange={(e) => {
                      setDispatchTotalWeight(e.target.value);
                      const mtVal = Number(e.target.value) || 0;
                      setDispatchAllocations((prev) =>
                        recomputeAllocations(prev, mtVal, Math.round(Number(dispatchTotalBags) || 0), true)
                      );
                    }}
                    placeholder="যেমন: 10.000"
                    className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 font-mono tabular-nums text-sm font-bold text-slate-900 focus:border-indigo-700 focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="disp-tot-bags" className="block text-xs font-semibold text-slate-700 mb-1">
                    মোট বস্তা সংখ্যা
                  </label>
                  <input
                    id="disp-tot-bags"
                    type="number"
                    inputMode="numeric"
                    min="0"
                    value={dispatchTotalBags}
                    onChange={(e) => {
                      setDispatchTotalBags(e.target.value);
                      const bVal = Math.round(Number(e.target.value) || 0);
                      setDispatchAllocations((prev) =>
                        recomputeAllocations(prev, Number(dispatchTotalWeight) || 0, bVal, true)
                      );
                    }}
                    placeholder="যেমন: 200"
                    className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 font-mono tabular-nums text-sm font-bold text-slate-900 focus:border-indigo-700 focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="disp-date" className="block text-xs font-semibold text-slate-700 mb-1">
                    প্রেরণের তারিখ
                  </label>
                  <input
                    id="disp-date"
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 font-mono text-xs text-slate-900 focus:border-indigo-700 focus:outline-none"
                  />
                </div>

                <div>
                  <label htmlFor="disp-ref" className="block text-xs font-semibold text-slate-700 mb-1">
                    রেফারেন্স / গাড়ি নং (ঐচ্ছিক)
                  </label>
                  <input
                    id="disp-ref"
                    type="text"
                    value={dispatchRef}
                    onChange={(e) => setDispatchRef(e.target.value)}
                    placeholder="যানবাহন নং বা অতিরিক্ত তথ্য"
                    className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs text-slate-900 focus:border-indigo-700 focus:outline-none"
                  />
                </div>
              </div>

              {/* Selected khamals for Dispatch */}
              {dispatchAllocations.length > 0 && (
                <div className="space-y-2">
                  <div className="text-xs font-bold text-slate-800">
                    নির্বাচিত খামাল ({dispatchAllocations.length}টি) · মোট: {formatMetricTons(dispatchTotals.mt)} মে.টন ({formatBags(dispatchTotals.bags)} বস্তা)
                  </div>
                  {dispatchAllocations.map((a) => (
                    <div
                      key={a.key}
                      className="rounded-xl border border-slate-200 bg-white p-3 space-y-2"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="text-xs font-bold text-slate-900">
                          {a.godownNo} / {a.khamalNo}{' '}
                          <span className="font-normal text-slate-500">
                            (মজুদ: {a.availMt.toFixed(3)} মে.টন · {a.availBags} বস্তা)
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() =>
                            setDispatchAllocations((prev) => prev.filter((x) => x.key !== a.key))
                          }
                          className="p-1 text-slate-400 hover:text-rose-600 cursor-pointer"
                          aria-label="বাদ দিন"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[10px] text-slate-500 mb-0.5">ওজন (মে.টন)</label>
                          <input
                            type="number"
                            step="0.001"
                            min="0"
                            max={a.availMt}
                            value={a.deliveredMt}
                            onChange={(e) =>
                              handleUpdateDispatchAlloc(a.key, {
                                deliveredMt: e.target.value,
                                manualOverride: true,
                              })
                            }
                            className="w-full min-h-[36px] rounded-lg border border-slate-300 px-2.5 font-mono text-xs font-bold text-slate-900"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-slate-500 mb-0.5">বস্তা</label>
                          <input
                            type="number"
                            min="0"
                            max={a.availBags}
                            value={a.deliveredBags}
                            onChange={(e) =>
                              handleUpdateDispatchAlloc(a.key, {
                                deliveredBags: e.target.value,
                                manualOverride: true,
                              })
                            }
                            className="w-full min-h-[36px] rounded-lg border border-slate-300 px-2.5 font-mono text-xs font-bold text-slate-900"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Additional khamal picker for Dispatch overflow */}
              {dispatchCandidateKhamals.length > 0 && (
                <div className="space-y-1.5">
                  <div className="text-[11px] font-bold text-slate-600">
                    আরও খামাল যুক্ত করুন (প্রয়োজনে একাধিক খামাল মার্ক করুন):
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {dispatchCandidateKhamals.map((k) => (
                      <button
                        key={k.key}
                        type="button"
                        onClick={() => handleAddDispatchKhamal(k)}
                        className="rounded-xl border border-slate-200 bg-white hover:border-indigo-500 p-2.5 flex items-center justify-between text-left cursor-pointer"
                      >
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-slate-900 truncate">
                            {k.godownNo} / {k.khamalNo} ({PRODUCT_MAP[k.product].shortBn})
                          </div>
                          <div className="text-[11px] text-slate-500 tabular-nums">
                            {k.currentMt.toFixed(3)} মে.টন · {k.currentBags} বস্তা
                          </div>
                        </div>
                        <span className="px-2 py-0.5 rounded bg-slate-900 text-white text-[10px] font-bold">
                          + যুক্ত
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* MODE E: EMPTY BAG ISSUE OR ANYTIME SHORTAGE + CASCADE ADJUSTMENT */}
          {doSourceMode === 'bag_shortage' && (
            <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-4 space-y-4">
              <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-white border border-slate-200">
                <button
                  type="button"
                  onClick={() => setOtherSubMode('empty_bag')}
                  className={`min-h-[40px] rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer ${
                    otherSubMode === 'empty_bag'
                      ? 'bg-slate-900 text-white'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <PackageMinus className="h-3.5 w-3.5" />
                  <span>খালি বস্তা বিতরণ</span>
                </button>
                <button
                  type="button"
                  onClick={() => setOtherSubMode('shortage')}
                  className={`min-h-[40px] rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer ${
                    otherSubMode === 'shortage'
                      ? 'bg-amber-600 text-white'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <AlertTriangle className="h-3.5 w-3.5" />
                  <span>খামাল ঘাটতি এন্ট্রি</span>
                </button>
              </div>

              {otherSubMode === 'empty_bag' ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="eb-type" className="block text-xs font-semibold text-slate-700 mb-1">
                      বস্তার ধরন
                    </label>
                    <select
                      id="eb-type"
                      value={bagType}
                      onChange={(e) => setBagType(e.target.value)}
                      className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm font-semibold text-slate-900 focus:border-slate-900 focus:outline-none"
                    >
                      <option value="৫০ কেজির বস্তা">৫০ কেজির বস্তা</option>
                      <option value="৩০ কেজির বস্তা">৩০ কেজির বস্তা</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="eb-godown" className="block text-xs font-semibold text-slate-700 mb-1">
                      গুদাম নং
                    </label>
                    <input
                      id="eb-godown"
                      type="text"
                      list="dist-godowns"
                      value={bagGodown}
                      onChange={(e) => setBagGodown(e.target.value)}
                      className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-slate-900 focus:outline-none"
                    />
                    <datalist id="dist-godowns">
                      {godownList.map((g) => (
                        <option key={g} value={g} />
                      ))}
                    </datalist>
                  </div>

                  <div>
                    <label htmlFor="eb-qty" className="block text-xs font-semibold text-slate-700 mb-1">
                      বিতরণকৃত বস্তার সংখ্যা <span className="text-rose-600">*</span>
                    </label>
                    <input
                      id="eb-qty"
                      type="number"
                      inputMode="numeric"
                      min="1"
                      value={bagQty}
                      onChange={(e) => setBagQty(e.target.value)}
                      placeholder="যেমন: 100"
                      className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 font-mono tabular-nums text-sm font-bold text-slate-900 focus:border-slate-900 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label htmlFor="eb-khamal" className="block text-xs font-semibold text-slate-700 mb-1">
                      সংশ্লিষ্ট খামাল / বাবদ (ঐচ্ছিক)
                    </label>
                    <input
                      id="eb-khamal"
                      type="text"
                      value={bagKhamalNo}
                      onChange={(e) => setBagKhamalNo(e.target.value)}
                      placeholder="যেমন: খামাল-০৫"
                      className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs text-slate-900 focus:border-slate-900 focus:outline-none"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label htmlFor="eb-date" className="block text-xs font-semibold text-slate-700 mb-1">
                      তারিখ
                    </label>
                    <input
                      id="eb-date"
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 font-mono text-xs text-slate-900 focus:border-slate-900 focus:outline-none"
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="rounded-xl border border-amber-200 bg-amber-50/70 p-3 text-xs text-amber-950">
                    যেকোনো সময় (বিতরণ, ইনভয়েস বা মিল ক্রাশিংয়ের আগে বা পরে) খামালের ঘাটতি এন্ট্রি দিতে পারবেন। বর্তমান মজুদের চেয়ে বেশি ঘাটতি হলে আগের ডিও, ইনভয়েস বা মিল প্রেরণ স্বয়ংক্রিয়ভাবে আপডেট হয়ে <strong>পরবর্তী খামালে</strong> অ্যাডজাস্ট হবে।
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="sm:col-span-2">
                      <label htmlFor="disc-khamal" className="block text-xs font-semibold text-slate-700 mb-1">
                        কোন খামালে ঘাটতি? <span className="text-rose-600">*</span>
                      </label>
                      <select
                        id="disc-khamal"
                        value={discKhamalKey}
                        onChange={(e) => {
                          setDiscKhamalKey(e.target.value);
                          setPreferredNextKeys([]);
                        }}
                        className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs font-semibold text-slate-900 focus:border-amber-700 focus:outline-none"
                      >
                        {grainKhamals.length === 0 ? (
                          <option value="">কোনো খামাল পাওয়া যায়নি</option>
                        ) : (
                          grainKhamals.map((k) => (
                            <option key={k.key} value={k.key}>
                              {k.godownNo} / খামাল {k.khamalNo} ({PRODUCT_MAP[k.product].shortBn} · অবশিষ্ট: {k.currentMt.toFixed(3)} মে.টন, {k.currentBags} বস্তা · বিতরণ: {k.distMt.toFixed(3)} মে.টন)
                            </option>
                          ))
                        )}
                      </select>

                      {selectedShortageKhamal && (
                        <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-slate-600 tabular-nums">
                          <span>
                            মোট প্রাপ্তি:{' '}
                            <strong className="text-slate-800">
                              {selectedShortageKhamal.receiptMt.toFixed(3)} মে.টন ({selectedShortageKhamal.receiptBags} বস্তা)
                            </strong>
                          </span>
                          <span>·</span>
                          <span>
                            ইতিমধ্যে বিতরণ/প্রেরণ:{' '}
                            <strong className="text-rose-700">
                              {selectedShortageKhamal.distMt.toFixed(3)} মে.টন ({selectedShortageKhamal.distBags} বস্তা)
                            </strong>
                          </span>
                          <span>·</span>
                          <span>
                            বর্তমান অবশিষ্ট:{' '}
                            <strong className="text-emerald-800">
                              {selectedShortageKhamal.currentMt.toFixed(3)} মে.টন ({selectedShortageKhamal.currentBags} বস্তা)
                            </strong>
                          </span>
                        </div>
                      )}
                    </div>

                    <div>
                      <label htmlFor="disc-weight" className="block text-xs font-semibold text-slate-700 mb-1">
                        ঘাটতি ওজন (মে.টন) <span className="text-rose-600">*</span>
                      </label>
                      <input
                        id="disc-weight"
                        type="number"
                        inputMode="decimal"
                        step="0.001"
                        min="0"
                        value={discWeight}
                        onChange={(e) => setDiscWeight(e.target.value)}
                        placeholder="যেমন: 0.250"
                        className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 font-mono tabular-nums text-sm font-bold text-slate-900 focus:border-amber-700 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label htmlFor="disc-bags" className="block text-xs font-semibold text-slate-700 mb-1">
                        ঘাটতি বস্তা (ঐচ্ছিক)
                      </label>
                      <input
                        id="disc-bags"
                        type="number"
                        inputMode="numeric"
                        min="0"
                        value={discBags}
                        onChange={(e) => setDiscBags(e.target.value)}
                        placeholder="0"
                        className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 font-mono tabular-nums text-sm font-bold text-slate-900 focus:border-amber-700 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label htmlFor="disc-date" className="block text-xs font-semibold text-slate-700 mb-1">
                        তারিখ
                      </label>
                      <input
                        id="disc-date"
                        type="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 font-mono text-xs text-slate-900 focus:border-amber-700 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label htmlFor="disc-remarks" className="block text-xs font-semibold text-slate-700 mb-1">
                        কারণ / মন্তব্য
                      </label>
                      <input
                        id="disc-remarks"
                        type="text"
                        value={discRemarks}
                        onChange={(e) => setDiscRemarks(e.target.value)}
                        placeholder="যেমন: শুকনা ঘাটতি / ছিদ্র"
                        className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs text-slate-900 focus:border-amber-700 focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* LIVE CASCADE ADJUSTMENT PREVIEW */}
                  {shortageCascadePlan &&
                    (shortageCascadePlan.overdrawMt > 0.0001 ||
                      shortageCascadePlan.overdrawBags > 0) && (
                      <div className="rounded-xl border border-amber-300 bg-white p-3.5 space-y-3">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="text-xs font-extrabold text-amber-900">
                            পরবর্তী খামালে অটো-অ্যাডজাস্টমেন্ট ({formatMetricTons(shortageCascadePlan.overdrawMt)} মে.টন · {formatBags(shortageCascadePlan.overdrawBags)} বস্তা)
                          </div>
                          <label className="flex items-center gap-1.5 text-[11px] font-bold text-slate-800 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={autoCascadeEnabled}
                              onChange={(e) => setAutoCascadeEnabled(e.target.checked)}
                              className="h-3.5 w-3.5 accent-amber-700"
                            />
                            <span>পরের খামালে অ্যাডজাস্ট চালু</span>
                          </label>
                        </div>

                        {autoCascadeEnabled && (
                          <>
                            {shortageCascadePlan.candidateNextKhamals.length > 0 && (
                              <div className="space-y-1.5">
                                <div className="text-[11px] font-semibold text-slate-600">
                                  কোন পরবর্তী খামাল থেকে সমন্বয় হবে? (না দিলে স্বয়ংক্রিয়ভাবে পরের খামাল নেবে)
                                </div>
                                <div className="flex flex-wrap gap-1.5">
                                  {shortageCascadePlan.candidateNextKhamals.map((ck) => {
                                    const picked = preferredNextKeys.includes(ck.key);
                                    return (
                                      <button
                                        key={ck.key}
                                        type="button"
                                        onClick={() => handleTogglePreferredNextKhamal(ck.key)}
                                        className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold cursor-pointer ${
                                          picked
                                            ? 'bg-slate-900 text-white border-slate-900'
                                            : 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-slate-100'
                                        }`}
                                      >
                                        {ck.godownNo} / {ck.khamalNo} ({ck.currentMt.toFixed(3)} মে.টন · {ck.currentBags} বস্তা)
                                      </button>
                                    );
                                  })}
                                </div>
                              </div>
                            )}

                            {shortageCascadePlan.shifts.length > 0 && (
                              <div className="space-y-1.5 pt-2 border-t border-slate-100">
                                <div className="text-[11px] font-bold text-emerald-900">
                                  যেসকল বিতরণ / প্রেরণ আপডেট হয়ে পরের খামালে যুক্ত হবে:
                                </div>
                                <div className="space-y-1">
                                  {shortageCascadePlan.shifts.map((sh, i) => (
                                    <div
                                      key={`${sh.recordId}-${i}`}
                                      className="rounded-lg bg-emerald-50/70 border border-emerald-200 px-2.5 py-1.5 text-[11px] text-slate-800 flex flex-wrap items-center justify-between gap-2 tabular-nums"
                                    >
                                      <span className="font-semibold">{sh.label}</span>
                                      <span className="inline-flex items-center gap-1 font-bold text-emerald-900">
                                        <span>
                                          {formatMetricTons(sh.shiftMt)} মে.টন ({formatBags(sh.shiftBags)} বস্তা)
                                        </span>
                                        <ArrowRight className="h-3 w-3" />
                                        <span>
                                          {sh.targetGodown} / {sh.targetKhamalNo}
                                        </span>
                                      </span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                            {(shortageCascadePlan.unallocatedMt > 0.0005 ||
                              shortageCascadePlan.unallocatedBags > 0) && (
                              <div className="rounded-lg bg-rose-50 border border-rose-200 px-3 py-2 text-[11px] font-semibold text-rose-800">
                                সতর্কতা: আরও {formatMetricTons(shortageCascadePlan.unallocatedMt)} মে.টন (
                                {formatBags(shortageCascadePlan.unallocatedBags)} বস্তা) সমন্বয়ের জন্য পরবর্তী খামালে পর্যাপ্ত মজুদ বা পূর্বের বিতরণ পাওয়া যায়নি।
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    )}
                </div>
              )}
            </div>
          )}

          {errorMsg && (
            <div
              role="alert"
              className="rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs font-semibold text-rose-800 flex items-center gap-2"
            >
              <AlertCircle className="h-4 w-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Footer Submit */}
          {showFormSubmit ? (
            <div className="sticky bottom-0 pt-3 pb-1 bg-white border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="text-xs text-slate-600 tabular-nums">
                {showAllocationWorkspace ? (
                  <>
                    {doSourceMode === 'existing' && (
                      <>
                        <span className="font-semibold text-slate-900">
                          {selectedCategoryCount} খাত · {selectedDos.length} ডিও
                        </span>
                        <span aria-hidden="true"> · </span>
                      </>
                    )}
                    <span className="font-semibold text-slate-900">{allocations.length}টি খামাল</span>
                    <span aria-hidden="true"> · </span>
                    <span>
                      ডেলিভারি:{' '}
                      <strong className="text-slate-900">
                        {activeMeta.tracksWeight
                          ? `${formatMetricTons(allocationTotals.deliveredMt)} মে.টন`
                          : `${formatBags(allocationTotals.deliveredBags)} বস্তা`}
                      </strong>
                    </span>
                    {allocationTotals.shortageMt > 0 && (
                      <>
                        <span aria-hidden="true"> · </span>
                        <span className="text-amber-800 font-semibold">
                          শর্টেজ: {formatMetricTons(allocationTotals.shortageMt)} মে.টন
                        </span>
                      </>
                    )}
                  </>
                ) : doSourceMode === 'dispatch' ? (
                  <span>
                    {dispatchType === 'Invoice' ? 'ইনভয়েস প্রেরণ' : 'মিলে ধান ক্রাশিং'} ·{' '}
                    {dispatchAllocations.length}টি খামাল ({formatMetricTons(dispatchTotals.mt)} মে.টন)
                  </span>
                ) : (
                  <span>
                    {otherSubMode === 'empty_bag' ? 'খালি বস্তা বিতরণ এন্ট্রি' : 'খামাল ঘাটতি এন্ট্রি'}
                  </span>
                )}
              </div>

              <button
                type="submit"
                disabled={isSaving}
                className="min-h-[48px] px-5 py-2.5 rounded-xl bg-[#B91C1C] hover:bg-red-800 disabled:opacity-60 text-sm font-bold text-white flex items-center justify-center gap-2 shadow-sm whitespace-nowrap cursor-pointer"
              >
                {isSaving ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Check className="h-4 w-4 stroke-[2.5]" />
                )}
                <span>
                  {isSaving
                    ? 'সংরক্ষণ হচ্ছে...'
                    : showAllocationWorkspace
                      ? 'ডিও বিতরণ ও শর্টেজ সংরক্ষণ করুন'
                      : doSourceMode === 'dispatch'
                        ? 'প্রেরণ সংরক্ষণ করুন'
                        : otherSubMode === 'empty_bag'
                          ? 'বস্তা বিতরণ সেভ করুন'
                          : shortageCascadePlan && shortageCascadePlan.shifts.length > 0
                            ? 'ঘাটতি ও পরের খামালে সমন্বয় সেভ করুন'
                            : 'ঘাটতি সংরক্ষণ করুন'}
                </span>
              </button>
            </div>
          ) : (
            <div className="sticky bottom-0 pt-3 pb-1 bg-white border-t border-slate-200 flex justify-end">
              <button
                type="button"
                onClick={onClose}
                className="min-h-[44px] px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-xs font-bold text-white cursor-pointer"
              >
                বন্ধ করুন
              </button>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};
