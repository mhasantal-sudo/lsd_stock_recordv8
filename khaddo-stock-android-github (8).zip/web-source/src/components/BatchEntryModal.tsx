import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  Calculator,
  Check,
  Layers,
  Minus,
  Plus,
  Settings2,
  Trash2,
  X,
} from 'lucide-react';
import {
  PRODUCTS,
  PRODUCT_MAP,
  type BatchRowDraft,
  type ChannelConfig,
  type ChannelMode,
  type ProductCategory,
} from '../types/grain';
import {
  ProductIcon,
  formatBags,
  formatMetricTons,
  todayIsoDate,
} from './GrainIcons';
import type { BatchInputPayload } from '../store/useGrainStore';

interface BatchEntryModalProps {
  isOpen: boolean;
  initialProduct: ProductCategory;
  initialGodown?: string;
  initialKhamal?: string;
  channels: ChannelConfig;
  godownList: string[];
  onClose: () => void;
  onSwitchToDistribution: (product: ProductCategory) => void;
  onSaveBatch: (
    payload: BatchInputPayload & { uniqueId?: string }
  ) =>
    | { ok: boolean; error?: string; count?: number }
    | Promise<{ ok: boolean; error?: string; count?: number }>;
  onQuickAddChannel: (product: ProductCategory, mode: ChannelMode, name: string) => boolean;
  onOpenChannelSettings: (product: ProductCategory, mode: ChannelMode) => void;
}

function makeDraftRow(khamalNo = ''): BatchRowDraft {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    khamalNo,
    bags: '',
    metricTons: '',
  };
}

export const BatchEntryModal: React.FC<BatchEntryModalProps> = ({
  isOpen,
  initialProduct,
  initialGodown,
  initialKhamal,
  channels,
  godownList,
  onClose,
  onSwitchToDistribution,
  onSaveBatch,
  onQuickAddChannel,
  onOpenChannelSettings,
}) => {
  const [product, setProduct] = useState<ProductCategory>(initialProduct);
  const [godownNo, setGodownNo] = useState<string>(initialGodown || godownList[0] || '০১');
  const [channel, setChannel] = useState<string>('');
  const [date, setDate] = useState<string>(todayIsoDate());
  const [referenceNo, setReferenceNo] = useState<string>('');
  const [uniqueId, setUniqueId] = useState<string>('');
  const [note, setNote] = useState<string>('');
  const [rows, setRows] = useState<BatchRowDraft[]>([makeDraftRow(initialKhamal || '')]);

  const [batchCountInput, setBatchCountInput] = useState<string>('10');
  const [batchPrefix, setBatchPrefix] = useState<string>('খামাল-');

  const [showQuickChannelInput, setShowQuickChannelInput] = useState(false);
  const [quickChannelName, setQuickChannelName] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    setProduct(initialProduct);
    setGodownNo(initialGodown || godownList[0] || '০১');
    setDate(todayIsoDate());
    setReferenceNo('');
    setUniqueId('');
    setNote('');
    setRows([makeDraftRow(initialKhamal || '')]);
    setErrorMsg(null);
    setIsSaving(false);
    setShowQuickChannelInput(false);
    setQuickChannelName('');
  }, [isOpen, initialProduct, initialGodown, initialKhamal, godownList]);

  const availableChannels = useMemo(
    () => channels[product]?.receipt || [],
    [channels, product]
  );

  useEffect(() => {
    if (!availableChannels.includes(channel)) {
      setChannel(availableChannels[0] || '');
    }
  }, [availableChannels, channel]);

  const productMeta = PRODUCT_MAP[product];

  const batchSummary = useMemo(() => {
    let totalBags = 0;
    let totalMt = 0;
    for (const r of rows) {
      totalBags += Number(r.bags) || 0;
      totalMt += Number(r.metricTons) || 0;
    }
    return {
      count: rows.length,
      totalBags,
      totalMt: Number(totalMt.toFixed(4)),
    };
  }, [rows]);

  if (!isOpen) return null;

  const handleGenerateRows = (countToGenerate: number) => {
    const count = Math.min(50, Math.max(1, Math.floor(countToGenerate)));
    const nextStartIdx = rows.filter((r) => r.khamalNo.trim() || r.bags || r.metricTons).length;
    const prefix = batchPrefix.trim() || 'খামাল-';

    const generated: BatchRowDraft[] = Array.from({ length: count }, (_, idx) => {
      const num = String(nextStartIdx + idx + 1).padStart(2, '0');
      return makeDraftRow(`${prefix}${num}`);
    });

    const isSingleEmpty =
      rows.length === 1 && !rows[0].khamalNo.trim() && !rows[0].bags && !rows[0].metricTons;
    setRows(isSingleEmpty ? generated : [...rows, ...generated]);
    setErrorMsg(null);
  };

  const handleRowChange = (id: string, field: keyof BatchRowDraft, value: string) => {
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, [field]: value } : r)));
    setErrorMsg(null);
  };

  const handleRemoveRow = (id: string) => {
    setRows((prev) => (prev.length > 1 ? prev.filter((r) => r.id !== id) : prev));
  };

  const handleAutoCalcMt = (id: string, bagsStr: string) => {
    const bagsNum = Number(bagsStr);
    if (!bagsNum || bagsNum <= 0) return;
    const mt = (bagsNum * 0.05).toFixed(3);
    handleRowChange(id, 'metricTons', mt);
  };

  const handleQuickAddChannelSubmit = () => {
    const clean = quickChannelName.trim();
    if (!clean) return;
    onQuickAddChannel(product, 'receipt', clean);
    setChannel(clean);
    setQuickChannelName('');
    setShowQuickChannelInput(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSaving) return;

    const parsedItems = rows.map((r) => ({
      khamalNo: r.khamalNo.trim(),
      bags: Number(r.bags) || 0,
      metricTons: productMeta.tracksWeight ? Number(r.metricTons) || 0 : 0,
    }));

    setIsSaving(true);
    setErrorMsg(null);
    try {
      const result = await onSaveBatch({
        type: 'receipt',
        product,
        godownNo,
        channel,
        date,
        referenceNo,
        uniqueId: uniqueId.trim(),
        note,
        items: parsedItems,
      });

      if (!result.ok) {
        setErrorMsg(result.error || 'সংরক্ষণ করা যায়নি। তথ্য যাচাই করুন।');
        return;
      }
      onClose();
    } finally {
      setIsSaving(false);
    }
  };

  const isBagSelected = product === 'bosta_50' || product === 'bosta_30';

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/55 backdrop-blur-xs sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="batch-modal-title"
    >
      <div className="w-full sm:max-w-3xl max-h-[94dvh] flex flex-col bg-white rounded-t-3xl sm:rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Grab handle on mobile */}
        <div className="sm:hidden pt-2.5 pb-1 flex justify-center bg-white shrink-0">
          <div className="w-10 h-1.5 rounded-full bg-slate-300" aria-hidden="true" />
        </div>

        {/* Header */}
        <div className="px-4 sm:px-6 py-3.5 border-b border-slate-200 flex items-center justify-between gap-3 shrink-0 bg-white">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="h-9 w-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
              <Plus className="h-5 w-5 stroke-[2.5]" />
            </div>
            <div className="min-w-0">
              <h2 id="batch-modal-title" className="text-base sm:text-lg font-bold text-slate-900 truncate">
                খাদ্যশস্য প্রাপ্তি — খামাল যুক্ত করুন
              </h2>
              <p className="text-xs text-slate-500 truncate">
                একসাথে একাধিক খামাল (ব্যাচ এন্ট্রি) ও উৎস/চ্যানেল সংরক্ষণ করুন
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => onSwitchToDistribution(product)}
              className="hidden sm:inline-flex items-center gap-1 rounded-lg border border-rose-200 bg-rose-50 px-2.5 py-1.5 text-xs font-bold text-rose-800 hover:bg-rose-100 cursor-pointer"
            >
              <Minus className="h-3.5 w-3.5" />
              <span>বিতরণে যান</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center text-slate-500 hover:bg-slate-100 hover:text-slate-800 transition-colors cursor-pointer shrink-0"
              aria-label="বন্ধ করুন"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto px-4 sm:px-6 py-4 space-y-5">
          {/* Product Selector: ধান, চাল, গম, বস্তা */}
          <div className="space-y-2.5">
            <div className="text-xs font-semibold text-slate-700">
              পণ্য / ক্যাটাগরি নির্বাচন করুন
            </div>
            <div className="grid grid-cols-4 gap-2 sm:gap-3">
              {PRODUCTS.slice(0, 3).map((item) => {
                const selected = product === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setProduct(item.id);
                      setErrorMsg(null);
                    }}
                    className={`min-h-[68px] rounded-xl border p-2.5 flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      selected
                        ? 'border-slate-900 bg-slate-900 text-white shadow-xs'
                        : 'border-slate-200 bg-white text-slate-800 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <ProductIcon
                      product={item.id}
                      className={`h-6 w-6 ${selected ? 'text-white' : item.textColorClass}`}
                    />
                    <span className="text-xs sm:text-sm font-bold whitespace-nowrap">
                      {item.nameBn}
                    </span>
                  </button>
                );
              })}

              {/* 4th Icon: বস্তা (opens 50kg / 30kg choice) */}
              <button
                type="button"
                onClick={() => {
                  if (!isBagSelected) setProduct('bosta_50');
                  setErrorMsg(null);
                }}
                className={`min-h-[68px] rounded-xl border p-2.5 flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  isBagSelected
                    ? 'border-slate-900 bg-slate-900 text-white shadow-xs'
                    : 'border-slate-200 bg-white text-slate-800 hover:border-slate-300 hover:bg-slate-50'
                }`}
              >
                <ProductIcon
                  product="bosta"
                  className={`h-6 w-6 ${isBagSelected ? 'text-white' : 'text-slate-700'}`}
                />
                <span className="text-xs sm:text-sm font-bold whitespace-nowrap">খালি বস্তা</span>
              </button>
            </div>

            {/* 2 Types of Empty Bags (৫০ কেজি খালি বস্তা / ৩০ কেজি খালি বস্তা) */}
            {isBagSelected && (
              <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-slate-100 border border-slate-200">
                <button
                  type="button"
                  onClick={() => setProduct('bosta_50')}
                  className={`min-h-[40px] rounded-lg px-3 py-1.5 text-xs font-bold transition-colors cursor-pointer ${
                    product === 'bosta_50'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  ৫০ কেজি খালি বস্তা
                </button>
                <button
                  type="button"
                  onClick={() => setProduct('bosta_30')}
                  className={`min-h-[40px] rounded-lg px-3 py-1.5 text-xs font-bold transition-colors cursor-pointer ${
                    product === 'bosta_30'
                      ? 'bg-white text-blue-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  ৩০ কেজি খালি বস্তা
                </button>
              </div>
            )}
          </div>

          {/* Shared Batch Header */}
          <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-4 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-xs font-bold text-slate-800">
                সাধারণ তথ্য (ব্যাচের সকল খামালের জন্য প্রযোজ্য)
              </h3>
              <span className="text-[11px] text-slate-500">
                গুদাম ও চ্যানেল একই রেখে একাধিক খামাল এন্ট্রি দিন
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label
                  htmlFor="batch-godown-input"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  ১. গুদাম নং <span className="text-rose-600">*</span>
                </label>
                <input
                  id="batch-godown-input"
                  list="godown-suggestions"
                  type="text"
                  value={godownNo}
                  onChange={(e) => {
                    setGodownNo(e.target.value);
                    setErrorMsg(null);
                  }}
                  placeholder="যেমন: গুদাম-০১"
                  className="w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-sm font-medium text-slate-900 focus:border-emerald-700 focus:outline-none"
                />
                <datalist id="godown-suggestions">
                  {godownList.map((g) => (
                    <option key={g} value={g} />
                  ))}
                </datalist>
                {godownList.length > 0 && (
                  <div className="mt-1.5 flex flex-wrap gap-1.5">
                    {godownList.slice(0, 5).map((g) => (
                      <button
                        key={g}
                        type="button"
                        onClick={() => setGodownNo(g)}
                        className={`px-2 py-0.5 rounded-md text-[11px] font-medium border transition-colors cursor-pointer ${
                          godownNo === g
                            ? 'bg-slate-800 text-white border-slate-800'
                            : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        {g}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <label
                    htmlFor="batch-channel-select"
                    className="block text-xs font-semibold text-slate-700"
                  >
                    প্রাপ্তির চ্যানেল / খাত <span className="text-rose-600">*</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => onOpenChannelSettings(product, 'receipt')}
                    className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 hover:underline cursor-pointer whitespace-nowrap"
                  >
                    <Settings2 className="h-3 w-3" />
                    <span>চ্যানেল সেটিংস</span>
                  </button>
                </div>

                <select
                  id="batch-channel-select"
                  value={channel}
                  onChange={(e) => {
                    setChannel(e.target.value);
                    setErrorMsg(null);
                  }}
                  className="w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3 py-2 text-sm font-medium text-slate-900 focus:border-emerald-700 focus:outline-none"
                >
                  {availableChannels.map((ch) => (
                    <option key={ch} value={ch}>
                      {ch}
                    </option>
                  ))}
                </select>

                {!showQuickChannelInput ? (
                  <button
                    type="button"
                    onClick={() => setShowQuickChannelInput(true)}
                    className="mt-1.5 text-[11px] font-semibold text-slate-600 hover:text-slate-900 cursor-pointer"
                  >
                    + নতুন {productMeta.shortBn} চ্যানেল যোগ করুন
                  </button>
                ) : (
                  <div className="mt-2 flex items-center gap-1.5">
                    <input
                      type="text"
                      value={quickChannelName}
                      onChange={(e) => setQuickChannelName(e.target.value)}
                      placeholder="নতুন খাত/উৎসের নাম..."
                      className="flex-1 rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-900 focus:border-emerald-700 focus:outline-none"
                    />
                    <button
                      type="button"
                      onClick={handleQuickAddChannelSubmit}
                      className="rounded-lg bg-emerald-700 px-2.5 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800 cursor-pointer"
                    >
                      যোগ
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowQuickChannelInput(false)}
                      className="rounded-lg border border-slate-200 bg-white px-2 py-1.5 text-xs text-slate-600 cursor-pointer"
                    >
                      বাতিল
                    </button>
                  </div>
                )}
              </div>

              <div>
                <label
                  htmlFor="batch-date-input"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  তারিখ
                </label>
                <input
                  id="batch-date-input"
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 py-2 font-mono text-xs text-slate-900 focus:border-emerald-700 focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="batch-ref-input"
                  className="block text-xs font-semibold text-slate-700 mb-1.5"
                >
                  {productMeta.tracksWeight ? 'আইডি / চালান নং (ঐচ্ছিক)' : 'চালান / ইনভয়েস নং (ঐচ্ছিক)'}
                </label>
                <input
                  id="batch-ref-input"
                  type="text"
                  value={productMeta.tracksWeight ? uniqueId || referenceNo : referenceNo}
                  onChange={(e) => {
                    setUniqueId(e.target.value);
                    setReferenceNo(e.target.value);
                  }}
                  placeholder={productMeta.tracksWeight ? 'যেমন: ১২৩ বা INV-105' : 'যেমন: INV-2026-105'}
                  className="w-full min-h-[44px] rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-sm text-slate-900 focus:border-emerald-700 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Batch Row Generator */}
          <div className="rounded-2xl border border-slate-200 bg-white p-3.5 sm:p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Layers className="h-4 w-4 text-slate-600" />
                <span className="text-xs sm:text-sm font-bold text-slate-900">
                  খামাল এন্ট্রি তালিকা ({rows.length}টি সারি)
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => handleGenerateRows(1)}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-800 whitespace-nowrap cursor-pointer"
                >
                  + ১টি খামাল
                </button>
                <button
                  type="button"
                  onClick={() => handleGenerateRows(5)}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-800 whitespace-nowrap cursor-pointer"
                >
                  + ৫টি খামাল
                </button>
                <button
                  type="button"
                  onClick={() => handleGenerateRows(10)}
                  className="px-2.5 py-1.5 rounded-lg border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 text-xs font-bold text-emerald-800 whitespace-nowrap cursor-pointer"
                >
                  + ১০টি খামাল
                </button>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 text-xs">
              <span className="text-slate-500 font-medium">কাস্টম ব্যাচ:</span>
              <input
                type="text"
                value={batchPrefix}
                onChange={(e) => setBatchPrefix(e.target.value)}
                aria-label="খামাল প্রিফিক্স"
                placeholder="প্রিফিক্স (খামাল-)"
                className="w-24 rounded-lg border border-slate-200 px-2.5 py-1.5 text-xs text-slate-800 focus:border-emerald-700 focus:outline-none"
              />
              <input
                type="number"
                min={1}
                max={50}
                value={batchCountInput}
                onChange={(e) => setBatchCountInput(e.target.value)}
                aria-label="খামাল সংখ্যা"
                className="w-16 rounded-lg border border-slate-200 px-2 py-1.5 font-mono tabular-nums text-xs text-slate-800 focus:border-emerald-700 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => handleGenerateRows(Number(batchCountInput) || 1)}
                className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-semibold whitespace-nowrap cursor-pointer"
              >
                সারি তৈরি করুন
              </button>
            </div>

            <div className="space-y-2.5 pt-1">
              {rows.map((row, index) => (
                <div
                  key={row.id}
                  className="rounded-xl border border-slate-200 bg-slate-50/50 p-3 space-y-2"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold text-slate-700 tabular-nums">
                      খামাল #{index + 1}
                    </span>
                    {rows.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleRemoveRow(row.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                        aria-label={`সারি ${index + 1} মুছুন`}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </div>

                  <div
                    className={`grid grid-cols-1 gap-2.5 ${
                      productMeta.tracksWeight ? 'sm:grid-cols-3' : 'sm:grid-cols-2'
                    }`}
                  >
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        ২. খামাল নং
                      </label>
                      <input
                        type="text"
                        value={row.khamalNo}
                        onChange={(e) => handleRowChange(row.id, 'khamalNo', e.target.value)}
                        placeholder={`যেমন: খামাল-${String(index + 1).padStart(2, '0')}`}
                        className="w-full min-h-[42px] rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-sm text-slate-900 focus:border-emerald-700 focus:outline-none"
                      />
                    </div>

                    {productMeta.tracksWeight && (
                      <div>
                        <div className="flex items-center justify-between gap-1 mb-1">
                          <label className="block text-[11px] font-semibold text-slate-600">
                            ৩. পরিমাণ (মে.টন)
                          </label>
                          {Number(row.bags) > 0 && (
                            <button
                              type="button"
                              onClick={() => handleAutoCalcMt(row.id, row.bags)}
                              className="inline-flex items-center gap-0.5 text-[10px] font-semibold text-emerald-700 hover:underline cursor-pointer"
                            >
                              <Calculator className="h-2.5 w-2.5" />
                              <span>৫০ কেজি/বস্তা</span>
                            </button>
                          )}
                        </div>
                        <input
                          type="number"
                          inputMode="decimal"
                          min="0"
                          step="0.001"
                          value={row.metricTons}
                          onChange={(e) => handleRowChange(row.id, 'metricTons', e.target.value)}
                          placeholder="0.000"
                          className="w-full min-h-[42px] rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 font-mono tabular-nums text-sm font-bold text-slate-900 focus:border-emerald-700 focus:outline-none"
                        />
                      </div>
                    )}

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        {productMeta.tracksWeight ? '৪. পরিমাণ বস্তা (ঐচ্ছিক)' : '৩. পরিমাণ বস্তা'}
                      </label>
                      <input
                        type="number"
                        inputMode="numeric"
                        min="0"
                        step="1"
                        value={row.bags}
                        onChange={(e) => handleRowChange(row.id, 'bags', e.target.value)}
                        placeholder="0"
                        className="w-full min-h-[42px] rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 font-mono tabular-nums text-sm text-slate-900 focus:border-emerald-700 focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <label htmlFor="batch-note-input" className="block text-xs font-semibold text-slate-700 mb-1">
              মন্তব্য (ঐচ্ছিক)
            </label>
            <input
              id="batch-note-input"
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="যেমন: ট্রাক নং, মিলের নাম বা অতিরিক্ত তথ্য"
              className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3.5 py-2 text-sm text-slate-900 focus:border-emerald-700 focus:outline-none"
            />
          </div>

          {errorMsg && (
            <div
              role="alert"
              className="rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs font-semibold text-rose-800 flex items-center gap-2"
            >
              <AlertCircle className="h-4 w-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div className="sticky bottom-0 pt-3 pb-1 bg-white border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="text-xs text-slate-600 tabular-nums">
              <span className="font-semibold text-slate-900">{batchSummary.count}টি খামাল</span>
              {productMeta.tracksWeight && (
                <>
                  <span aria-hidden="true"> · </span>
                  <span>
                    মোট মে.টন:{' '}
                    <strong className="text-slate-900">
                      {formatMetricTons(batchSummary.totalMt)}
                    </strong>
                  </span>
                </>
              )}
              <span aria-hidden="true"> · </span>
              <span>
                মোট বস্তা:{' '}
                <strong className="text-slate-900">{formatBags(batchSummary.totalBags)}</strong>
              </span>
            </div>

            <button
              type="submit"
              disabled={isSaving}
              className="min-h-[48px] px-5 py-2.5 rounded-xl bg-[#0D6E4E] hover:bg-emerald-900 disabled:opacity-60 text-sm font-bold text-white flex items-center justify-center gap-2 shadow-sm transition-colors whitespace-nowrap cursor-pointer"
            >
              <Check className="h-4 w-4 stroke-[2.5]" />
              <span>
                {isSaving
                  ? 'সংরক্ষণ হচ্ছে...'
                  : rows.length > 1
                    ? `সবগুলো (${rows.length}টি) একত্রে সংরক্ষণ করুন`
                    : 'প্রাপ্তি সংরক্ষণ করুন'}
              </span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
