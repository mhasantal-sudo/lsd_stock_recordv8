import React from 'react';
import { AlertTriangle, FileSpreadsheet, ShieldCheck, X } from 'lucide-react';
import type { SheetWriteConfirmRequest } from '../types/grain';

interface SheetWriteConfirmModalProps {
  request: SheetWriteConfirmRequest | null;
  onConfirm: () => void;
  onCancel: () => void;
}

export const SheetWriteConfirmModal: React.FC<SheetWriteConfirmModalProps> = ({
  request,
  onConfirm,
  onCancel,
}) => {
  if (!request) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="sheet-confirm-title"
    >
      <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white shadow-xl overflow-hidden">
        <div
          className={`px-5 py-4 border-b flex items-center justify-between gap-3 ${
            request.isDestructive
              ? 'bg-rose-50 border-rose-200'
              : 'bg-emerald-50 border-emerald-200'
          }`}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            {request.isDestructive ? (
              <AlertTriangle className="h-5 w-5 text-rose-700 shrink-0" />
            ) : (
              <ShieldCheck className="h-5 w-5 text-[#0D6E4E] shrink-0" />
            )}
            <h3
              id="sheet-confirm-title"
              className={`text-sm sm:text-base font-extrabold truncate ${
                request.isDestructive ? 'text-rose-950' : 'text-emerald-950'
              }`}
            >
              {request.title}
            </h3>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="rounded-lg p-1.5 text-slate-500 hover:bg-white/70 hover:text-slate-900 cursor-pointer"
            aria-label="বন্ধ করুন"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="p-5 space-y-3.5 text-xs sm:text-sm text-slate-700">
          <p className="leading-relaxed">{request.description}</p>

          <div className="rounded-xl border border-slate-200 bg-slate-50 p-3 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
              <FileSpreadsheet className="h-4 w-4 text-[#0D6E4E] shrink-0" />
              <span className="truncate">{request.spreadsheetName}</span>
            </div>
            <div className="text-[11px] text-slate-600">
              টার্গেট শিট:{' '}
              <span className="font-mono font-bold text-slate-900">
                {request.targetSheets.join(', ')}
              </span>
            </div>
            {request.details.length > 0 && (
              <ul className="space-y-1 pt-1 border-t border-slate-200 text-xs text-slate-800">
                {request.details.map((line, idx) => (
                  <li key={idx} className="leading-snug">
                    • {line}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        <div className="px-5 py-3.5 border-t border-slate-100 bg-slate-50/60 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onCancel}
            className="min-h-[40px] rounded-xl border border-slate-300 bg-white hover:bg-slate-100 px-4 py-2 text-xs font-bold text-slate-800 cursor-pointer"
          >
            বাতিল করুন
          </button>
          <button
            type="button"
            onClick={onConfirm}
            className={`min-h-[40px] rounded-xl px-4 py-2 text-xs font-bold text-white cursor-pointer ${
              request.isDestructive
                ? 'bg-rose-700 hover:bg-rose-800'
                : 'bg-[#0D6E4E] hover:bg-emerald-900'
            }`}
          >
            {request.confirmLabel || (request.isDestructive ? 'হ্যাঁ, পরিবর্তন করুন' : 'নিশ্চিত করুন ও সেভ করুন')}
          </button>
        </div>
      </div>
    </div>
  );
};
