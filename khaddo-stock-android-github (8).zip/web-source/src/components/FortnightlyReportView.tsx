import React, { useMemo, useRef, useState } from 'react';
import {
  Calendar,
  Download,
  Edit3,
  FileCheck2,
  Play,
  Printer,
  RefreshCw,
} from 'lucide-react';
import html2canvas from 'html2canvas-pro';
import { jsPDF } from 'jspdf';
import type {
  FortnightlyReportSettings,
  GasAppData,
  GasBridgeStatus,
  GrainTransaction,
} from '../types/grain';
import {
  buildFortnightlySnapshot,
  defaultFortnightDates,
  formatBnBags,
  formatBnDateFromIso,
  formatBnMt,
  formatBnSerial,
  getFortnightPeriodPhrase,
} from '../shared/fortnightlyReport';
import { todayIsoDate } from './GrainIcons';

interface FortnightlyReportViewProps {
  transactions: GrainTransaction[];
  gasData: GasAppData | null;
  gasBridgeStatus: GasBridgeStatus;
  settings: FortnightlyReportSettings;
  isSyncingDos?: boolean;
  onSyncExternalDos?: () => void;
  onOpenReportSettings: () => void;
}

interface ReportRunParams {
  memoNo: string;
  memoDate: string;
  startDate: string;
  endDate: string;
  includeZeroBalance: boolean;
}

export const FortnightlyReportView: React.FC<FortnightlyReportViewProps> = ({
  transactions,
  gasData,
  gasBridgeStatus,
  settings,
  isSyncingDos = false,
  onSyncExternalDos,
  onOpenReportSettings,
}) => {
  const today = todayIsoDate();
  const initialPeriod = defaultFortnightDates(today);

  const [memoNoInput, setMemoNoInput] = useState(settings.defaultMemoNo);
  const [memoDateInput, setMemoDateInput] = useState(today);
  const [startDateInput, setStartDateInput] = useState(initialPeriod.startDate);
  const [endDateInput, setEndDateInput] = useState(initialPeriod.endDate);
  const [includeZeroInput, setIncludeZeroInput] = useState(false);

  const [activeParams, setActiveParams] = useState<ReportRunParams | null>(null);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [pdfError, setPdfError] = useState<string | null>(null);

  const sheet1Ref = useRef<HTMLDivElement>(null);
  const sheet2Ref = useRef<HTMLDivElement>(null);
  const previewWrapRef = useRef<HTMLDivElement>(null);

  const applyFortnightPreset = (half: 1 | 2) => {
    const base = endDateInput || today;
    const [yStr, mStr] = base.split('-');
    const y = Number(yStr) || new Date().getFullYear();
    const m = Number(mStr) || new Date().getMonth() + 1;
    const lastDay = new Date(y, m, 0).getDate();
    const mPad = String(m).padStart(2, '0');
    if (half === 1) {
      const s = `${y}-${mPad}-01`;
      const e = `${y}-${mPad}-15`;
      setStartDateInput(s);
      setEndDateInput(e);
      setMemoDateInput(e);
    } else {
      const s = `${y}-${mPad}-16`;
      const e = `${y}-${mPad}-${String(lastDay).padStart(2, '0')}`;
      setStartDateInput(s);
      setEndDateInput(e);
      setMemoDateInput(e);
    }
  };

  const handleRunReport = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setPdfError(null);
    const cleanStart = startDateInput || endDateInput || today;
    const cleanEnd = endDateInput || startDateInput || today;
    const orderedStart = cleanStart <= cleanEnd ? cleanStart : cleanEnd;
    const orderedEnd = cleanStart <= cleanEnd ? cleanEnd : cleanStart;

    setActiveParams({
      memoNo: memoNoInput.trim() || settings.defaultMemoNo,
      memoDate: memoDateInput || orderedEnd,
      startDate: orderedStart,
      endDate: orderedEnd,
      includeZeroBalance: includeZeroInput,
    });

    window.setTimeout(() => {
      previewWrapRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 80);
  };

  const snapshot = useMemo(() => {
    if (!activeParams) return null;
    return buildFortnightlySnapshot({
      endDate: activeParams.endDate,
      transactions,
      gasData,
      gasBridgeStatus,
      includeZeroBalance: activeParams.includeZeroBalance,
    });
  }, [activeParams, transactions, gasData, gasBridgeStatus]);

  const renderedBodyText = useMemo(() => {
    if (!activeParams) return '';
    const memoDateBn = formatBnDateFromIso(activeParams.memoDate);
    const startBn = formatBnDateFromIso(activeParams.startDate);
    const endBn = formatBnDateFromIso(activeParams.endDate);
    const periodPhrase = getFortnightPeriodPhrase(activeParams.startDate, activeParams.endDate);

    return (settings.bodyTemplate || '')
      .replace(/\{তারিখ\}/g, `${memoDateBn} খ্রিঃ`)
      .replace(/\{গুদাম\}/g, settings.lsdDisplayName || 'শিকারপুর')
      .replace(/\{পক্ষ\}/g, periodPhrase)
      .replace(/\{শুরু_তারিখ\}/g, startBn)
      .replace(/\{শেষ_তারিখ\}/g, endBn);
  }, [activeParams, settings.bodyTemplate, settings.lsdDisplayName]);

  const copyLines = useMemo(() => {
    return (settings.copyList || '')
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter(Boolean);
  }, [settings.copyList]);

  const handleDownloadPdf = async () => {
    if (!sheet1Ref.current || !activeParams) return;
    setIsExportingPdf(true);
    setPdfError(null);

    try {
      // Ensure Nikosh webfont is fully loaded before canvas rasterization
      if (document.fonts) {
        try {
          await document.fonts.load("12pt 'Nikosh'");
          await document.fonts.load("bold 14pt 'Nikosh'");
          await document.fonts.ready;
        } catch {
          // Proceed even if browser rejects pre-load call
        }
      }

      const scale = 2.2;
      const sheet1El = sheet1Ref.current;
      const sheet1Rect = sheet1El.getBoundingClientRect();

      // Collect safe row/block break coordinates in CSS pixels relative to sheet1El
      const blockBottoms = new Set<number>([0]);
      const blockIntervals: Array<{ top: number; bottom: number }> = [];
      sheet1El.querySelectorAll<HTMLElement>('[data-pdf-block], tr').forEach((el) => {
        const r = el.getBoundingClientRect();
        const top = Math.max(0, r.top - sheet1Rect.top);
        const bottom = Math.max(top, r.bottom - sheet1Rect.top);
        blockBottoms.add(Math.ceil(bottom));
        blockIntervals.push({ top, bottom });
      });

      const canvas1 = await html2canvas(sheet1El, {
        scale,
        useCORS: true,
        backgroundColor: '#ffffff',
        logging: false,
      });

      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const pageWidthMm = 210;
      const pageHeightMm = 297;
      const marginX = 10;
      const marginY = 11;
      const printableWidthMm = pageWidthMm - marginX * 2;
      const printableHeightMm = pageHeightMm - marginY * 2;

      // Pixel height on canvas1 that corresponds to one printable A4 page height
      const pxPerMm = canvas1.width / printableWidthMm;
      const maxSliceHeightPx = Math.floor(printableHeightMm * pxPerMm);

      const safeBreaksPx = Array.from(blockBottoms)
        .map((cssY) => Math.round(cssY * scale))
        .filter((py) => py >= 0 && py <= canvas1.height)
        .sort((a, b) => a - b);
      if (safeBreaksPx[safeBreaksPx.length - 1] !== canvas1.height) {
        safeBreaksPx.push(canvas1.height);
      }

      let cursorY = 0;
      let pageIndex = 0;

      while (cursorY < canvas1.height - 2) {
        const targetEnd = cursorY + maxSliceHeightPx;
        let breakY = targetEnd;

        if (targetEnd >= canvas1.height) {
          breakY = canvas1.height;
        } else {
          // Pick the largest safe block bottom <= targetEnd that still makes progress
          let candidate = -1;
          for (let i = safeBreaksPx.length - 1; i >= 0; i--) {
            if (safeBreaksPx[i] <= targetEnd && safeBreaksPx[i] > cursorY + 80) {
              candidate = safeBreaksPx[i];
              break;
            }
          }
          if (candidate > cursorY) {
            breakY = candidate;
          } else {
            // Fallback: avoid slicing inside an atomic interval if possible
            const crossing = blockIntervals.find(
              (iv) => iv.top * scale < targetEnd && iv.bottom * scale > targetEnd
            );
            if (crossing && crossing.top * scale > cursorY + 60) {
              breakY = Math.floor(crossing.top * scale);
            }
          }
        }

        const sliceHeight = Math.max(1, breakY - cursorY);
        const pageCanvas = document.createElement('canvas');
        pageCanvas.width = canvas1.width;
        pageCanvas.height = sliceHeight;
        const ctx = pageCanvas.getContext('2d');
        if (ctx) {
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, pageCanvas.width, pageCanvas.height);
          ctx.drawImage(
            canvas1,
            0,
            cursorY,
            canvas1.width,
            sliceHeight,
            0,
            0,
            canvas1.width,
            sliceHeight
          );
          const imgData = pageCanvas.toDataURL('image/png');
          if (pageIndex > 0) pdf.addPage();
          const renderHeightMm = sliceHeight / pxPerMm;
          pdf.addImage(
            imgData,
            'PNG',
            marginX,
            marginY,
            printableWidthMm,
            renderHeightMm,
            undefined,
            'FAST'
          );
        }

        cursorY = breakY;
        pageIndex += 1;
      }

      // Page 2+: Copy / অনুলিপি Sheet
      if (sheet2Ref.current) {
        const canvas2 = await html2canvas(sheet2Ref.current, {
          scale,
          useCORS: true,
          backgroundColor: '#ffffff',
          logging: false,
        });
        pdf.addPage();
        const img2 = canvas2.toDataURL('image/png');
        const h2Mm = Math.min(printableHeightMm, (canvas2.height / canvas2.width) * printableWidthMm);
        pdf.addImage(img2, 'PNG', marginX, marginY, printableWidthMm, h2Mm, undefined, 'FAST');
      }

      const pdfFileName = `Pakkhik_Report_${activeParams.endDate}.pdf`;
      const androidBridge = (
        window as unknown as {
          AndroidBlobBridge?: {
            saveBase64File?: (data: string, fileName: string, mimeType: string) => void;
            printCurrentPage?: () => void;
          };
        }
      ).AndroidBlobBridge;

      if (androidBridge && typeof androidBridge.saveBase64File === 'function') {
        const dataUri = pdf.output('datauristring');
        androidBridge.saveBase64File(dataUri, pdfFileName, 'application/pdf');
      } else {
        pdf.save(pdfFileName);
      }
    } catch (err) {
      setPdfError(
        err instanceof Error
          ? `পিডিএফ তৈরিতে সমস্যা হয়েছে: ${err.message}`
          : 'পিডিএফ তৈরি করা যায়নি। অনুগ্রহ করে প্রিন্ট বাটন ব্যবহার করুন।'
      );
    } finally {
      setIsExportingPdf(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Control Panel (hidden during print) */}
      <section className="no-print rounded-2xl border border-slate-200 bg-white p-4 sm:p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="h-10 w-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center shrink-0">
              <FileCheck2 className="h-5 w-5 text-[#0D6E4E]" />
            </div>
            <div>
              <h1 className="text-base sm:text-lg font-extrabold text-slate-900">
                পাক্ষিক মজুদ যাচাই প্রতিবেদন
              </h1>
              <p className="text-xs text-slate-500 mt-0.5">
                স্মারক নং, পত্রের তারিখ এবং পাক্ষিকের শুরু ও শেষ তারিখ নির্বাচন করে রিপোর্ট রান ও নিকোশ ফন্টে পিডিএফ ডাউনলোড করুন।
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {onSyncExternalDos && (
              <button
                type="button"
                onClick={onSyncExternalDos}
                disabled={isSyncingDos}
                className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 px-3 py-1.5 text-xs font-bold text-slate-700 cursor-pointer"
              >
                <RefreshCw className={`h-3.5 w-3.5 ${isSyncingDos ? 'animate-spin' : ''}`} />
                <span>{isSyncingDos ? 'সিঙ্ক হচ্ছে...' : 'তথ্য রিফ্রেশ'}</span>
              </button>
            )}
            <button
              type="button"
              onClick={onOpenReportSettings}
              className="min-h-[38px] inline-flex items-center gap-1.5 rounded-xl border border-emerald-200 bg-emerald-50 hover:bg-emerald-100 px-3 py-1.5 text-xs font-bold text-emerald-900 cursor-pointer"
            >
              <Edit3 className="h-3.5 w-3.5" />
              <span>পত্রের লেখা এডিট (সেটিংস)</span>
            </button>
          </div>
        </div>

        <form onSubmit={handleRunReport} className="space-y-3 pt-3 border-t border-slate-100">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div>
              <label htmlFor="pk-memo" className="block text-xs font-bold text-slate-700 mb-1">
                স্মারক নং *
              </label>
              <input
                id="pk-memo"
                type="text"
                value={memoNoInput}
                onChange={(e) => setMemoNoInput(e.target.value)}
                placeholder="যেমন: ১৩.০১.০৬৯৪.০০৭.৬৮.০২০.৫০৬"
                className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs sm:text-sm font-semibold text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="pk-memo-date" className="block text-xs font-bold text-slate-700 mb-1">
                পত্রের তারিখ *
              </label>
              <input
                id="pk-memo-date"
                type="date"
                value={memoDateInput}
                onChange={(e) => setMemoDateInput(e.target.value)}
                className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs sm:text-sm font-semibold text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="pk-start-date" className="block text-xs font-bold text-slate-700 mb-1">
                পাক্ষিকের শুরু তারিখ *
              </label>
              <input
                id="pk-start-date"
                type="date"
                value={startDateInput}
                onChange={(e) => setStartDateInput(e.target.value)}
                className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs sm:text-sm font-semibold text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="pk-end-date" className="block text-xs font-bold text-slate-700 mb-1">
                পাক্ষিকের শেষ তারিখ (হালনাগাদ মজুদ) *
              </label>
              <input
                id="pk-end-date"
                type="date"
                value={endDateInput}
                onChange={(e) => {
                  setEndDateInput(e.target.value);
                  setMemoDateInput(e.target.value);
                }}
                className="w-full min-h-[42px] rounded-xl border border-slate-300 bg-white px-3 py-2 text-xs sm:text-sm font-semibold text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => applyFortnightPreset(1)}
                className="min-h-[34px] inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 px-2.5 py-1 text-[11px] font-bold text-slate-700 cursor-pointer"
              >
                <Calendar className="h-3 w-3" />
                <span>১ম পক্ষ (১–১৫)</span>
              </button>
              <button
                type="button"
                onClick={() => applyFortnightPreset(2)}
                className="min-h-[34px] inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 px-2.5 py-1 text-[11px] font-bold text-slate-700 cursor-pointer"
              >
                <Calendar className="h-3 w-3" />
                <span>২য় পক্ষ (১৬–শেষ)</span>
              </button>
              <label className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 ml-1 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={includeZeroInput}
                  onChange={(e) => setIncludeZeroInput(e.target.checked)}
                  className="rounded border-slate-300 text-[#0D6E4E] focus:ring-[#0D6E4E]"
                />
                <span>শূন্য ব্যালেন্স খামালও দেখান</span>
              </label>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="submit"
                className="min-h-[42px] inline-flex items-center gap-2 rounded-xl bg-[#0D6E4E] hover:bg-emerald-900 px-4 py-2 text-xs sm:text-sm font-bold text-white shadow-xs cursor-pointer"
              >
                <Play className="h-4 w-4" />
                <span>রিপোর্ট রান করুন</span>
              </button>

              {activeParams && (
                <>
                  <button
                    type="button"
                    onClick={() => void handleDownloadPdf()}
                    disabled={isExportingPdf}
                    className="min-h-[42px] inline-flex items-center gap-2 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-60 px-4 py-2 text-xs sm:text-sm font-bold text-white cursor-pointer"
                  >
                    <Download className="h-4 w-4" />
                    <span>
                      {isExportingPdf ? 'পিডিএফ তৈরি হচ্ছে...' : 'পিডিএফ ডাউনলোড (Nikosh)'}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const androidBridge = (
                        window as unknown as {
                          AndroidBlobBridge?: { printCurrentPage?: () => void };
                        }
                      ).AndroidBlobBridge;
                      if (androidBridge && typeof androidBridge.printCurrentPage === 'function') {
                        androidBridge.printCurrentPage();
                      } else {
                        window.print();
                      }
                    }}
                    className="min-h-[42px] inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 px-3.5 py-2 text-xs sm:text-sm font-bold text-slate-800 cursor-pointer"
                  >
                    <Printer className="h-4 w-4" />
                    <span>প্রিন্ট</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {pdfError && (
            <div className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-semibold text-rose-800">
              {pdfError}
            </div>
          )}
        </form>
      </section>

      {/* Report Output Area */}
      {!activeParams || !snapshot ? (
        <div className="no-print rounded-2xl border border-dashed border-slate-300 bg-white/80 p-10 text-center space-y-2">
          <FileCheck2 className="h-9 w-9 text-emerald-700/70 mx-auto" />
          <div className="text-sm font-bold text-slate-800">
            পাক্ষিক মজুদ যাচাই প্রতিবেদন দেখতে উপরে &ldquo;রিপোর্ট রান করুন&rdquo; বাটনে চাপ দিন
          </div>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            নির্বাচিত শেষ তারিখ ({formatBnDateFromIso(endDateInput)} খ্রিঃ) পর্যন্ত সকল প্রাপ্তি, বিতরণ ও গুদাম ঘাটতির সর্বশেষ আপডেট হিসাব অনুযায়ী প্রতিবেদন তৈরি হবে।
          </p>
        </div>
      ) : (
        <div ref={previewWrapRef} className="space-y-6 overflow-x-auto pb-4">
          {/* PAGE 1: Main Letter, Khath-grouped Grain Tables, Consolidated Grand Total, Bag Table & Signature */}
          <div
            ref={sheet1Ref}
            className="print-only-sheet font-nikosh mx-auto bg-white shadow-sm border border-slate-300"
            style={{
              width: '794px',
              minHeight: '1122px',
              padding: '44px 48px 42px 48px',
              color: '#000000',
              backgroundColor: '#ffffff',
              fontFamily: "'Nikosh', 'SolaimanLipi', 'Hind Siliguri', serif",
              lineHeight: 1.38,
              boxSizing: 'border-box',
            }}
          >
            {/* Official Letterhead */}
            <div data-pdf-block className="text-center" style={{ marginBottom: '18px' }}>
              <div style={{ fontSize: '21px', fontWeight: 700, lineHeight: 1.25 }}>
                {settings.govTitle}
              </div>
              <div style={{ fontSize: '18px', fontWeight: 700, lineHeight: 1.28 }}>
                {settings.officeName}
              </div>
              <div style={{ fontSize: '15.5px', fontWeight: 400, lineHeight: 1.28 }}>
                {settings.officeLocation}
              </div>
            </div>

            {/* Memo & Date Row */}
            <div
              data-pdf-block
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'baseline',
                fontSize: '15px',
                fontWeight: 700,
                marginBottom: '18px',
              }}
            >
              <div>স্মারক নং-{activeParams.memoNo}</div>
              <div>তারিখঃ {formatBnDateFromIso(activeParams.memoDate)} খ্রিঃ</div>
            </div>

            {/* Addressee, Subject, Reference */}
            <div
              data-pdf-block
              style={{ fontSize: '15px', lineHeight: 1.5, marginBottom: '12px' }}
            >
              <div>
                <span style={{ fontWeight: 700 }}>{settings.recipientLabel}</span>{' '}
                <span>{settings.recipientText}</span>
              </div>
              <div style={{ marginTop: '2px' }}>
                <span style={{ fontWeight: 700 }}>{settings.subjectLabel}</span>{' '}
                <span>{settings.subjectText}</span>
              </div>
              <div style={{ marginTop: '2px' }}>
                <span style={{ fontWeight: 700 }}>{settings.referenceLabel}</span>{' '}
                <span>{settings.referenceText}</span>
              </div>
            </div>

            {/* Body Paragraph */}
            <div
              data-pdf-block
              style={{
                fontSize: '15px',
                lineHeight: 1.55,
                textAlign: 'justify',
                marginBottom: '12px',
              }}
            >
              {renderedBodyText}
            </div>

            {/* Fortnight Start & End Date Header Bar right above the tables */}
            <div
              data-pdf-block
              style={{
                fontSize: '14.5px',
                fontWeight: 700,
                marginBottom: '10px',
                paddingBottom: '4px',
                borderBottom: '1px solid #000000',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}
            >
              <span>
                পাক্ষিকের সময়কালঃ {formatBnDateFromIso(activeParams.startDate)} খ্রিঃ হইতে{' '}
                {formatBnDateFromIso(activeParams.endDate)} খ্রিঃ পর্যন্ত
              </span>
              <span>
                হালনাগাদ মজুদঃ {formatBnDateFromIso(activeParams.endDate)} খ্রিঃ
              </span>
            </div>

            {/* Grain Tables: (চাল), (গম), (ধান) — Khath-separated + Grain totals */}
            {snapshot.grainSections.length === 0 ? (
              <div
                data-pdf-block
                style={{
                  border: '1px solid #000000',
                  padding: '16px',
                  textAlign: 'center',
                  fontSize: '14.5px',
                  marginBottom: '14px',
                }}
              >
                নির্বাচিত তারিখ ({formatBnDateFromIso(activeParams.endDate)} খ্রিঃ) পর্যন্ত কোনো খাদ্যশস্যের মজুদ পাওয়া যায়নি।
              </div>
            ) : (
              snapshot.grainSections.map((section) => {
                let runningSerial = 0;
                return (
                  <div key={section.product} style={{ marginBottom: '14px' }}>
                    <div
                      data-pdf-block
                      style={{
                        fontSize: '15.5px',
                        fontWeight: 700,
                        marginBottom: '4px',
                      }}
                    >
                      ({section.productNameBn})
                    </div>

                    <table
                      style={{
                        width: '100%',
                        borderCollapse: 'collapse',
                        fontSize: '13.5px',
                        lineHeight: 1.25,
                        tableLayout: 'fixed',
                      }}
                    >
                      <colgroup>
                        <col style={{ width: '5%' }} />
                        <col style={{ width: '7.5%' }} />
                        <col style={{ width: '16.5%' }} />
                        <col style={{ width: '6%' }} />
                        <col style={{ width: '7.5%' }} />
                        <col style={{ width: '10.5%' }} />
                        <col style={{ width: '7.5%' }} />
                        <col style={{ width: '10.5%' }} />
                        <col style={{ width: '7%' }} />
                        <col style={{ width: '9.5%' }} />
                        <col style={{ width: '12.5%' }} />
                      </colgroup>
                      <thead>
                        <tr>
                          <th rowSpan={2} style={thStyle}>
                            ক্রঃ
                          </th>
                          <th rowSpan={2} style={thStyle}>
                            গোডাউন
                          </th>
                          <th rowSpan={2} style={thStyle}>
                            খামাল নং
                          </th>
                          <th rowSpan={2} style={thStyle}>
                            পণ্য
                          </th>
                          <th colSpan={2} style={thStyle}>
                            রেকর্ড সূত্রে মজুদ
                          </th>
                          <th colSpan={2} style={thStyle}>
                            যাচাই অন্তে প্রাপ্ত মজুদ
                          </th>
                          <th colSpan={2} style={thStyle}>
                            গুদাম ঘাটতি
                          </th>
                          <th rowSpan={2} style={thStyle}>
                            মন্তব্য
                          </th>
                        </tr>
                        <tr>
                          <th style={thStyle}>বস্তা</th>
                          <th style={thStyle}>পরিমাণ</th>
                          <th style={thStyle}>বস্তা</th>
                          <th style={thStyle}>পরিমাণ</th>
                          <th style={thStyle}>বস্তা</th>
                          <th style={thStyle}>পরিমাণ</th>
                        </tr>
                      </thead>
                      <tbody>
                        {section.khathGroups.map((kGroup) => (
                          <React.Fragment key={`${section.product}::${kGroup.khath}`}>
                            {/* Khath Header Row */}
                            <tr>
                              <td
                                colSpan={11}
                                style={{
                                  ...tdStyle,
                                  textAlign: 'left',
                                  fontWeight: 700,
                                  backgroundColor: '#f5f5f5',
                                  padding: '4px 7px',
                                }}
                              >
                                খাতঃ {kGroup.khath}
                              </td>
                            </tr>

                            {/* Khamal Rows under this Khath */}
                            {kGroup.rows.map((row) => {
                              runningSerial += 1;
                              return (
                                <tr key={row.key}>
                                  <td style={tdCenterStyle}>{formatBnSerial(runningSerial)}</td>
                                  <td style={tdCenterStyle}>{row.godownNo}</td>
                                  <td
                                    style={{
                                      ...tdCenterStyle,
                                      wordBreak: 'break-word',
                                    }}
                                  >
                                    {row.khamalNo}
                                  </td>
                                  <td style={tdCenterStyle}>{row.productNameBn}</td>
                                  <td style={tdCenterStyle}>{formatBnBags(row.recordBags)}</td>
                                  <td style={tdCenterStyle}>{formatBnMt(row.recordMt)}</td>
                                  <td style={tdCenterStyle}>{formatBnBags(row.verifiedBags)}</td>
                                  <td style={tdCenterStyle}>{formatBnMt(row.verifiedMt)}</td>
                                  <td style={tdCenterStyle}>
                                    {formatBnBags(row.shortageBags, true)}
                                  </td>
                                  <td style={tdCenterStyle}>{formatBnMt(row.shortageMt)}</td>
                                  <td
                                    style={{
                                      ...tdCenterStyle,
                                      wordBreak: 'break-word',
                                    }}
                                  >
                                    {row.remarks}
                                  </td>
                                </tr>
                              );
                            })}

                            {/* Khath Subtotal Row */}
                            <tr>
                              <td
                                colSpan={4}
                                style={{
                                  ...tdStyle,
                                  textAlign: 'right',
                                  fontWeight: 700,
                                  backgroundColor: '#fafafa',
                                  paddingRight: '8px',
                                }}
                              >
                                উপ-মোট ({kGroup.khath}) =
                              </td>
                              <td style={{ ...tdCenterBoldStyle, backgroundColor: '#fafafa' }}>
                                {formatBnBags(kGroup.totals.recordBags)}
                              </td>
                              <td style={{ ...tdCenterBoldStyle, backgroundColor: '#fafafa' }}>
                                {formatBnMt(kGroup.totals.recordMt)}
                              </td>
                              <td style={{ ...tdCenterBoldStyle, backgroundColor: '#fafafa' }}>
                                {formatBnBags(kGroup.totals.verifiedBags)}
                              </td>
                              <td style={{ ...tdCenterBoldStyle, backgroundColor: '#fafafa' }}>
                                {formatBnMt(kGroup.totals.verifiedMt)}
                              </td>
                              <td style={{ ...tdCenterBoldStyle, backgroundColor: '#fafafa' }}>
                                {formatBnBags(kGroup.totals.shortageBags, true)}
                              </td>
                              <td style={{ ...tdCenterBoldStyle, backgroundColor: '#fafafa' }}>
                                {formatBnMt(kGroup.totals.shortageMt)}
                              </td>
                              <td style={{ ...tdCenterBoldStyle, backgroundColor: '#fafafa' }} />
                            </tr>
                          </React.Fragment>
                        ))}

                        {/* Grain-wise Total Row */}
                        <tr>
                          <td
                            colSpan={4}
                            style={{
                              ...tdStyle,
                              textAlign: 'right',
                              fontWeight: 700,
                              paddingRight: '8px',
                            }}
                          >
                            মোট ({section.productNameBn}) =
                          </td>
                          <td style={tdCenterBoldStyle}>
                            {formatBnBags(section.totals.recordBags)}
                          </td>
                          <td style={tdCenterBoldStyle}>
                            {formatBnMt(section.totals.recordMt)}
                          </td>
                          <td style={tdCenterBoldStyle}>
                            {formatBnBags(section.totals.verifiedBags)}
                          </td>
                          <td style={tdCenterBoldStyle}>
                            {formatBnMt(section.totals.verifiedMt)}
                          </td>
                          <td style={tdCenterBoldStyle}>
                            {formatBnBags(section.totals.shortageBags, true)}
                          </td>
                          <td style={tdCenterBoldStyle}>
                            {formatBnMt(section.totals.shortageMt)}
                          </td>
                          <td style={tdCenterBoldStyle} />
                        </tr>
                      </tbody>
                    </table>
                  </div>
                );
              })
            )}

            {/* Consolidated Summary of All Grains (সকল শস্যের সমন্বিত যোগফল) */}
            {snapshot.grainSections.length > 0 && (
              <div style={{ marginBottom: '16px' }}>
                <div
                  data-pdf-block
                  style={{
                    fontSize: '15px',
                    fontWeight: 700,
                    marginBottom: '4px',
                  }}
                >
                  (সকল শস্যের সমন্বিত যোগফল)
                </div>
                <table
                  style={{
                    width: '100%',
                    borderCollapse: 'collapse',
                    fontSize: '13.5px',
                    lineHeight: 1.25,
                    tableLayout: 'fixed',
                  }}
                >
                  <colgroup>
                    <col style={{ width: '35%' }} />
                    <col style={{ width: '7.5%' }} />
                    <col style={{ width: '10.5%' }} />
                    <col style={{ width: '7.5%' }} />
                    <col style={{ width: '10.5%' }} />
                    <col style={{ width: '7%' }} />
                    <col style={{ width: '9.5%' }} />
                    <col style={{ width: '12.5%' }} />
                  </colgroup>
                  <thead>
                    <tr>
                      <th rowSpan={2} style={thStyle}>
                        শস্যের বিবরণ
                      </th>
                      <th colSpan={2} style={thStyle}>
                        রেকর্ড সূত্রে মজুদ
                      </th>
                      <th colSpan={2} style={thStyle}>
                        যাচাই অন্তে প্রাপ্ত মজুদ
                      </th>
                      <th colSpan={2} style={thStyle}>
                        গুদাম ঘাটতি
                      </th>
                      <th rowSpan={2} style={thStyle}>
                        মন্তব্য
                      </th>
                    </tr>
                    <tr>
                      <th style={thStyle}>বস্তা</th>
                      <th style={thStyle}>পরিমাণ (মে.টন)</th>
                      <th style={thStyle}>বস্তা</th>
                      <th style={thStyle}>পরিমাণ (মে.টন)</th>
                      <th style={thStyle}>বস্তা</th>
                      <th style={thStyle}>পরিমাণ (মে.টন)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {snapshot.grainSections.map((sec) => (
                      <tr key={`sum-${sec.product}`}>
                        <td style={{ ...tdStyle, textAlign: 'left', fontWeight: 700, paddingLeft: '8px' }}>
                          মোট {sec.productNameBn}
                        </td>
                        <td style={tdCenterStyle}>{formatBnBags(sec.totals.recordBags)}</td>
                        <td style={tdCenterStyle}>{formatBnMt(sec.totals.recordMt)}</td>
                        <td style={tdCenterStyle}>{formatBnBags(sec.totals.verifiedBags)}</td>
                        <td style={tdCenterStyle}>{formatBnMt(sec.totals.verifiedMt)}</td>
                        <td style={tdCenterStyle}>{formatBnBags(sec.totals.shortageBags, true)}</td>
                        <td style={tdCenterStyle}>{formatBnMt(sec.totals.shortageMt)}</td>
                        <td style={tdCenterStyle}>-</td>
                      </tr>
                    ))}
                    <tr>
                      <td
                        style={{
                          ...tdStyle,
                          textAlign: 'right',
                          fontWeight: 700,
                          backgroundColor: '#f3f3f3',
                          paddingRight: '8px',
                        }}
                      >
                        সকল শস্যের সমন্বিত সর্বমোট =
                      </td>
                      <td style={{ ...tdCenterBoldStyle, backgroundColor: '#f3f3f3' }}>
                        {formatBnBags(snapshot.grandTotals.recordBags)}
                      </td>
                      <td style={{ ...tdCenterBoldStyle, backgroundColor: '#f3f3f3' }}>
                        {formatBnMt(snapshot.grandTotals.recordMt)}
                      </td>
                      <td style={{ ...tdCenterBoldStyle, backgroundColor: '#f3f3f3' }}>
                        {formatBnBags(snapshot.grandTotals.verifiedBags)}
                      </td>
                      <td style={{ ...tdCenterBoldStyle, backgroundColor: '#f3f3f3' }}>
                        {formatBnMt(snapshot.grandTotals.verifiedMt)}
                      </td>
                      <td style={{ ...tdCenterBoldStyle, backgroundColor: '#f3f3f3' }}>
                        {formatBnBags(snapshot.grandTotals.shortageBags, true)}
                      </td>
                      <td style={{ ...tdCenterBoldStyle, backgroundColor: '#f3f3f3' }}>
                        {formatBnMt(snapshot.grandTotals.shortageMt)}
                      </td>
                      <td style={{ ...tdCenterBoldStyle, backgroundColor: '#f3f3f3' }} />
                    </tr>
                  </tbody>
                </table>
              </div>
            )}

            {/* Empty Bag Table: (বস্তা) */}
            <div style={{ marginBottom: '26px' }}>
              <div
                data-pdf-block
                style={{
                  fontSize: '15.5px',
                  fontWeight: 700,
                  marginBottom: '4px',
                }}
              >
                (বস্তা)
              </div>
              <table
                style={{
                  width: '100%',
                  borderCollapse: 'collapse',
                  fontSize: '14px',
                  lineHeight: 1.3,
                  tableLayout: 'fixed',
                }}
              >
                <colgroup>
                  <col style={{ width: '9%' }} />
                  <col style={{ width: '12%' }} />
                  <col style={{ width: '35%' }} />
                  <col style={{ width: '22%' }} />
                  <col style={{ width: '22%' }} />
                </colgroup>
                <thead>
                  <tr>
                    <th style={thStyle}>ক্রঃ নং</th>
                    <th style={thStyle}>গোডাউন নং</th>
                    <th style={thStyle}>বস্তার ধরন</th>
                    <th style={thStyle}>রেকর্ড বস্তা</th>
                    <th style={thStyle}>যাচাই অন্তে প্রাপ্ত বস্তা</th>
                  </tr>
                </thead>
                <tbody>
                  {snapshot.bagRows.length === 0 ? (
                    <tr>
                      <td colSpan={5} style={tdCenterStyle}>
                        কোনো খালি বস্তার মজুদ নেই
                      </td>
                    </tr>
                  ) : (
                    snapshot.bagRows.map((b, idx) => (
                      <tr key={`${b.godownNo}-${b.product}-${idx}`}>
                        <td style={tdCenterStyle}>{formatBnSerial(idx + 1)}</td>
                        <td style={tdCenterStyle}>{b.godownNo}</td>
                        <td style={tdCenterStyle}>{b.bagTypeLabel}</td>
                        <td style={tdCenterStyle}>{formatBnBags(b.recordBags)}</td>
                        <td style={tdCenterStyle}>{formatBnBags(b.verifiedBags)}</td>
                      </tr>
                    ))
                  )}
                  <tr>
                    <td
                      colSpan={3}
                      style={{
                        ...tdStyle,
                        textAlign: 'right',
                        fontWeight: 700,
                        paddingRight: '10px',
                      }}
                    >
                      মোট =
                    </td>
                    <td style={tdCenterBoldStyle}>
                      {formatBnBags(snapshot.bagTotals.recordBags)}
                    </td>
                    <td style={tdCenterBoldStyle}>
                      {formatBnBags(snapshot.bagTotals.verifiedBags)}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Officer Signature Block (Bottom Right of Main Letter) */}
            <div
              data-pdf-block
              style={{
                display: 'flex',
                justifyContent: 'flex-end',
                marginTop: '34px',
                pageBreakInside: 'avoid',
                breakInside: 'avoid',
              }}
            >
              <div style={{ textAlign: 'center', fontSize: '15.5px', lineHeight: 1.4, minWidth: '210px' }}>
                {settings.officerName.trim() && (
                  <div style={{ fontWeight: 400 }}>({settings.officerName.trim()})</div>
                )}
                <div style={{ fontWeight: 400 }}>{settings.officerDesignation}</div>
                <div style={{ fontWeight: 400 }}>{settings.signOfficeLocation}</div>
              </div>
            </div>
          </div>

          {/* PAGE 2: Copy / অনুলিপি Sheet (matches Page 2 of attached PDF) */}
          <div
            ref={sheet2Ref}
            className="print-only-sheet print-page-break font-nikosh mx-auto bg-white shadow-sm border border-slate-300"
            style={{
              width: '794px',
              minHeight: '560px',
              padding: '44px 48px 42px 48px',
              color: '#000000',
              backgroundColor: '#ffffff',
              fontFamily: "'Nikosh', 'SolaimanLipi', 'Hind Siliguri', serif",
              lineHeight: 1.45,
              boxSizing: 'border-box',
            }}
          >
            {/* Memo & Date Row on Copy Page */}
            <div
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'baseline',
                fontSize: '15px',
                fontWeight: 400,
                marginBottom: '12px',
              }}
            >
              <div>স্মারক নং-{activeParams.memoNo}</div>
              <div>তারিখঃ {formatBnDateFromIso(activeParams.memoDate)} খ্রিঃ</div>
            </div>

            {/* Copy Section (অনুলিপিঃ) */}
            <div style={{ fontSize: '15px', lineHeight: 1.55, marginBottom: '48px' }}>
              <div style={{ fontWeight: 700, marginBottom: '2px' }}>{settings.copyTitle}</div>
              {copyLines.map((line, i) => (
                <div key={i}>{line}</div>
              ))}
            </div>

            {/* Signature on Copy Page */}
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '48px' }}>
              <div style={{ textAlign: 'center', fontSize: '15.5px', lineHeight: 1.4, minWidth: '210px' }}>
                <div>{settings.footerDesignation}</div>
                <div>{settings.footerLocation}</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const thStyle: React.CSSProperties = {
  border: '1px solid #000000',
  padding: '5px 4px',
  textAlign: 'center',
  fontWeight: 700,
  verticalAlign: 'middle',
  backgroundColor: '#ffffff',
};

const tdStyle: React.CSSProperties = {
  border: '1px solid #000000',
  padding: '4px 4px',
  verticalAlign: 'middle',
};

const tdCenterStyle: React.CSSProperties = {
  ...tdStyle,
  textAlign: 'center',
};

const tdCenterBoldStyle: React.CSSProperties = {
  ...tdCenterStyle,
  fontWeight: 700,
};
