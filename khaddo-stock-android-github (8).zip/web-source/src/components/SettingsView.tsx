import React, { useEffect, useRef, useState } from 'react';
import {
  Building2,
  Calendar,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Code2,
  Copy,
  Download,
  Edit3,
  ExternalLink,
  FileCode2,
  FileSpreadsheet,
  FileText,
  FolderGit2,
  Link2,
  Plus,
  RefreshCw,
  RotateCcw,
  Save,
  Trash2,
  Upload,
} from 'lucide-react';
import JSZip from 'jszip';
import type { User } from 'firebase/auth';
import {
  DEFAULT_MAIN_APPS_SCRIPT_URL,
  PRODUCTS,
  PRODUCT_MAP,
  inferDefaultProductFromCategory,
  type ChannelConfig,
  type ChannelMode,
  type DeliveryOrder,
  type DriveSpreadsheetFile,
  type ExternalSyncConfig,
  type FortnightlyReportSettings,
  type GasAppData,
  type GasBridgeStatus,
  type GoogleSheetsConfig,
  type ProductCategory,
} from '../types/grain';
import { isDoPending } from '../shared/externalDoSync';
import { GAS_BRIDGE_SNIPPET } from '../shared/gasBridge';
import {
  DEV_PWA_APP_URL,
  GOOGLE_AUTH_PROJECT_ID,
  LIVE_PWA_APP_URL,
  hasOpenExternalBrowserBridge,
  isAndroidWebViewOrigin,
  isInEmbeddedIframe,
  openExternalBrowserIfAndroid,
  resolveReachablePwaOrigin,
} from '../shared/googleAuth';
import { extractSpreadsheetId } from '../shared/googleSheetsSync';
import { GoogleSignInButton } from './GoogleSignInButton';
import {
  ProductIcon,
  formatBags,
  formatMetricTons,
  todayIsoDate,
} from './GrainIcons';
import {
  DEFAULT_ANDROID_CONFIG,
  type AndroidAppConfig,
} from '../shared/androidConfig';
import { SourceCodeCopyModal } from './SourceCodeCopyModal';

interface ActionResult {
  ok: boolean;
  message?: string;
  error?: string;
}

interface SettingsViewProps {
  channels: ChannelConfig;
  deliveryOrders: DeliveryOrder[];
  externalSyncConfig: ExternalSyncConfig;
  isSyncingDos: boolean;
  gasData?: GasAppData | null;
  gasBridgeStatus?: GasBridgeStatus;
  gasBridgeMessage?: string;
  onUpdateExternalSyncConfig: (patch: Partial<ExternalSyncConfig>) => void;
  onSyncExternalDos: (
    override?: Partial<ExternalSyncConfig>
  ) => Promise<{ ok: boolean; added: number; error?: string; needsBridge?: boolean }>;
  onSaveGasInstitution?: (input: {
    lsdName: string;
    upazila: string;
    district: string;
    officer: string;
  }) => Promise<ActionResult>;
  onSaveGasCategories?: (categoriesMap: Record<string, string[]>) => Promise<ActionResult>;
  onAddGasFiscalYear?: (input: {
    name: string;
    start: string;
    end: string;
    makeActive: boolean;
  }) => Promise<ActionResult>;
  onSetActiveGasFiscalYear?: (name: string) => Promise<ActionResult>;
  onDeleteGasFiscalYear?: (name: string) => Promise<ActionResult>;
  initialProduct?: ProductCategory;
  initialMode?: ChannelMode;
  onAddChannel: (product: ProductCategory, mode: ChannelMode, name: string) => boolean;
  onRenameChannel: (
    product: ProductCategory,
    mode: ChannelMode,
    oldName: string,
    newName: string
  ) => void;
  onRemoveChannel: (product: ProductCategory, mode: ChannelMode, name: string) => void;
  onResetDefaultChannels: () => void;
  onAddDeliveryOrder: (input: {
    doNumber: string;
    product: ProductCategory;
    category: string;
    totalBags: number;
    totalMt: number;
    recipient: string;
    date: string;
  }) => { ok: boolean; error?: string };
  onDeleteDeliveryOrder: (id: string) => void;
  fortnightlySettings: FortnightlyReportSettings;
  onUpdateFortnightlySettings: (patch: Partial<FortnightlyReportSettings>) => void;
  onResetFortnightlySettings: () => void;
  onExportBackup: () => void;
  onImportBackup: (jsonText: string) => { ok: boolean; error?: string };
  onLoadSampleData: () => void;
  onClearAllData: () => void;
  googleSheetsConfig?: GoogleSheetsConfig;
  googleUser?: User | null;
  hasGoogleToken?: boolean;
  isGoogleSigningIn?: boolean;
  googleAuthError?: string | null;
  availableSpreadsheets?: DriveSpreadsheetFile[];
  isLoadingSpreadsheets?: boolean;
  mainSheetTabs?: string[];
  dataSourceMode?: 'google_sheets' | 'apps_script' | 'local';
  onGoogleSignIn?: () => Promise<{ ok: boolean; error?: string }>;
  onGoogleSignOut?: () => Promise<void>;
  onRefreshSpreadsheets?: () => Promise<DriveSpreadsheetFile[]>;
  onSelectSpreadsheetsAndSync?: (
    patch: Partial<GoogleSheetsConfig>
  ) => Promise<{ ok: boolean; added: number; error?: string }>;
  onUpdateGoogleSheetsConfig?: (patch: Partial<GoogleSheetsConfig>) => void;
}

const EXPECTED_MAIN_TABS = [
  'Settings',
  'Khamal_Master',
  'Transactions',
  'Empty_Bags',
  'Bag_Transactions',
  'External_DOs',
];

export const SettingsView: React.FC<SettingsViewProps> = ({
  channels,
  deliveryOrders,
  externalSyncConfig,
  isSyncingDos,
  gasData = null,
  gasBridgeStatus = 'idle',
  gasBridgeMessage = '',
  onUpdateExternalSyncConfig,
  onSyncExternalDos,
  onSaveGasInstitution,
  onSaveGasCategories,
  onAddGasFiscalYear,
  onSetActiveGasFiscalYear,
  onDeleteGasFiscalYear,
  initialProduct = 'rice',
  initialMode = 'distribution',
  onAddChannel,
  onRenameChannel,
  onRemoveChannel,
  onResetDefaultChannels,
  onAddDeliveryOrder,
  onDeleteDeliveryOrder,
  fortnightlySettings,
  onUpdateFortnightlySettings,
  onResetFortnightlySettings,
  onExportBackup,
  onImportBackup,
  onLoadSampleData,
  onClearAllData,
  googleSheetsConfig,
  googleUser = null,
  hasGoogleToken = false,
  isGoogleSigningIn = false,
  googleAuthError = null,
  availableSpreadsheets = [],
  isLoadingSpreadsheets = false,
  mainSheetTabs = [],
  dataSourceMode = 'local',
  onGoogleSignIn,
  onGoogleSignOut,
  onRefreshSpreadsheets,
  onSelectSpreadsheetsAndSync,
  onUpdateGoogleSheetsConfig,
}) => {
  const [selectedProduct, setSelectedProduct] = useState<ProductCategory>(initialProduct);
  const [selectedMode, setSelectedMode] = useState<ChannelMode>(initialMode);
  const [newChannelName, setNewChannelName] = useState('');
  const [editingChannel, setEditingChannel] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');

  // Direct Google Sheets inputs
  const [mainSheetIdInput, setMainSheetIdInput] = useState(
    googleSheetsConfig?.mainSpreadsheetId || ''
  );
  const [extDoSheetIdInput, setExtDoSheetIdInput] = useState(
    googleSheetsConfig?.externalDoSpreadsheetId || ''
  );
  const [extDoTabInput, setExtDoTabInput] = useState(
    googleSheetsConfig?.externalDoSheetName || 'DO_Issue'
  );
  const [extDoCutoffInput, setExtDoCutoffInput] = useState(
    googleSheetsConfig?.cutoffDate || '2026-11-01'
  );
  const [extDoBagKgInput, setExtDoBagKgInput] = useState(
    String(googleSheetsConfig?.bagKg || 50)
  );
  const [extDoExcludeInput, setExtDoExcludeInput] = useState(
    (googleSheetsConfig?.excludeDoNos || ['240319', '240320']).join(', ')
  );
  const [gsSyncFeedback, setGsSyncFeedback] = useState<{ ok: boolean; text: string } | null>(null);

  // External Web App / Main Apps Script Link state
  const [extUrlInput, setExtUrlInput] = useState(
    externalSyncConfig.externalAppUrl || DEFAULT_MAIN_APPS_SCRIPT_URL
  );
  const [extSecretInput, setExtSecretInput] = useState(externalSyncConfig.apiSecret || '');
  const [extEnabled, setExtEnabled] = useState(externalSyncConfig.enabled);
  const [extAutoSync, setExtAutoSync] = useState(externalSyncConfig.autoSync);
  const [extPushStatus, setExtPushStatus] = useState(externalSyncConfig.pushDistributedStatus);
  const [extSyncFeedback, setExtSyncFeedback] = useState<{ ok: boolean; text: string } | null>(
    null
  );
  const [copiedWebhook, setCopiedWebhook] = useState(false);
  const [showBridgeSnippet, setShowBridgeSnippet] = useState(false);
  const [copiedSnippet, setCopiedSnippet] = useState(false);

  // GAS Institution Settings state
  const [lsdName, setLsdName] = useState(gasData?.settings?.lsdName || '');
  const [upazila, setUpazila] = useState(gasData?.settings?.upazila || '');
  const [district, setDistrict] = useState(gasData?.settings?.district || '');
  const [officer, setOfficer] = useState(gasData?.settings?.officer || '');
  const [savingInst, setSavingInst] = useState(false);
  const [savingCats, setSavingCats] = useState(false);

  // GAS Fiscal Year state
  const [fyName, setFyName] = useState('');
  const [fyStart, setFyStart] = useState('');
  const [fyEnd, setFyEnd] = useState('');
  const [fyMakeActive, setFyMakeActive] = useState(true);
  const [savingFy, setSavingFy] = useState(false);

  // Quick DO queue adder
  const [doNum, setDoNum] = useState('');
  const [doProd, setDoProd] = useState<ProductCategory>('rice');
  const [doCat, setDoCat] = useState(channels.rice.distribution[0] || '');
  const [doMt, setDoMt] = useState('');
  const [doBags, setDoBags] = useState('');
  const [doRecipient, setDoRecipient] = useState('');

  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);

  const [apkAppName, setApkAppName] = useState(DEFAULT_ANDROID_CONFIG.appName);
  const [apkPackage, setApkPackage] = useState(DEFAULT_ANDROID_CONFIG.packageName);
  const [apkDownloading, setApkDownloading] = useState(false);
  const [sourceZipDownloading, setSourceZipDownloading] = useState(false);
  const [showSourceCopyModal, setShowSourceCopyModal] = useState(false);
  const [apkError, setApkError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (googleSheetsConfig) {
      setMainSheetIdInput(googleSheetsConfig.mainSpreadsheetId || '');
      setExtDoSheetIdInput(googleSheetsConfig.externalDoSpreadsheetId || '');
      setExtDoTabInput(googleSheetsConfig.externalDoSheetName || 'DO_Issue');
      setExtDoCutoffInput(googleSheetsConfig.cutoffDate || '2026-11-01');
      setExtDoBagKgInput(String(googleSheetsConfig.bagKg || 50));
      setExtDoExcludeInput((googleSheetsConfig.excludeDoNos || ['240319', '240320']).join(', '));
    }
  }, [googleSheetsConfig]);

  useEffect(() => {
    if (gasData?.settings) {
      setLsdName(gasData.settings.lsdName || '');
      setUpazila(gasData.settings.upazila || '');
      setDistrict(gasData.settings.district || '');
      setOfficer(gasData.settings.officer || '');
    }
  }, [gasData?.settings]);

  useEffect(() => {
    if (gasBridgeStatus === 'needs_bridge' && dataSourceMode !== 'google_sheets') {
      setShowBridgeSnippet(false);
    }
  }, [gasBridgeStatus, dataSourceMode]);

  const currentList = channels[selectedProduct]?.[selectedMode] || [];

  const inboundWebhookUrl =
    typeof window !== 'undefined' ? `${window.location.origin}/api/external-dos` : '/api/external-dos';

  const handleSaveAndSyncExternal = async (e: React.FormEvent) => {
    e.preventDefault();
    const patch: Partial<ExternalSyncConfig> = {
      enabled: extEnabled || Boolean(extUrlInput.trim()),
      externalAppUrl: extUrlInput.trim() || DEFAULT_MAIN_APPS_SCRIPT_URL,
      apiSecret: extSecretInput.trim(),
      autoSync: extAutoSync,
      pushDistributedStatus: extPushStatus,
    };
    setExtEnabled(Boolean(patch.enabled));
    onUpdateExternalSyncConfig(patch);
    const res = await onSyncExternalDos(patch);
    if (res.ok) {
      setExtSyncFeedback({
        ok: true,
        text: `মেইন ওয়েব অ্যাপের সাথে লাইভ সংযোগ সফল হয়েছে! (${res.added}টি পেন্ডিং ডিও)`,
      });
    } else if (res.needsBridge) {
      setShowBridgeSnippet(true);
      setExtSyncFeedback({
        ok: false,
        text: res.error || 'মেইন অ্যাপে Code.gs JSON ব্রিজ কোড যুক্ত করা প্রয়োজন।',
      });
    } else {
      setExtSyncFeedback({
        ok: false,
        text: res.error || 'অন্য ওয়েব অ্যাপের সাথে সংযোগ করা যায়নি।',
      });
    }
  };

  const handleCopySnippet = async () => {
    try {
      await navigator.clipboard.writeText(GAS_BRIDGE_SNIPPET);
      setCopiedSnippet(true);
      window.setTimeout(() => setCopiedSnippet(false), 2500);
    } catch {
      // Ignore clipboard failure
    }
  };

  const handleCopyWebhook = async () => {
    try {
      await navigator.clipboard.writeText(inboundWebhookUrl);
      setCopiedWebhook(true);
      window.setTimeout(() => setCopiedWebhook(false), 2000);
    } catch {
      // Ignore clipboard failure
    }
  };

  const handleSaveInstitutionForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onSaveGasInstitution) return;
    setSavingInst(true);
    try {
      const res = await onSaveGasInstitution({ lsdName, upazila, district, officer });
      setStatusMsg(res.ok ? res.message || 'প্রতিষ্ঠানের তথ্য সেভ হয়েছে।' : res.error || 'সেভ ব্যর্থ হয়েছে।');
    } finally {
      setSavingInst(false);
    }
  };

  const handleAddFiscalYearForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onAddGasFiscalYear || !fyName.trim()) return;
    setSavingFy(true);
    try {
      const res = await onAddGasFiscalYear({
        name: fyName.trim(),
        start: fyStart,
        end: fyEnd,
        makeActive: fyMakeActive,
      });
      if (res.ok) {
        setFyName('');
        setFyStart('');
        setFyEnd('');
        setStatusMsg(res.message || 'নতুন অর্থবছর যুক্ত হয়েছে।');
      } else {
        setStatusMsg(res.error || 'অর্থবছর যুক্ত করা যায়নি।');
      }
    } finally {
      setSavingFy(false);
    }
  };

  const handleSaveCategoriesToSheet = async () => {
    if (!onSaveGasCategories) return;
    setSavingCats(true);
    try {
      const res = await onSaveGasCategories({
        'চাল': channels.rice.distribution,
        'ধান': channels.paddy.receipt,
        'গম': channels.wheat.distribution,
      });
      setStatusMsg(
        res.ok
          ? res.message || 'গুগল শিটে ক্যাটাগরি তালিকা সেভ হয়েছে।'
          : res.error || 'ক্যাটাগরি সেভ ব্যর্থ হয়েছে।'
      );
    } finally {
      setSavingCats(false);
    }
  };

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newChannelName.trim()) return;
    const added = onAddChannel(selectedProduct, selectedMode, newChannelName);
    if (added) {
      setNewChannelName('');
      setStatusMsg('নতুন চ্যানেল / ক্যাটাগরি সংরক্ষণ করা হয়েছে।');
      window.setTimeout(() => setStatusMsg(null), 2500);
    }
  };

  const handleSaveRename = (oldName: string) => {
    if (editValue.trim() && editValue.trim() !== oldName) {
      onRenameChannel(selectedProduct, selectedMode, oldName, editValue.trim());
    }
    setEditingChannel(null);
    setEditValue('');
  };

  const handleCreateDo = (e: React.FormEvent) => {
    e.preventDefault();
    const res = onAddDeliveryOrder({
      doNumber: doNum,
      product: doProd,
      category: doCat || channels[doProd]?.distribution[0] || 'বিডব্লিউবি',
      totalBags: Number(doBags) || 0,
      totalMt: Number(doMt) || 0,
      recipient: doRecipient,
      date: todayIsoDate(),
    });
    if (!res.ok) {
      setStatusMsg(res.error || 'ডিও যোগ করা যায়নি।');
      return;
    }
    setDoNum('');
    setDoMt('');
    setDoBags('');
    setDoRecipient('');
    setStatusMsg('নতুন ডিও তালিকায় যুক্ত হয়েছে।');
    window.setTimeout(() => setStatusMsg(null), 2500);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    try {
      const lower = file.name.toLowerCase();
      if (lower.endsWith('.zip') || file.type.includes('zip')) {
        const buffer = await file.arrayBuffer();
        const zip = await JSZip.loadAsync(buffer);
        const jsonEntry = Object.values(zip.files).find(
          (entry) => !entry.dir && entry.name.toLowerCase().endsWith('.json')
        );
        if (!jsonEntry) {
          setStatusMsg('এই ZIP ফাইলের ভেতরে কোনো JSON ব্যাকআপ ফাইল পাওয়া যায়নি।');
          return;
        }
        const jsonText = await jsonEntry.async('text');
        const res = onImportBackup(jsonText);
        setStatusMsg(
          res.ok
            ? `ZIP (${jsonEntry.name}) থেকে ব্যাকআপ সফলভাবে রিস্টোর হয়েছে!`
            : res.error || 'ZIP ব্যাকআপ রিস্টোর ব্যর্থ হয়েছে।'
        );
        return;
      }

      const text = await file.text();
      const res = onImportBackup(text);
      setStatusMsg(res.ok ? 'ব্যাকআপ সফলভাবে পুনরুদ্ধার হয়েছে!' : res.error || 'পুনরুদ্ধার ব্যর্থ হয়েছে।');
    } catch (err) {
      setStatusMsg(err instanceof Error ? `ফাইল পড়া যায়নি: ${err.message}` : 'ফাইল আপলোড ব্যর্থ হয়েছে।');
    }
  };

  const apiBaseOrigin = isAndroidWebViewOrigin() ? LIVE_PWA_APP_URL : '';

  const handleDownloadAndroidZip = async () => {
    setApkDownloading(true);
    setApkError(null);
    try {
      const payload = {
        ...DEFAULT_ANDROID_CONFIG,
        appName: apkAppName.trim() || DEFAULT_ANDROID_CONFIG.appName,
        packageName: apkPackage.trim() || DEFAULT_ANDROID_CONFIG.packageName,
        targetUrl: isAndroidWebViewOrigin() ? LIVE_PWA_APP_URL : window.location.origin,
        webSeed: {
          externalAppUrl: extUrlInput.trim() || externalSyncConfig.externalAppUrl,
          apiSecret: extSecretInput.trim() || externalSyncConfig.apiSecret,
          googleSheetsConfig,
          gasData,
          fortnightlySettings,
        },
      };
      const response = await fetch(`${apiBaseOrigin}/api/build-android-project`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!response.ok) {
        const err = await response.json().catch(() => ({}));
        throw new Error(err.error || 'APK প্রজেক্ট তৈরি করা যায়নি।');
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'khaddo-stock-android-github.zip';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      setStatusMsg('Android Studio ও GitHub Actions প্রজেক্ট ZIP ডাউনলোড হয়েছে!');
    } catch (err) {
      setApkError(err instanceof Error ? err.message : 'ডাউনলোড ব্যর্থ হয়েছে।');
    } finally {
      setApkDownloading(false);
    }
  };

  const handleDownloadSourceZip = async () => {
    setSourceZipDownloading(true);
    setApkError(null);
    try {
      const response = await fetch(`${apiBaseOrigin}/api/download-source-zip`);
      if (!response.ok) {
        const err = await response.json().catch(() => ({}));
        throw new Error(err.error || 'সোর্স কোড ZIP তৈরি করা যায়নি।');
      }
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'khaddo-stock-source-code.zip';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      setStatusMsg('সম্পূর্ণ প্রজেক্ট সোর্স কোড ZIP ডাউনলোড হয়েছে!');
    } catch (err) {
      setApkError(err instanceof Error ? err.message : 'ডাউনলোড ব্যর্থ হয়েছে।');
    } finally {
      setSourceZipDownloading(false);
    }
  };

  return (
    <div className="space-y-6">
      {statusMsg && (
        <div
          role="status"
          className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs font-semibold text-emerald-900 flex items-center gap-2"
        >
          <CheckCircle2 className="h-4 w-4 text-emerald-700 shrink-0" />
          <span>{statusMsg}</span>
        </div>
      )}

      {/* Quick Direct Source Code Copy Bar (No Zip Required) */}
      <section className="rounded-2xl border border-slate-200 bg-white px-4 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="h-9 w-9 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center shrink-0">
            <FileCode2 className="h-4.5 w-4.5 text-slate-800" />
          </div>
          <div className="min-w-0">
            <div className="text-xs sm:text-sm font-extrabold text-slate-900">
              সকল সোর্স কোড কপি করুন (জিপ ছাড়া)
            </div>
            <p className="text-[11px] text-slate-500 truncate">
              ওয়েব অ্যাপ এবং Android APK-এর প্রতিটি ফাইল আলাদাভাবে দেখে ১ ক্লিকে কপি করুন।
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setShowSourceCopyModal(true)}
          className="min-h-[40px] inline-flex items-center justify-center gap-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 px-4 py-2 text-xs font-bold text-white shrink-0 cursor-pointer"
        >
          <FileCode2 className="h-4 w-4 text-emerald-400" />
          <span>সব কোড দেখুন ও কপি করুন</span>
        </button>
      </section>

      {/* 0. Direct Google Sheets Connection (NO Code.gs changes required) */}
      <section className="rounded-2xl border-2 border-emerald-200 bg-white p-4 sm:p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="h-10 w-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center shrink-0">
              <FileSpreadsheet className="h-5 w-5 text-[#0D6E4E]" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-base sm:text-lg font-extrabold text-slate-900">
                  সরাসরি Google Sheets সংযোগ (কোনো Code.gs কোড লাগবে না)
                </h2>
                <span
                  className={`text-xs font-bold ${
                    dataSourceMode === 'google_sheets'
                      ? 'text-emerald-800'
                      : hasGoogleToken
                        ? 'text-amber-700'
                        : 'text-slate-500'
                  }`}
                >
                  ·{' '}
                  {dataSourceMode === 'google_sheets'
                    ? 'Google Sheets সরাসরি যুক্ত'
                    : hasGoogleToken
                      ? 'লগইন সম্পন্ন — শিট নির্বাচন করুন'
                      : 'Google Sign-In প্রয়োজন'}
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                আপনার Google অ্যাকাউন্ট দিয়ে লগইন করলে Apps Script-এর কোনো কোড পরিবর্তন ছাড়াই মূল Google Sheet-এর সকল খামাল, লেনদেন, খালি বস্তা, ডিও এবং সেটিংস সরাসরি লোড ও সেভ হবে।
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 self-start shrink-0">
            {onGoogleSignIn &&
              onGoogleSignOut &&
              (!isAndroidWebViewOrigin() || hasOpenExternalBrowserBridge() || hasGoogleToken) && (
                <GoogleSignInButton
                  user={googleUser}
                  hasToken={hasGoogleToken}
                  isSigningIn={isGoogleSigningIn}
                  onSignIn={() => void onGoogleSignIn()}
                  onSignOut={() => void onGoogleSignOut()}
                  label="গুগল দিয়ে লগইন করুন"
                />
              )}
          </div>
        </div>

        {isAndroidWebViewOrigin() && hasOpenExternalBrowserBridge() && !hasGoogleToken && (
          <div className="rounded-xl border border-emerald-200 bg-emerald-50/70 px-3.5 py-2.5 text-xs text-emerald-950 space-y-1 leading-relaxed">
            <div>
              <strong>অ্যান্ড্রয়েড অ্যাপ গুগল লগইন:</strong> উপরের{' '}
              <strong>«গুগল দিয়ে লগইন করুন»</strong> বাটনে চাপ দিলে ফোনের Chrome ব্রাউজারে নিরাপদ গুগল অ্যাকাউন্ট বাছাইয়ের পর্দা খুলবে এবং লগইন শেষ হলে স্বয়ংক্রিয়ভাবে এই অ্যাপে ফিরে আসবে।
            </div>
            {isGoogleSigningIn && (
              <div className="text-[11px] font-bold text-[#0D6E4E]">
                Chrome ব্রাউজারে গুগল সাইন-ইন সম্পন্ন করুন — লগইন শেষ হলে অ্যাপে যুক্ত হয়ে যাবে...
              </div>
            )}
          </div>
        )}

        {isAndroidWebViewOrigin() && !hasOpenExternalBrowserBridge() && !hasGoogleToken && (
          <div className="rounded-xl border border-amber-300 bg-amber-50 px-3.5 py-3 text-xs text-amber-950 space-y-2 leading-relaxed">
            <div>
              <strong>পুরনো অ্যান্ড্রয়েড APK সনাক্ত হয়েছে:</strong> আপনার ফোনে ইনস্টল করা এই APK-তে Chrome-লগইন ব্রিজ যুক্ত নেই। সরাসরি APK থেকে জিমেইল লগইন করতে নিচের{' '}
              <strong>«অ্যান্ড্রয়েড APK প্রজেক্ট (.zip)»</strong> ডাউনলোড করে GitHub Actions দিয়ে নতুন APK বানিয়ে ইনস্টল করুন।
            </div>
            <div className="text-[11px] text-amber-900/90">
              বিকল্প ১: নিচের <strong>«ওয়েব অ্যাপ / Apps Script সংযোগ»</strong> অপশনে লিংক দিলে কোনো গুগল লগইন ছাড়াই এই APK থেকে সরাসরি শিট সিঙ্ক হবে।
              <br />
              বিকল্প ২: এখনই গুগল অ্যাকাউন্ট দিয়ে লগইন করতে চাইলে নিচের বাটনে চাপ দিয়ে{' '}
              <strong>Chrome ব্রাউজারে</strong> খুলুন।
            </div>
            <div className="flex flex-wrap items-center gap-2 pt-0.5">
              <button
                type="button"
                onClick={async () => {
                  let target = DEV_PWA_APP_URL;
                  try {
                    target = await resolveReachablePwaOrigin();
                  } catch {
                    target = DEV_PWA_APP_URL;
                  }
                  const launched = openExternalBrowserIfAndroid(target);
                  if (!launched && typeof window !== 'undefined') {
                    window.location.assign(target);
                  }
                }}
                className="inline-flex items-center gap-1.5 rounded-lg bg-[#0D6E4E] hover:bg-emerald-900 px-3 py-1.5 text-[11px] font-bold text-white cursor-pointer"
              >
                <ExternalLink className="h-3.5 w-3.5" />
                <span>Chrome ব্রাউজারে খুলুন (গুগল লগইন)</span>
              </button>
            </div>
          </div>
        )}

        {googleAuthError && (
          <div className="rounded-xl border border-rose-200 bg-rose-50 px-3.5 py-2.5 text-xs text-rose-900 space-y-1.5">
            <div className="font-bold">{googleAuthError}</div>
            <div className="text-[11px] text-rose-800/90 leading-relaxed">
              <strong>শেয়ার করা অন্য Gmail-এ লগইন সমস্যার সমাধান:</strong> Google Cloud Console ({GOOGLE_AUTH_PROJECT_ID || 'Project'}) →{' '}
              <strong>APIs &amp; Services → OAuth consent screen → Audience (Test users)</strong>-এ গিয়ে{' '}
              <strong>Add users</strong>-এ শেয়ার করা ইমেইলটি যোগ করুন।
            </div>
            {isInEmbeddedIframe() && typeof window !== 'undefined' && (
              <a
                href={window.location.href}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 rounded-lg border border-rose-300 bg-white hover:bg-rose-100 px-2.5 py-1 text-[11px] font-bold text-rose-900"
              >
                <ExternalLink className="h-3 w-3" />
                <span>নতুন ট্যাবে অ্যাপ খুলে সাইন-ইন করুন</span>
              </a>
            )}
          </div>
        )}

        {!hasGoogleToken && !googleAuthError && (
          <div className="rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-2 text-[11px] text-slate-600 leading-relaxed flex flex-wrap items-center justify-between gap-2">
            <span>
              <strong>শেয়ার করা ইমেইলে লগইন টিপস:</strong> অন্য Gmail দিয়ে সাইন-ইন করতে{' '}
              Google Cloud Console ({GOOGLE_AUTH_PROJECT_ID || 'Project'}) → OAuth consent screen →{' '}
              <strong>Test users</strong>-এ ওই ইমেইল যুক্ত থাকতে হবে।
            </span>
            {isInEmbeddedIframe() && typeof window !== 'undefined' && (
              <a
                href={window.location.href}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 px-2.5 py-1 font-bold text-slate-800 shrink-0"
              >
                <ExternalLink className="h-3 w-3" />
                <span>নতুন ট্যাবে খুলুন</span>
              </a>
            )}
          </div>
        )}

        <form
          onSubmit={async (e) => {
            e.preventDefault();
            if (!onSelectSpreadsheetsAndSync) return;
            const parsedMainId = extractSpreadsheetId(mainSheetIdInput);
            const parsedExtId = extractSpreadsheetId(extDoSheetIdInput);
            const selectedMainName =
              availableSpreadsheets.find((f) => f.id === parsedMainId)?.name ||
              googleSheetsConfig?.mainSpreadsheetName ||
              '';
            const selectedExtName =
              availableSpreadsheets.find((f) => f.id === parsedExtId)?.name ||
              googleSheetsConfig?.externalDoSpreadsheetName ||
              '';
            const excludeList = extDoExcludeInput
              .split(',')
              .map((s) => s.trim())
              .filter(Boolean);

            const res = await onSelectSpreadsheetsAndSync({
              enabled: true,
              mainSpreadsheetId: parsedMainId,
              mainSpreadsheetName: selectedMainName,
              externalDoSpreadsheetId: parsedExtId,
              externalDoSpreadsheetName: selectedExtName,
              externalDoSheetName: extDoTabInput.trim() || 'DO_Issue',
              cutoffDate: extDoCutoffInput.trim() || '2026-11-01',
              bagKg: Number(extDoBagKgInput) > 0 ? Number(extDoBagKgInput) : 50,
              excludeDoNos: excludeList,
            });
            setGsSyncFeedback(
              res.ok
                ? {
                    ok: true,
                    text: `Google Sheet সরাসরি সিঙ্ক সফল হয়েছে! (${res.added}টি পেন্ডিং ডিও)`,
                  }
                : {
                    ok: false,
                    text: res.error || 'Google Sheet সিঙ্ক করা যায়নি।',
                  }
            );
          }}
          className="space-y-3.5 rounded-xl border border-slate-200 bg-slate-50/70 p-4"
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs font-bold text-slate-800">
              আপনার Google Drive থেকে ফাইল বাছাই করুন অথবা লিংক/ID পেস্ট করুন:
            </span>
            {hasGoogleToken && onRefreshSpreadsheets && (
              <button
                type="button"
                onClick={() => void onRefreshSpreadsheets()}
                disabled={isLoadingSpreadsheets}
                className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 px-2.5 py-1 text-[11px] font-bold text-slate-800 cursor-pointer"
              >
                <RefreshCw className={`h-3 w-3 ${isLoadingSpreadsheets ? 'animate-spin' : ''}`} />
                <span>{isLoadingSpreadsheets ? 'তালিকা আসছে...' : 'শিট তালিকা রিফ্রেশ'}</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
            {/* Main Stock Spreadsheet */}
            <div className="space-y-2 rounded-xl border border-slate-200 bg-white p-3">
              <label className="block text-xs font-bold text-slate-900">
                ১. মেইন স্টক গুগল শিট (Khamal_Master, Transactions)
              </label>
              {availableSpreadsheets.length > 0 && (
                <select
                  value={extractSpreadsheetId(mainSheetIdInput)}
                  onChange={(e) => {
                    const id = e.target.value;
                    setMainSheetIdInput(id);
                    const found = availableSpreadsheets.find((f) => f.id === id);
                    if (found && onUpdateGoogleSheetsConfig) {
                      onUpdateGoogleSheetsConfig({
                        mainSpreadsheetId: id,
                        mainSpreadsheetName: found.name,
                      });
                    }
                  }}
                  className="w-full min-h-[40px] rounded-lg border border-slate-300 bg-slate-50 px-2.5 py-1.5 text-xs font-semibold text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
                >
                  <option value="">— Google Drive থেকে ফাইল বাছাই করুন —</option>
                  {availableSpreadsheets.map((file) => (
                    <option key={file.id} value={file.id}>
                      {file.name}
                    </option>
                  ))}
                </select>
              )}
              <input
                type="text"
                value={mainSheetIdInput}
                onChange={(e) => setMainSheetIdInput(e.target.value)}
                placeholder="Google Sheet URL অথবা Spreadsheet ID পেস্ট করুন"
                className="w-full min-h-[40px] rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-mono text-xs text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
              />
              {mainSheetTabs.length > 0 && (
                <div className="flex flex-wrap gap-1 pt-1">
                  {EXPECTED_MAIN_TABS.map((tab) => {
                    const found = mainSheetTabs.includes(tab);
                    return (
                      <span
                        key={tab}
                        className={`rounded-md px-1.5 py-0.5 font-mono text-[10px] font-semibold ${
                          found
                            ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                            : 'bg-amber-50 text-amber-800 border border-amber-200'
                        }`}
                      >
                        {found ? '✓' : '+'} {tab}
                      </span>
                    );
                  })}
                </div>
              )}
            </div>

            {/* External DO Spreadsheet (optional) */}
            <div className="space-y-2 rounded-xl border border-slate-200 bg-white p-3">
              <label className="block text-xs font-bold text-slate-900">
                ২. বাইরের ডিও গুগল শিট (DO_Issue — ঐচ্ছিক)
              </label>
              {availableSpreadsheets.length > 0 && (
                <select
                  value={extractSpreadsheetId(extDoSheetIdInput)}
                  onChange={(e) => {
                    const id = e.target.value;
                    setExtDoSheetIdInput(id);
                    const found = availableSpreadsheets.find((f) => f.id === id);
                    if (found && onUpdateGoogleSheetsConfig) {
                      onUpdateGoogleSheetsConfig({
                        externalDoSpreadsheetId: id,
                        externalDoSpreadsheetName: found.name,
                      });
                    }
                  }}
                  className="w-full min-h-[40px] rounded-lg border border-slate-300 bg-slate-50 px-2.5 py-1.5 text-xs font-semibold text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
                >
                  <option value="">— বাইরের ডিও শিট না থাকলে খালি রাখুন —</option>
                  {availableSpreadsheets.map((file) => (
                    <option key={file.id} value={file.id}>
                      {file.name}
                    </option>
                  ))}
                </select>
              )}
              <input
                type="text"
                value={extDoSheetIdInput}
                onChange={(e) => setExtDoSheetIdInput(e.target.value)}
                placeholder="বাইরের DO Sheet URL বা ID (যেমন: 1DSvlpUe6dr...)"
                className="w-full min-h-[40px] rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-mono text-xs text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
              />
              <div className="grid grid-cols-3 gap-1.5">
                <input
                  type="text"
                  value={extDoTabInput}
                  onChange={(e) => setExtDoTabInput(e.target.value)}
                  placeholder="DO_Issue"
                  title="ট্যাবের নাম"
                  className="min-h-[34px] rounded-lg border border-slate-300 px-2 font-mono text-[11px] text-slate-900"
                />
                <input
                  type="date"
                  value={extDoCutoffInput}
                  onChange={(e) => setExtDoCutoffInput(e.target.value)}
                  title="কাট-অফ তারিখ"
                  className="min-h-[34px] rounded-lg border border-slate-300 px-2 font-mono text-[11px] text-slate-900"
                />
                <input
                  type="number"
                  min="1"
                  value={extDoBagKgInput}
                  onChange={(e) => setExtDoBagKgInput(e.target.value)}
                  placeholder="৫০ কেজি"
                  title="বস্তা প্রতি কেজি"
                  className="min-h-[34px] rounded-lg border border-slate-300 px-2 font-mono text-[11px] text-slate-900"
                />
              </div>
              <input
                type="text"
                value={extDoExcludeInput}
                onChange={(e) => setExtDoExcludeInput(e.target.value)}
                placeholder="বাদ দেওয়ার ডিও নম্বর (যেমন: 240319, 240320)"
                className="w-full min-h-[34px] rounded-lg border border-slate-300 px-2.5 font-mono text-[11px] text-slate-800"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="submit"
              disabled={isSyncingDos || !hasGoogleToken}
              className="min-h-[42px] inline-flex items-center gap-2 rounded-xl bg-[#0D6E4E] hover:bg-emerald-900 disabled:opacity-50 px-4 py-2 text-xs font-bold text-white cursor-pointer"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${isSyncingDos ? 'animate-spin' : ''}`} />
              <span>
                {isSyncingDos ? 'Google Sheet সিঙ্ক হচ্ছে...' : 'Google Sheet থেকে ডেটা সিঙ্ক করুন'}
              </span>
            </button>
          </div>

          {gsSyncFeedback && (
            <div
              className={`rounded-lg px-3 py-2 text-xs font-semibold ${
                gsSyncFeedback.ok
                  ? 'bg-emerald-50 border border-emerald-200 text-emerald-900'
                  : 'bg-amber-50 border border-amber-200 text-amber-900'
              }`}
            >
              {gsSyncFeedback.text}
            </div>
          )}
        </form>
      </section>

      {/* 1. Fallback: Main Apps Script Web App Live Sync & JSON Bridge */}
      <section className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="h-10 w-10 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center shrink-0">
              <Link2 className="h-5 w-5 text-slate-700" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-slate-900">
                  বিকল্প পদ্ধতি: মেইন ওয়েব অ্যাপ লিংক (Google Apps Script ব্রিজ)
                </h2>
                <span
                  className={`text-xs font-bold ${
                    gasBridgeStatus === 'connected'
                      ? 'text-emerald-800'
                      : gasBridgeStatus === 'needs_bridge'
                        ? 'text-amber-700'
                        : 'text-slate-500'
                  }`}
                >
                  ·{' '}
                  {gasBridgeStatus === 'connected'
                    ? 'লাইভ যুক্ত'
                    : gasBridgeStatus === 'needs_bridge'
                      ? 'JSON ব্রিজ অপেক্ষমাণ'
                      : 'সংযোগ পরীক্ষিত'}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
                মেইন ওয়েব অ্যাপের সকল লজিক ও যুক্ত থাকা অপর ২টি অ্যাপ সম্পূর্ণ অক্ষুণ্ণ রেখে এই
                অ্যান্ড্রয়েড ইন্টারফেস থেকে সরাসরি গুগল শিটে খামাল, ডিও বিতরণ, ইনভয়েস/মিল ও বস্তা এন্ট্রি হবে।
              </p>
            </div>
          </div>

          <a
            href={extUrlInput.trim() || DEFAULT_MAIN_APPS_SCRIPT_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 px-3.5 py-2 text-xs font-bold text-slate-800 whitespace-nowrap self-start"
          >
            <ExternalLink className="h-3.5 w-3.5 text-emerald-700" />
            <span>মেইন ওয়েব অ্যাপ খুলুন</span>
          </a>
        </div>

        <form onSubmit={handleSaveAndSyncExternal} className="space-y-3 rounded-xl border border-slate-200 bg-slate-50/70 p-4">
          <label className="flex items-center gap-2 text-xs font-bold text-slate-800 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={extEnabled}
              onChange={(e) => setExtEnabled(e.target.checked)}
              className="h-4 w-4 rounded border-slate-300 accent-emerald-700"
            />
            <span>মেইন Apps Script ওয়েব অ্যাপের সাথে লাইভ সিঙ্ক চালু রাখুন</span>
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <div className="sm:col-span-2">
              <label htmlFor="ext-app-url" className="block text-[11px] font-semibold text-slate-600 mb-1">
                মেইন গুগল অ্যাপস স্ক্রিপ্ট Web App URL (/exec)
              </label>
              <input
                id="ext-app-url"
                type="url"
                value={extUrlInput}
                onChange={(e) => setExtUrlInput(e.target.value)}
                placeholder={DEFAULT_MAIN_APPS_SCRIPT_URL}
                className="w-full min-h-[42px] rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-xs text-slate-900 focus:border-emerald-700 focus:outline-none"
              />
            </div>

            <div>
              <label htmlFor="ext-app-secret" className="block text-[11px] font-semibold text-slate-600 mb-1">
                API কী / টোকেন (ঐচ্ছিক)
              </label>
              <input
                id="ext-app-secret"
                type="text"
                value={extSecretInput}
                onChange={(e) => setExtSecretInput(e.target.value)}
                placeholder="ঐচ্ছিক"
                className="w-full min-h-[42px] rounded-lg border border-slate-300 bg-white px-3 py-2 font-mono text-xs text-slate-900 focus:border-emerald-700 focus:outline-none"
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-4 pt-1">
            <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={extAutoSync}
                onChange={(e) => setExtAutoSync(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 accent-emerald-700"
              />
              <span>স্বয়ংক্রিয় ব্যাকগ্রাউন্ড রিফ্রেশ চালু রাখুন (বন্ধ থাকলে শুধু রিফ্রেশ বাটনে আপডেট হবে)</span>
            </label>

            <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={extPushStatus}
                onChange={(e) => setExtPushStatus(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 accent-emerald-700"
              />
              <span>বিতরণ হলে মেইন অ্যাপে তাৎক্ষণিক আপডেট পাঠান</span>
            </label>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-1">
            <button
              type="submit"
              disabled={isSyncingDos}
              className="min-h-[42px] inline-flex items-center gap-2 rounded-xl bg-[#0D6E4E] hover:bg-emerald-900 disabled:opacity-60 px-4 py-2 text-xs font-bold text-white cursor-pointer"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${isSyncingDos ? 'animate-spin' : ''}`} />
              <span>{isSyncingDos ? 'সিঙ্ক হচ্ছে...' : 'লিংক সংরক্ষণ ও লাইভ সিঙ্ক করুন'}</span>
            </button>

            <button
              type="button"
              onClick={() => setShowBridgeSnippet((v) => !v)}
              className="min-h-[42px] inline-flex items-center gap-1.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 px-3.5 py-2 text-xs font-bold text-slate-800 cursor-pointer"
            >
              <Code2 className="h-3.5 w-3.5 text-slate-700" />
              <span>Code.gs ১-মিনিট JSON ব্রিজ কোড</span>
              {showBridgeSnippet ? (
                <ChevronUp className="h-3.5 w-3.5" />
              ) : (
                <ChevronDown className="h-3.5 w-3.5" />
              )}
            </button>
          </div>

          {(gasBridgeMessage || externalSyncConfig.lastSyncMessage) && (
            <div className="text-[11px] font-medium text-slate-600">
              বর্তমান অবস্থা: {gasBridgeMessage || externalSyncConfig.lastSyncMessage}
            </div>
          )}

          {extSyncFeedback && (
            <div
              className={`rounded-lg px-3 py-2 text-xs font-semibold ${
                extSyncFeedback.ok
                  ? 'bg-emerald-50 border border-emerald-200 text-emerald-900'
                  : 'bg-amber-50 border border-amber-200 text-amber-900'
              }`}
            >
              {extSyncFeedback.text}
            </div>
          )}
        </form>

        {/* Collapsible 1-minute Code.gs JSON bridge snippet */}
        {showBridgeSnippet && (
          <div className="rounded-xl border border-amber-200 bg-slate-900 text-slate-100 p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="space-y-0.5">
                <div className="text-xs font-bold text-amber-300">
                  মেইন ওয়েব অ্যাপের Code.gs-এ এই সামান্য JSON পাস-থ্রু যুক্ত করুন (১ মিনিট):
                </div>
                <p className="text-[11px] text-slate-300">
                  এটি বিদ্যমান কোনো ফাংশন বা অপর ২টি লিংক করা অ্যাপের লজিক বিন্দুমাত্র পরিবর্তন করবে না — শুধু অ্যান্ড্রয়েড অ্যাপ থেকে সরাসরি পড়া ও লেখার JSON গেটওয়ে খুলে দেবে।
                </p>
              </div>
              <button
                type="button"
                onClick={handleCopySnippet}
                className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 px-3 py-1.5 text-xs font-bold text-white cursor-pointer shrink-0"
              >
                <Copy className="h-3.5 w-3.5" />
                <span>{copiedSnippet ? 'কপি হয়েছে!' : 'কোড কপি করুন'}</span>
              </button>
            </div>
            <pre className="rounded-lg bg-slate-950 p-3 font-mono text-[10.5px] text-emerald-300 overflow-x-auto leading-relaxed">
              {GAS_BRIDGE_SNIPPET}
            </pre>
          </div>
        )}

        {/* Inbound Webhook for external DO push */}
        <div className="rounded-xl border border-slate-200 bg-slate-50 p-3.5 space-y-2">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="text-xs font-bold text-slate-800">
              অথবা তৃতীয় কোনো অ্যাপ থেকে ইনবাউন্ড ওয়েবহুক লিংক (POST):
            </div>
            <button
              type="button"
              onClick={handleCopyWebhook}
              className="inline-flex items-center gap-1 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 px-2.5 py-1 text-[11px] font-bold text-slate-800 cursor-pointer"
            >
              <Copy className="h-3 w-3" />
              <span>{copiedWebhook ? 'কপি হয়েছে!' : 'লিংক কপি'}</span>
            </button>
          </div>
          <div className="rounded-lg bg-white border border-slate-200 px-3 py-1.5 font-mono text-[11px] text-slate-700 break-all">
            {inboundWebhookUrl}
          </div>
        </div>
      </section>

      {/* 2. Live Institution & Fiscal Year Controls (when connected to Main GAS App) */}
      {gasBridgeStatus === 'connected' && gasData && (
        <section className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-6 space-y-5">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Institution Details */}
            <form onSubmit={(e) => void handleSaveInstitutionForm(e)} className="space-y-3">
              <div className="flex items-center gap-2">
                <Building2 className="h-4.5 w-4.5 text-[#0D6E4E]" />
                <h2 className="text-base font-bold text-slate-900">এলএসডি / প্রতিষ্ঠানের তথ্য</h2>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    এলএসডি-এর নাম
                  </label>
                  <input
                    type="text"
                    value={lsdName}
                    onChange={(e) => setLsdName(e.target.value)}
                    placeholder="যেমন: সদর এলএসডি"
                    className="w-full min-h-[40px] rounded-xl border border-slate-300 px-3 py-1.5 text-sm text-slate-900 focus:border-emerald-700 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">উপজেলা</label>
                  <input
                    type="text"
                    value={upazila}
                    onChange={(e) => setUpazila(e.target.value)}
                    className="w-full min-h-[40px] rounded-xl border border-slate-300 px-3 py-1.5 text-sm text-slate-900 focus:border-emerald-700 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">জেলা</label>
                  <input
                    type="text"
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    className="w-full min-h-[40px] rounded-xl border border-slate-300 px-3 py-1.5 text-sm text-slate-900 focus:border-emerald-700 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    ভারপ্রাপ্ত কর্মকর্তার নাম
                  </label>
                  <input
                    type="text"
                    value={officer}
                    onChange={(e) => setOfficer(e.target.value)}
                    className="w-full min-h-[40px] rounded-xl border border-slate-300 px-3 py-1.5 text-sm text-slate-900 focus:border-emerald-700 focus:outline-none"
                  />
                </div>
              </div>
              <button
                type="submit"
                disabled={savingInst}
                className="min-h-[40px] inline-flex items-center gap-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-60 px-4 py-2 text-xs font-bold text-white cursor-pointer"
              >
                <Save className="h-3.5 w-3.5" />
                <span>{savingInst ? 'সেভ হচ্ছে...' : 'প্রতিষ্ঠানের তথ্য গুগল শিটে সেভ করুন'}</span>
              </button>
            </form>

            {/* Fiscal Year Management */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Calendar className="h-4.5 w-4.5 text-[#0D6E4E]" />
                <h2 className="text-base font-bold text-slate-900">অর্থবছর (Fiscal Year) ব্যবস্থাপনা</h2>
              </div>

              <form onSubmit={(e) => void handleAddFiscalYearForm(e)} className="grid grid-cols-1 sm:grid-cols-3 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200">
                <input
                  type="text"
                  value={fyName}
                  onChange={(e) => setFyName(e.target.value)}
                  placeholder="নাম (যেমন: 2026-27)"
                  className="min-h-[38px] rounded-lg border border-slate-300 bg-white px-2.5 text-xs text-slate-900"
                />
                <input
                  type="date"
                  value={fyStart}
                  onChange={(e) => setFyStart(e.target.value)}
                  className="min-h-[38px] rounded-lg border border-slate-300 bg-white px-2.5 font-mono text-xs text-slate-900"
                />
                <input
                  type="date"
                  value={fyEnd}
                  onChange={(e) => setFyEnd(e.target.value)}
                  className="min-h-[38px] rounded-lg border border-slate-300 bg-white px-2.5 font-mono text-xs text-slate-900"
                />
                <div className="sm:col-span-3 flex flex-wrap items-center justify-between gap-2 pt-1">
                  <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={fyMakeActive}
                      onChange={(e) => setFyMakeActive(e.target.checked)}
                      className="h-4 w-4 accent-emerald-700"
                    />
                    <span>যোগ করার পর সক্রিয় (Active) করুন</span>
                  </label>
                  <button
                    type="submit"
                    disabled={savingFy || !fyName.trim()}
                    className="min-h-[36px] px-3.5 rounded-lg bg-[#0D6E4E] text-white text-xs font-bold disabled:opacity-50 cursor-pointer"
                  >
                    + অর্থবছর যুক্ত
                  </button>
                </div>
              </form>

              <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
                {(gasData.settings?.fiscalYears || []).map((fy) => {
                  const isActive = gasData.settings.activeFY === fy.name;
                  return (
                    <div
                      key={fy.name}
                      className="px-3.5 py-2.5 flex items-center justify-between gap-2 bg-white text-xs"
                    >
                      <div>
                        <span className="font-bold text-slate-900">{fy.name}</span>{' '}
                        {isActive && <span className="text-emerald-700 font-bold">· সক্রিয়</span>}
                        {(fy.start || fy.end) && (
                          <div className="text-[11px] font-mono text-slate-500">
                            {fy.start} — {fy.end}
                          </div>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5">
                        {!isActive && onSetActiveGasFiscalYear && (
                          <button
                            type="button"
                            onClick={() => void onSetActiveGasFiscalYear(fy.name)}
                            className="px-2.5 py-1 rounded-lg border border-emerald-200 bg-emerald-50 text-[11px] font-bold text-emerald-800 cursor-pointer"
                          >
                            সক্রিয় করুন
                          </button>
                        )}
                        {onDeleteGasFiscalYear && (
                          <button
                            type="button"
                            onClick={() => void onDeleteGasFiscalYear(fy.name)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer"
                            aria-label={`${fy.name} মুছুন`}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* 3. Product-wise Receipt & Distribution Category Settings */}
      <section className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-slate-900">
              প্রাপ্তি চ্যানেল ও বিতরণ ক্যাটাগরি সেটআপ
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              ধান, চাল, গম এবং ৫০/৩০ কেজি বস্তার প্রাপ্তি ও বিতরণের খাত (বিডব্লিউবি, জিআর, ভিজিএফ, কাবিখা ইত্যাদি) সেট করুন
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 self-start">
            {gasBridgeStatus === 'connected' && onSaveGasCategories && (
              <button
                type="button"
                disabled={savingCats}
                onClick={() => void handleSaveCategoriesToSheet()}
                className="inline-flex items-center gap-1.5 rounded-xl bg-[#0D6E4E] hover:bg-emerald-900 disabled:opacity-60 px-3.5 py-2 text-xs font-bold text-white whitespace-nowrap cursor-pointer"
              >
                <Save className="h-3.5 w-3.5" />
                <span>{savingCats ? 'সেভ হচ্ছে...' : 'গুগল শিটে সেভ'}</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                onResetDefaultChannels();
                setStatusMsg('ডিফল্ট চ্যানেল ও ক্যাটাগরি পুনরুদ্ধার করা হয়েছে।');
              }}
              className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 px-3 py-2 text-xs font-semibold text-slate-700 whitespace-nowrap cursor-pointer"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>ডিফল্ট সেট</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
          {PRODUCTS.map((p) => {
            const active = selectedProduct === p.id;
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => setSelectedProduct(p.id)}
                className={`min-h-[54px] rounded-xl border p-2 flex flex-col items-center justify-center gap-1 transition-colors cursor-pointer ${
                  active
                    ? 'border-slate-900 bg-slate-900 text-white'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                <ProductIcon
                  product={p.id}
                  className={`h-5 w-5 ${active ? 'text-white' : p.textColorClass}`}
                />
                <span className="text-[11px] font-bold text-center leading-tight">{p.shortBn}</span>
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-slate-100 border border-slate-200">
          <button
            type="button"
            onClick={() => setSelectedMode('receipt')}
            className={`min-h-[40px] rounded-lg text-xs font-bold transition-colors cursor-pointer ${
              selectedMode === 'receipt'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            প্রাপ্তির চ্যানেলসমূহ (Receipt)
          </button>
          <button
            type="button"
            onClick={() => setSelectedMode('distribution')}
            className={`min-h-[40px] rounded-lg text-xs font-bold transition-colors cursor-pointer ${
              selectedMode === 'distribution'
                ? 'bg-white text-rose-800 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            বিতরণের ক্যাটাগরি (DO / Delivery)
          </button>
        </div>

        <form onSubmit={handleAdd} className="flex gap-2">
          <input
            type="text"
            value={newChannelName}
            onChange={(e) => setNewChannelName(e.target.value)}
            placeholder="নতুন ক্যাটাগরি বা চ্যানেলের নাম লিখুন..."
            className="flex-1 min-h-[44px] rounded-xl border border-slate-300 px-3.5 py-2 text-sm text-slate-900 focus:border-emerald-700 focus:outline-none"
          />
          <button
            type="submit"
            disabled={!newChannelName.trim()}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-[#0D6E4E] hover:bg-emerald-900 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
          >
            <Plus className="h-4 w-4" />
            <span>যোগ করুন</span>
          </button>
        </form>

        <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
          {currentList.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-500">
              এই ক্যাটাগরিতে এখনও কোনো চ্যানেল যোগ করা হয়নি।
            </div>
          ) : (
            currentList.map((ch, idx) => (
              <div
                key={`${ch}-${idx}`}
                className="flex items-center justify-between gap-3 px-4 py-3 bg-white"
              >
                {editingChannel === ch ? (
                  <div className="flex-1 flex items-center gap-2">
                    <input
                      type="text"
                      value={editValue}
                      onChange={(e) => setEditValue(e.target.value)}
                      className="flex-1 rounded-lg border border-slate-300 px-2.5 py-1.5 text-sm text-slate-900 focus:border-emerald-700 focus:outline-none"
                      autoFocus
                    />
                    <button
                      type="button"
                      onClick={() => handleSaveRename(ch)}
                      className="px-3 py-1.5 rounded-lg bg-emerald-700 text-white text-xs font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Check className="h-3.5 w-3.5" />
                      <span>সেভ</span>
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className="text-xs font-mono text-slate-400 tabular-nums w-5">
                        {idx + 1}.
                      </span>
                      <span className="text-sm font-medium text-slate-800 truncate">{ch}</span>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => {
                          setEditingChannel(ch);
                          setEditValue(ch);
                        }}
                        className="min-h-[36px] min-w-[36px] rounded-lg flex items-center justify-center text-slate-400 hover:text-slate-800 hover:bg-slate-100 cursor-pointer"
                        aria-label={`${ch} সম্পাদনা`}
                      >
                        <Edit3 className="h-4 w-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onRemoveChannel(selectedProduct, selectedMode, ch)}
                        className="min-h-[36px] min-w-[36px] rounded-lg flex items-center justify-center text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer"
                        aria-label={`${ch} মুছুন`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </>
                )}
              </div>
            ))
          )}
        </div>
      </section>

      {/* 4. Local DO Queue Management (shown as fallback/extra queue) */}
      <section className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-6 space-y-4">
        <div className="flex items-start gap-3">
          <div className="h-9 w-9 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-center shrink-0">
            <FileText className="h-4.5 w-4.5 text-rose-700" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">
              লোকাল ও জরুরি ডিও নম্বর (DO) তালিকা
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              অফলাইনে বা ম্যানুয়াল পেন্ডিং ডিও যোগ করুন (মেইন শিট যুক্ত থাকলে সরাসরি শিটের পেন্ডিং ডিও ব্যবহৃত হয়)
            </p>
          </div>
        </div>

        <form onSubmit={handleCreateDo} className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 bg-slate-50 p-3.5 rounded-xl border border-slate-200">
          <input
            type="text"
            value={doNum}
            onChange={(e) => setDoNum(e.target.value)}
            placeholder="ডিও নম্বর (যেমন: DO-2026-0515)"
            className="min-h-[40px] rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-mono text-xs text-slate-900 focus:border-emerald-700 focus:outline-none"
          />
          <select
            value={doProd}
            onChange={(e) => {
              const p = e.target.value as ProductCategory;
              setDoProd(p);
              setDoCat(channels[p]?.distribution[0] || '');
            }}
            className="min-h-[40px] rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-900 focus:border-emerald-700 focus:outline-none"
          >
            {PRODUCTS.map((p) => (
              <option key={p.id} value={p.id}>
                {p.nameBn}
              </option>
            ))}
          </select>
          <select
            value={doCat}
            onChange={(e) => {
              const c = e.target.value;
              setDoCat(c);
              if (doProd === 'rice' || doProd === 'wheat') {
                const inf = inferDefaultProductFromCategory(c);
                if (inf !== doProd) setDoProd(inf);
              }
            }}
            className="min-h-[40px] rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-900 focus:border-emerald-700 focus:outline-none"
          >
            {(channels[doProd]?.distribution || []).map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <input
            type="number"
            step="0.001"
            min="0"
            value={doMt}
            onChange={(e) => setDoMt(e.target.value)}
            placeholder="পরিমাণ (মে.টন)"
            className="min-h-[40px] rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-mono tabular-nums text-xs font-bold text-slate-900 focus:border-emerald-700 focus:outline-none"
          />
          <input
            type="number"
            min="0"
            value={doBags}
            onChange={(e) => setDoBags(e.target.value)}
            placeholder="বস্তা সংখ্যা (ঐচ্ছিক)"
            className="min-h-[40px] rounded-lg border border-slate-300 bg-white px-3 py-1.5 font-mono tabular-nums text-xs text-slate-900 focus:border-emerald-700 focus:outline-none"
          />
          <div className="flex gap-2">
            <input
              type="text"
              value={doRecipient}
              onChange={(e) => setDoRecipient(e.target.value)}
              placeholder="প্রাপক (ঐচ্ছিক)"
              className="flex-1 min-h-[40px] rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-900 focus:border-emerald-700 focus:outline-none"
            />
            <button
              type="submit"
              className="min-h-[40px] px-3.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold whitespace-nowrap cursor-pointer"
            >
              + যোগ
            </button>
          </div>
        </form>

        {deliveryOrders.length > 0 && (
          <div className="divide-y divide-slate-100 border border-slate-200 rounded-xl overflow-hidden">
            {deliveryOrders.map((d) => {
              const pMeta = PRODUCT_MAP[d.product];
              const remMt = Math.max(0, Number((d.totalMt - d.deliveredMt).toFixed(4)));
              const remBags = Math.max(0, d.totalBags - d.deliveredBags);
              const pending = isDoPending(d);
              return (
                <div key={d.id} className="px-4 py-3 flex items-center justify-between gap-3 bg-white">
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-slate-900 truncate">
                      <span className="font-mono">{d.doNumber}</span> · {pMeta.shortBn} · {d.category}{' '}
                      <span className={pending ? 'text-rose-700' : 'text-emerald-700'}>
                        ({pending ? 'পেন্ডিং' : 'বিতরণকৃত'})
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 tabular-nums mt-0.5">
                      মোট: {pMeta.tracksWeight ? `${formatMetricTons(d.totalMt)} মে.টন` : `${formatBags(d.totalBags)} বস্তা`} · বাকি:{' '}
                      <strong className="text-slate-800">
                        {pMeta.tracksWeight ? `${formatMetricTons(remMt)} মে.টন` : `${formatBags(remBags)} বস্তা`}
                      </strong>
                      {d.recipient ? ` · ${d.recipient}` : ''}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onDeleteDeliveryOrder(d.id)}
                    className="p-2 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer shrink-0"
                    aria-label="ডিও মুছুন"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* 4.5. Fortnightly Report Letter & Official Text Settings */}
      <section
        id="fortnightly-letter-settings"
        className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-6 space-y-4"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="h-9 w-9 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center shrink-0">
              <FileText className="h-4.5 w-4.5 text-[#0D6E4E]" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                পাক্ষিক প্রতিবেদন — পত্রের সকল লেখা ও অফিস তথ্য সেটিংস
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                পাক্ষিক রিপোর্ট ও পিডিএফের শিরোনাম, প্রাপক, বিষয়, সূত্র, মূল বক্তব্য, স্বাক্ষর ও অনুলিপি এখান থেকে এডিট করুন। সকল পরিবর্তন স্বয়ংক্রিয়ভাবে সংরক্ষিত হয়।
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              onResetFortnightlySettings();
              setStatusMsg('পাক্ষিক প্রতিবেদনের পত্রের লেখা ডিফল্ট অফিসিয়াল টেমপ্লেটে রিসেট করা হয়েছে।');
            }}
            className="min-h-[36px] inline-flex items-center gap-1.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 px-3 py-1.5 text-xs font-semibold text-slate-700 self-start shrink-0 cursor-pointer"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>ডিফল্ট লেখায় রিসেট</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 bg-slate-50/70 p-3.5 rounded-xl border border-slate-200">
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              ১. সরকার শিরোনাম
            </label>
            <input
              type="text"
              value={fortnightlySettings.govTitle}
              onChange={(e) => onUpdateFortnightlySettings({ govTitle: e.target.value })}
              className="w-full min-h-[38px] rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              ২. কার্যালয়ের নাম
            </label>
            <input
              type="text"
              value={fortnightlySettings.officeName}
              onChange={(e) => onUpdateFortnightlySettings({ officeName: e.target.value })}
              className="w-full min-h-[38px] rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              ৩. কার্যালয়ের ঠিকানা
            </label>
            <input
              type="text"
              value={fortnightlySettings.officeLocation}
              onChange={(e) => onUpdateFortnightlySettings({ officeLocation: e.target.value })}
              className="w-full min-h-[38px] rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              ৪. ডিফল্ট স্মারক নং
            </label>
            <input
              type="text"
              value={fortnightlySettings.defaultMemoNo}
              onChange={(e) => onUpdateFortnightlySettings({ defaultMemoNo: e.target.value })}
              className="w-full min-h-[38px] rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              ৫. প্রাপক শিরোনাম ও ঠিকানা
            </label>
            <div className="flex gap-1.5">
              <input
                type="text"
                value={fortnightlySettings.recipientLabel}
                onChange={(e) => onUpdateFortnightlySettings({ recipientLabel: e.target.value })}
                className="w-20 min-h-[38px] rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-xs font-bold text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
              />
              <input
                type="text"
                value={fortnightlySettings.recipientText}
                onChange={(e) => onUpdateFortnightlySettings({ recipientText: e.target.value })}
                className="flex-1 min-h-[38px] rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              ৬. খাদ্য গুদাম / এলএসডির নাম ({`{গুদাম}`})
            </label>
            <input
              type="text"
              value={fortnightlySettings.lsdDisplayName}
              onChange={(e) => onUpdateFortnightlySettings({ lsdDisplayName: e.target.value })}
              className="w-full min-h-[38px] rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
            />
          </div>

          <div className="sm:col-span-2 lg:col-span-3">
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              ৭. বিষয়
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={fortnightlySettings.subjectLabel}
                onChange={(e) => onUpdateFortnightlySettings({ subjectLabel: e.target.value })}
                className="w-24 min-h-[38px] rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-bold text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
              />
              <input
                type="text"
                value={fortnightlySettings.subjectText}
                onChange={(e) => onUpdateFortnightlySettings({ subjectText: e.target.value })}
                className="flex-1 min-h-[38px] rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
              />
            </div>
          </div>

          <div className="sm:col-span-2 lg:col-span-3">
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              ৮. সূত্র
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={fortnightlySettings.referenceLabel}
                onChange={(e) => onUpdateFortnightlySettings({ referenceLabel: e.target.value })}
                className="w-24 min-h-[38px] rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-bold text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
              />
              <input
                type="text"
                value={fortnightlySettings.referenceText}
                onChange={(e) => onUpdateFortnightlySettings({ referenceText: e.target.value })}
                className="flex-1 min-h-[38px] rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
              />
            </div>
          </div>

          <div className="sm:col-span-2 lg:col-span-3">
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              ৯. পত্রের মূল বক্তব্য (প্লেসহোল্ডার: <code className="font-mono text-emerald-800">{`{তারিখ}`}</code>,{' '}
              <code className="font-mono text-emerald-800">{`{গুদাম}`}</code>,{' '}
              <code className="font-mono text-emerald-800">{`{পক্ষ}`}</code>)
            </label>
            <textarea
              rows={3}
              value={fortnightlySettings.bodyTemplate}
              onChange={(e) => onUpdateFortnightlySettings({ bodyTemplate: e.target.value })}
              className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-900 leading-relaxed focus:border-[#0D6E4E] focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              ১০. স্বাক্ষরকারী কর্মকর্তার নাম
            </label>
            <input
              type="text"
              value={fortnightlySettings.officerName}
              onChange={(e) => onUpdateFortnightlySettings({ officerName: e.target.value })}
              className="w-full min-h-[38px] rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              ১১. কর্মকর্তার পদবি
            </label>
            <input
              type="text"
              value={fortnightlySettings.officerDesignation}
              onChange={(e) =>
                onUpdateFortnightlySettings({
                  officerDesignation: e.target.value,
                  footerDesignation: e.target.value,
                })
              }
              className="w-full min-h-[38px] rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              ১২. স্বাক্ষরের স্থান
            </label>
            <input
              type="text"
              value={fortnightlySettings.signOfficeLocation}
              onChange={(e) =>
                onUpdateFortnightlySettings({
                  signOfficeLocation: e.target.value,
                  footerLocation: e.target.value.replace(/।$/, ''),
                })
              }
              className="w-full min-h-[38px] rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
            />
          </div>

          <div className="sm:col-span-2 lg:col-span-3">
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              ১৩. অনুলিপি তালিকা (প্রতি লাইনে একটি করে লিখুন)
            </label>
            <div className="space-y-1.5">
              <input
                type="text"
                value={fortnightlySettings.copyTitle}
                onChange={(e) => onUpdateFortnightlySettings({ copyTitle: e.target.value })}
                className="w-36 min-h-[36px] rounded-lg border border-slate-300 bg-white px-2.5 py-1 text-xs font-bold text-slate-900 focus:border-[#0D6E4E] focus:outline-none"
              />
              <textarea
                rows={3}
                value={fortnightlySettings.copyList}
                onChange={(e) => onUpdateFortnightlySettings({ copyList: e.target.value })}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs text-slate-900 leading-relaxed focus:border-[#0D6E4E] focus:outline-none"
              />
            </div>
          </div>
        </div>
      </section>

      {/* 5. Backup & Data Controls */}
      <section className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-6 space-y-4">
        <div>
          <h2 className="text-base font-bold text-slate-900">ডিভাইস ব্যাকআপ ও রিস্টোর</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            সকল গুদাম, খামাল, ডিও এবং চ্যানেলের লোকাল ব্যাকআপ ডাউনলোড বা পুনরুদ্ধার করুন।
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={onExportBackup}
            className="min-h-[42px] inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 px-4 py-2 text-xs font-bold text-slate-800 cursor-pointer"
          >
            <Download className="h-4 w-4 text-emerald-700" />
            <span>JSON ব্যাকআপ ডাউনলোড</span>
          </button>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="min-h-[42px] inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 px-4 py-2 text-xs font-bold text-slate-800 cursor-pointer"
          >
            <Upload className="h-4 w-4 text-slate-700" />
            <span>ব্যাকআপ আপলোড (JSON / ZIP)</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="application/json,.json,application/zip,.zip"
            onChange={handleFileUpload}
            className="hidden"
          />

          <button
            type="button"
            onClick={() => {
              onLoadSampleData();
              setStatusMsg('নমুনা খাদ্যশস্য ও ডিও ডেটা লোড করা হয়েছে।');
            }}
            className="min-h-[42px] inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 px-3.5 py-2 text-xs font-semibold text-slate-700 cursor-pointer"
          >
            <span>নমুনা ডেটা লোড</span>
          </button>

          {!confirmClear ? (
            <button
              type="button"
              onClick={() => setConfirmClear(true)}
              className="min-h-[42px] inline-flex items-center gap-2 rounded-xl border border-rose-200 bg-rose-50 hover:bg-rose-100 px-3.5 py-2 text-xs font-semibold text-rose-700 cursor-pointer"
            >
              <span>সব লোকাল ডেটা খালি করুন</span>
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  onClearAllData();
                  setConfirmClear(false);
                  setStatusMsg('সব লোকাল মজুদ ডেটা মুছে ফেলা হয়েছে।');
                }}
                className="min-h-[42px] px-3.5 py-2 rounded-xl bg-rose-600 text-white text-xs font-bold cursor-pointer"
              >
                হ্যাঁ, সব মুছুন
              </button>
              <button
                type="button"
                onClick={() => setConfirmClear(false)}
                className="min-h-[42px] px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs font-semibold text-slate-700 cursor-pointer"
              >
                বাতিল
              </button>
            </div>
          )}
        </div>
      </section>

      {/* 6. GitHub Actions Android APK Exporter */}
      <section className="rounded-2xl border border-slate-200 bg-white p-4 sm:p-6 space-y-4">
        <div className="flex items-start gap-3">
          <div className="h-10 w-10 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center shrink-0">
            <FolderGit2 className="h-5 w-5 text-emerald-800" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900">
              গিটহাব থেকে অ্যান্ড্রয়েড APK তৈরি (.zip এক্সপোর্ট)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5 leading-relaxed">
              এই ZIP-এ সম্পূর্ণ Kotlin Android Studio প্রজেক্ট, কম্পাইল করা অফলাইন ওয়েব অ্যাপ, সম্পূর্ণ
              সোর্স কোড এবং GitHub Actions ওয়ার্কফ্লো একসাথে প্যাকেজ করা থাকে (কোনো কোড বাদ যায় না;
              টেক্সট কম্প্রেশনের কারণে ZIP ~১ MB হয় এবং GitHub থেকে তৈরি হওয়া চূড়ান্ত{' '}
              <code className="font-mono text-slate-800">app-debug.apk</code> ~১১–১২ MB হবে)।
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label htmlFor="apk-name" className="block text-xs font-semibold text-slate-700 mb-1">
              অ্যান্ড্রয়েড অ্যাপের নাম
            </label>
            <input
              id="apk-name"
              type="text"
              value={apkAppName}
              onChange={(e) => setApkAppName(e.target.value)}
              className="w-full min-h-[42px] rounded-xl border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-emerald-700 focus:outline-none"
            />
          </div>
          <div>
            <label htmlFor="apk-pkg" className="block text-xs font-semibold text-slate-700 mb-1">
              Package ID
            </label>
            <input
              id="apk-pkg"
              type="text"
              value={apkPackage}
              onChange={(e) => setApkPackage(e.target.value)}
              className="w-full min-h-[42px] rounded-xl border border-slate-300 px-3 py-2 font-mono text-xs text-slate-900 focus:border-emerald-700 focus:outline-none"
            />
          </div>
        </div>

        {apkError && (
          <div className="rounded-xl border border-rose-200 bg-rose-50 px-3 py-2 text-xs font-medium text-rose-800">
            {apkError}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => setShowSourceCopyModal(true)}
            className="min-h-[46px] inline-flex items-center justify-center gap-2 rounded-xl border-2 border-slate-900 bg-white hover:bg-slate-50 px-5 py-2.5 text-xs font-extrabold text-slate-900 cursor-pointer"
          >
            <FileCode2 className="h-4 w-4 text-[#0D6E4E]" />
            <span>সব কোড দেখুন ও কপি করুন (জিপ ছাড়া)</span>
          </button>

          <button
            type="button"
            onClick={handleDownloadAndroidZip}
            disabled={apkDownloading}
            className="min-h-[46px] inline-flex items-center justify-center gap-2 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-60 px-5 py-2.5 text-xs font-bold text-white cursor-pointer"
          >
            <Download className="h-4 w-4" />
            <span>
              {apkDownloading
                ? 'প্রজেক্ট প্যাকেজ হচ্ছে...'
                : 'অ্যান্ড্রয়েড APK প্রজেক্ট (.zip) ডাউনলোড করুন'}
            </span>
          </button>

          <button
            type="button"
            onClick={handleDownloadSourceZip}
            disabled={sourceZipDownloading}
            className="min-h-[46px] inline-flex items-center justify-center gap-2 rounded-xl bg-[#0D6E4E] hover:bg-emerald-900 disabled:opacity-60 px-5 py-2.5 text-xs font-bold text-white cursor-pointer"
          >
            <Download className="h-4 w-4" />
            <span>
              {sourceZipDownloading
                ? 'সোর্স কোড জিপ হচ্ছে...'
                : 'সম্পূর্ণ সোর্স কোড (.zip) ডাউনলোড করুন'}
            </span>
          </button>
        </div>
      </section>

      <SourceCodeCopyModal
        isOpen={showSourceCopyModal}
        onClose={() => setShowSourceCopyModal(false)}
        apkAppName={apkAppName}
        apkPackageName={apkPackage}
      />
    </div>
  );
};
