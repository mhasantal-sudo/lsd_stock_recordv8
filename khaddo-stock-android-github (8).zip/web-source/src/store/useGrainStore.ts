import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { User } from 'firebase/auth';
import {
  DEFAULT_CHANNELS,
  DEFAULT_FORTNIGHTLY_REPORT_SETTINGS,
  DEFAULT_MAIN_APPS_SCRIPT_URL,
  PRODUCTS,
  PRODUCT_MAP,
  inferDefaultProductFromCategory,
  type ChannelConfig,
  type ChannelMode,
  type DeliveryOrder,
  type DriveSpreadsheetFile,
  type ExternalSyncConfig,
  type FortnightlyReportSettings,
  type GasAppData,
  type GasBridgeStatus,
  type GoogleSheetsConfig,
  type GrainTransaction,
  type KhamalStockItem,
  type ProductCategory,
  type SheetWriteConfirmRequest,
} from '../types/grain';
import { isDoPending, normalizeExternalDoList } from '../shared/externalDoSync';
import {
  callGasAction,
  itemNameBnToProduct,
  parseGasNumber,
  productToItemNameBn,
} from '../shared/gasBridge';
import {
  clearGoogleAccessToken,
  getGoogleAccessToken,
  googleLogout,
  googleSignIn,
  initGoogleAuth,
} from '../shared/googleAuth';
import {
  GoogleAuthExpiredError,
  autoDetectUserSpreadsheets,
  extractSpreadsheetId,
  fetchGasAppDataFromSheets,
  getSpreadsheetMetadata,
  listUserSpreadsheets,
  writeActionToSheets,
} from '../shared/googleSheetsSync';
import { todayIsoDate } from '../components/GrainIcons';

const STORAGE_KEY_TX = 'khaddo_stock_transactions_v2';
const STORAGE_KEY_CHANNELS = 'khaddo_stock_channels_v2';
const STORAGE_KEY_GODOWNS = 'khaddo_stock_godowns_v2';
const STORAGE_KEY_DOS = 'khaddo_stock_dos_v2';
const STORAGE_KEY_EXT_SYNC = 'khaddo_stock_external_sync_v1';
const STORAGE_KEY_GAS_CACHE = 'khaddo_stock_gas_cache_v1';
const STORAGE_KEY_GSHEETS = 'khaddo_stock_gsheets_config_v1';
const STORAGE_KEY_DATA_SOURCE = 'khaddo_stock_data_source_v1';
const STORAGE_KEY_SELECTED_FY = 'khaddo_stock_selected_fy_v1';
const STORAGE_KEY_MAIN_TABS = 'khaddo_stock_main_tabs_v1';
const STORAGE_KEY_MANUAL_SYNC_MIGRATED = 'khaddo_stock_manual_sync_v1';
const STORAGE_KEY_FORTNIGHTLY_SETTINGS = 'khaddo_stock_fortnightly_settings_v1';
const STORAGE_KEY_INIT = 'khaddo_stock_initialized_v2';
const STORAGE_KEY_SAMPLE_SEED = 'khaddo_stock_sample_seed_v4';

const DEFAULT_GOOGLE_SHEETS_CONFIG: GoogleSheetsConfig = {
  enabled: true,
  mainSpreadsheetId: '',
  mainSpreadsheetName: '',
  externalDoSpreadsheetId: '',
  externalDoSpreadsheetName: '',
  externalDoSheetName: 'DO_Issue',
  cutoffDate: '2026-11-01',
  excludeDoNos: ['240319', '240320'],
  bagKg: 50,
};

const DEFAULT_EXTERNAL_SYNC: ExternalSyncConfig = {
  enabled: true,
  externalAppUrl: DEFAULT_MAIN_APPS_SCRIPT_URL,
  autoSync: false,
  syncIntervalSec: 60,
  pushDistributedStatus: true,
  apiSecret: '',
  lastSyncStatus: 'idle',
};

// Legacy v1 keys for smooth migration
const LEGACY_KEY_TX = 'khaddo_stock_transactions_v1';

const DEFAULT_GODOWNS = ['গুদাম-০১', 'গুদাম-০২', 'গুদাম-০৩', 'গুদাম-০৪'];

function createStarterTransactions(): GrainTransaction[] {
  const today = todayIsoDate();
  const batchPaddy = 'batch-starter-paddy';
  const batchRice = 'batch-starter-rice';
  const batchWheat = 'batch-starter-wheat';
  const batchBag = 'batch-starter-bag';
  const now = new Date().toISOString();

  return [
    // ধান (Paddy) - ৩টি খামাল
    {
      id: 'tx-s1',
      batchId: batchPaddy,
      type: 'receipt',
      product: 'paddy',
      godownNo: 'গুদাম-০১',
      khamalNo: 'খামাল-০১',
      bags: 500,
      metricTons: 20.0,
      channel: 'অভ্যন্তরীণ বোরো সংগ্রহ',
      referenceNo: 'INV-2026-101',
      date: today,
      note: 'নমুনা বোরো ধান সংগ্রহ',
      createdAt: now,
    },
    {
      id: 'tx-s2',
      batchId: batchPaddy,
      type: 'receipt',
      product: 'paddy',
      godownNo: 'গুদাম-০১',
      khamalNo: 'খামাল-০২',
      bags: 450,
      metricTons: 18.0,
      channel: 'অভ্যন্তরীণ বোরো সংগ্রহ',
      referenceNo: 'INV-2026-101',
      date: today,
      note: 'নমুনা বোরো ধান সংগ্রহ',
      createdAt: now,
    },
    {
      id: 'tx-s8',
      batchId: batchPaddy,
      type: 'receipt',
      product: 'paddy',
      godownNo: 'গুদাম-০১',
      khamalNo: 'খামাল-০৩',
      bags: 375,
      metricTons: 15.0,
      channel: 'আমন সংগ্রহ',
      referenceNo: 'INV-2026-102',
      date: today,
      note: 'নমুনা আমন ধান সংগ্রহ',
      createdAt: now,
    },

    // চাল (Rice) - ৬টি খামাল
    {
      id: 'tx-s3',
      batchId: batchRice,
      type: 'receipt',
      product: 'rice',
      godownNo: 'গুদাম-০২',
      khamalNo: 'খামাল-০১',
      bags: 100,
      metricTons: 5.0,
      channel: 'আমন সংগ্রহ',
      referenceNo: 'RC-2026-045',
      date: today,
      note: 'সেদ্ধ চাল খামাল-০১ (৫ টন)',
      createdAt: now,
    },
    {
      id: 'tx-s4',
      batchId: batchRice,
      type: 'receipt',
      product: 'rice',
      godownNo: 'গুদাম-০২',
      khamalNo: 'খামাল-০২',
      bags: 160,
      metricTons: 8.0,
      channel: 'আমন সংগ্রহ',
      referenceNo: 'RC-2026-046',
      date: today,
      note: 'সেদ্ধ চাল খামাল-০২ (৮ টন)',
      createdAt: now,
    },
    {
      id: 'tx-s9',
      batchId: batchRice,
      type: 'receipt',
      product: 'rice',
      godownNo: 'গুদাম-০২',
      khamalNo: 'খামাল-০৩',
      bags: 200,
      metricTons: 10.0,
      channel: 'অভ্যন্তরীণ বোরো সংগ্রহ',
      referenceNo: 'RC-2026-047',
      date: today,
      note: 'সেদ্ধ চাল খামাল-০৩ (১০ টন)',
      createdAt: now,
    },
    {
      id: 'tx-s10',
      batchId: batchRice,
      type: 'receipt',
      product: 'rice',
      godownNo: 'গুদাম-০২',
      khamalNo: 'খামাল-০৪',
      bags: 240,
      metricTons: 12.0,
      channel: 'অভ্যন্তরীণ বোরো সংগ্রহ',
      referenceNo: 'RC-2026-048',
      date: today,
      note: 'সেদ্ধ চাল খামাল-০৪ (১২ টন)',
      createdAt: now,
    },
    {
      id: 'tx-s11',
      batchId: batchRice,
      type: 'receipt',
      product: 'rice',
      godownNo: 'গুদাম-০৪',
      khamalNo: 'খামাল-০১',
      bags: 150,
      metricTons: 7.5,
      channel: 'ইনভয়েসের মাধ্যমে প্রাপ্তি',
      referenceNo: 'RC-2026-049',
      date: today,
      note: 'সিলো থেকে প্রাপ্ত সেদ্ধ চাল',
      createdAt: now,
    },
    {
      id: 'tx-s12',
      batchId: batchRice,
      type: 'receipt',
      product: 'rice',
      godownNo: 'গুদাম-০৪',
      khamalNo: 'খামাল-০২',
      bags: 120,
      metricTons: 6.0,
      channel: 'আমন সংগ্রহ',
      referenceNo: 'RC-2026-050',
      date: today,
      note: 'আমন সেদ্ধ চাল খামাল-০২',
      createdAt: now,
    },

    // গম (Wheat) - ৫টি খামাল
    {
      id: 'tx-s5',
      batchId: batchWheat,
      type: 'receipt',
      product: 'wheat',
      godownNo: 'গুদাম-০৩',
      khamalNo: 'খামাল-০১',
      bags: 300,
      metricTons: 15.0,
      channel: 'ইনভয়েসের মাধ্যমে প্রাপ্তি',
      referenceNo: 'INV-W-088',
      date: today,
      note: 'বন্দর ইনভয়েস গম খামাল-০১',
      createdAt: now,
    },
    {
      id: 'tx-s13',
      batchId: batchWheat,
      type: 'receipt',
      product: 'wheat',
      godownNo: 'গুদাম-০৩',
      khamalNo: 'খামাল-০২',
      bags: 200,
      metricTons: 10.0,
      channel: 'আমদানি / বন্দর হতে প্রাপ্তি',
      referenceNo: 'INV-W-089',
      date: today,
      note: 'আমদানি গম খামাল-০২',
      createdAt: now,
    },
    {
      id: 'tx-s14',
      batchId: batchWheat,
      type: 'receipt',
      product: 'wheat',
      godownNo: 'গুদাম-০৩',
      khamalNo: 'খামাল-০৩',
      bags: 160,
      metricTons: 8.0,
      channel: 'আমদানি / বন্দর হতে প্রাপ্তি',
      referenceNo: 'INV-W-090',
      date: today,
      note: 'আমদানি গম খামাল-০৩',
      createdAt: now,
    },
    {
      id: 'tx-s15',
      batchId: batchWheat,
      type: 'receipt',
      product: 'wheat',
      godownNo: 'গুদাম-০৩',
      khamalNo: 'খামাল-০৪',
      bags: 120,
      metricTons: 6.0,
      channel: 'অভ্যন্তরীণ সংগ্রহ',
      referenceNo: 'INV-W-091',
      date: today,
      note: 'দেশি গম সংগ্রহ খামাল-০৪',
      createdAt: now,
    },
    {
      id: 'tx-s16',
      batchId: batchWheat,
      type: 'receipt',
      product: 'wheat',
      godownNo: 'গুদাম-০৪',
      khamalNo: 'খামাল-০৩',
      bags: 140,
      metricTons: 7.0,
      channel: 'ইনভয়েসের মাধ্যমে প্রাপ্তি',
      referenceNo: 'INV-W-092',
      date: today,
      note: 'বদলি গম খামাল-০৩',
      createdAt: now,
    },

    // খালি বস্তা - ২টি খামাল
    {
      id: 'tx-s6',
      batchId: batchBag,
      type: 'receipt',
      product: 'bosta_50',
      godownNo: 'গুদাম-০১',
      khamalNo: 'খামাল-বস্তা-৫০',
      bags: 1200,
      metricTons: 0,
      channel: 'নতুন ৫০ কেজি বস্তা সরবরাহ',
      referenceNo: 'BAG-50-09',
      date: today,
      note: '৫০ কেজি খালি পাটের বস্তা',
      createdAt: now,
    },
    {
      id: 'tx-s7',
      batchId: batchBag,
      type: 'receipt',
      product: 'bosta_30',
      godownNo: 'গুদাম-০১',
      khamalNo: 'খামাল-বস্তা-৩০',
      bags: 850,
      metricTons: 0,
      channel: 'নতুন ৩০ কেজি বস্তা সরবরাহ',
      referenceNo: 'BAG-30-04',
      date: today,
      note: '৩০ কেজি খালি বস্তা',
      createdAt: now,
    },
  ];
}

function createStarterDeliveryOrders(): DeliveryOrder[] {
  const today = todayIsoDate();
  const now = new Date().toISOString();
  return [
    // === চাল (Rice) — ৫টি খাতে ১২টি ডিও ===
    // ১) ভিজিএফ ঈদ (৩টি)
    {
      id: 'do-s1',
      doNumber: 'DO-2026-0501',
      product: 'rice',
      category: 'ভিজিএফ ঈদ',
      totalBags: 120,
      totalMt: 6.0,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'সদর ইউনিয়ন পরিষদ',
      date: today,
      source: 'apps_script',
      status: 'pending',
      createdAt: now,
    },
    {
      id: 'do-s4',
      doNumber: 'DO-2026-0504',
      product: 'rice',
      category: 'ভিজিএফ ঈদ',
      totalBags: 90,
      totalMt: 4.5,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'পূর্ব ইউনিয়ন পরিষদ',
      date: today,
      source: 'apps_script',
      status: 'pending',
      createdAt: now,
    },
    {
      id: 'do-s5',
      doNumber: 'DO-2026-0505',
      product: 'rice',
      category: 'ভিজিএফ ঈদ',
      totalBags: 80,
      totalMt: 4.0,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'দক্ষিণ ইউনিয়ন পরিষদ',
      date: today,
      source: 'apps_script',
      status: 'pending',
      createdAt: now,
    },

    // ২) বিডব্লিউবি (৩টি)
    {
      id: 'do-s3',
      doNumber: 'DO-2026-0503',
      product: 'rice',
      category: 'বিডব্লিউবি',
      totalBags: 60,
      totalMt: 3.0,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'পশ্চিম ইউনিয়ন ডিলার',
      date: today,
      source: 'external_app',
      status: 'pending',
      createdAt: now,
    },
    {
      id: 'do-s6',
      doNumber: 'DO-2026-0506',
      product: 'rice',
      category: 'বিডব্লিউবি',
      totalBags: 50,
      totalMt: 2.5,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'উত্তর ইউনিয়ন ডিলার',
      date: today,
      source: 'external_app',
      status: 'pending',
      createdAt: now,
    },
    {
      id: 'do-s7',
      doNumber: 'DO-2026-0507',
      product: 'rice',
      category: 'বিডব্লিউবি',
      totalBags: 70,
      totalMt: 3.5,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'মধ্যনগর ইউনিয়ন ডিলার',
      date: today,
      source: 'external_app',
      status: 'pending',
      createdAt: now,
    },

    // ৩) ভিজিএফ মৎস্য (২টি)
    {
      id: 'do-s8',
      doNumber: 'DO-2026-0508',
      product: 'rice',
      category: 'ভিজিএফ মৎস্য',
      totalBags: 80,
      totalMt: 4.0,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'নদীপাড় মৎস্যজীবী সমবায়',
      date: today,
      source: 'apps_script',
      status: 'pending',
      createdAt: now,
    },
    {
      id: 'do-s9',
      doNumber: 'DO-2026-0509',
      product: 'rice',
      category: 'ভিজিএফ মৎস্য',
      totalBags: 100,
      totalMt: 5.0,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'চর এলাকা মৎস্যজীবী কার্ডধারী',
      date: today,
      source: 'apps_script',
      status: 'pending',
      createdAt: now,
    },

    // ৪) জিআর চাল (২টি)
    {
      id: 'do-s10',
      doNumber: 'DO-2026-0510',
      product: 'rice',
      category: 'জিআর',
      totalBags: 40,
      totalMt: 2.0,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'উপজেলা দুর্যোগ ব্যবস্থাপনা',
      date: today,
      source: 'external_app',
      status: 'pending',
      createdAt: now,
    },
    {
      id: 'do-s11',
      doNumber: 'DO-2026-0511',
      product: 'rice',
      category: 'জিআর',
      totalBags: 60,
      totalMt: 3.0,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'পৌরসভা জরুরি ত্রাণ খাত',
      date: today,
      source: 'external_app',
      status: 'pending',
      createdAt: now,
    },

    // ৫) কাবিখা সাধারণ চাল (২টি)
    {
      id: 'do-s12',
      doNumber: 'DO-2026-0512',
      product: 'rice',
      category: 'কাবিখা সাধারণ চাল',
      totalBags: 80,
      totalMt: 4.0,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'গ্রামীণ সড়ক উন্নয়ন প্রকল্প-১',
      date: today,
      source: 'apps_script',
      status: 'pending',
      createdAt: now,
    },
    {
      id: 'do-s13',
      doNumber: 'DO-2026-0513',
      product: 'rice',
      category: 'কাবিখা সাধারণ চাল',
      totalBags: 70,
      totalMt: 3.5,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'খাল খনন প্রকল্প-২',
      date: today,
      source: 'apps_script',
      status: 'pending',
      createdAt: now,
    },

    // === গম (Wheat) — শুধু কাবিখা গম, ইপি গম, ওএমএস সাধারণ গম ===
    // ১) কাবিখা বিশেষ গম / কাবিখা গম (৩টি)
    {
      id: 'do-s2',
      doNumber: 'DO-2026-0502',
      product: 'wheat',
      category: 'কাবিখা গম',
      totalBags: 100,
      totalMt: 5.0,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'উপজেলা প্রকল্প বাস্তবায়ন অফিস',
      date: today,
      source: 'apps_script',
      status: 'pending',
      createdAt: now,
    },
    {
      id: 'do-s14',
      doNumber: 'DO-2026-0514',
      product: 'wheat',
      category: 'কাবিখা গম',
      totalBags: 80,
      totalMt: 4.0,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'সদর বাঁধ সংস্কার প্রকল্প',
      date: today,
      source: 'apps_script',
      status: 'pending',
      createdAt: now,
    },
    {
      id: 'do-s15',
      doNumber: 'DO-2026-0515',
      product: 'wheat',
      category: 'কাবিখা বিশেষ গম',
      totalBags: 120,
      totalMt: 6.0,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'উপজেলা সেচ উন্নয়ন প্রকল্প',
      date: today,
      source: 'apps_script',
      status: 'pending',
      createdAt: now,
    },

    // ২) ইপি গম (৩টি)
    {
      id: 'do-s16',
      doNumber: 'DO-2026-0516',
      product: 'wheat',
      category: 'ইপি গম',
      totalBags: 70,
      totalMt: 3.5,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'পুলিশ / আনসার ইপি বরাদ্দ-১',
      date: today,
      source: 'external_app',
      status: 'pending',
      createdAt: now,
    },
    {
      id: 'do-s17',
      doNumber: 'DO-2026-0517',
      product: 'wheat',
      category: 'ইপি গম',
      totalBags: 90,
      totalMt: 4.5,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'জরুরি সেবা ইপি বরাদ্দ-২',
      date: today,
      source: 'external_app',
      status: 'pending',
      createdAt: now,
    },
    {
      id: 'do-s18',
      doNumber: 'DO-2026-0518',
      product: 'wheat',
      category: 'ইপি গম',
      totalBags: 50,
      totalMt: 2.5,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'উপজেলা ইপি ডিলার-৩',
      date: today,
      source: 'external_app',
      status: 'pending',
      createdAt: now,
    },

    // ৩) ওএমএস সাধারণ গম (৩টি)
    {
      id: 'do-s19',
      doNumber: 'DO-2026-0519',
      product: 'wheat',
      category: 'ওএমএস সাধারণ গম',
      totalBags: 60,
      totalMt: 3.0,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'পৌর বাজার ওএমএস কেন্দ্র-১',
      date: today,
      source: 'apps_script',
      status: 'pending',
      createdAt: now,
    },
    {
      id: 'do-s20',
      doNumber: 'DO-2026-0520',
      product: 'wheat',
      category: 'ওএমএস সাধারণ গম',
      totalBags: 80,
      totalMt: 4.0,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'উপজেলা সদর ওএমএস কেন্দ্র-২',
      date: today,
      source: 'apps_script',
      status: 'pending',
      createdAt: now,
    },
    {
      id: 'do-s21',
      doNumber: 'DO-2026-0521',
      product: 'wheat',
      category: 'ওএমএস সাধারণ গম',
      totalBags: 50,
      totalMt: 2.5,
      deliveredBags: 0,
      deliveredMt: 0,
      recipient: 'বাসস্ট্যান্ড ওএমএস কেন্দ্র-৩',
      date: today,
      source: 'external_app',
      status: 'pending',
      createdAt: now,
    },
  ];
}

function safeLoadJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function normalizeProduct(raw: string): ProductCategory {
  if (raw === 'bosta') return 'bosta_50';
  if (
    raw === 'paddy' ||
    raw === 'rice' ||
    raw === 'wheat' ||
    raw === 'bosta_50' ||
    raw === 'bosta_30'
  ) {
    return raw;
  }
  return 'paddy';
}

export interface BatchInputPayload {
  type: 'receipt' | 'distribution';
  product: ProductCategory;
  godownNo: string;
  channel: string;
  date: string;
  referenceNo: string;
  note: string;
  items: Array<{
    khamalNo: string;
    bags: number;
    metricTons: number;
  }>;
}

export interface DoAllocationInput {
  godownNo: string;
  khamalNo: string;
  deliveredBags: number;
  deliveredMt: number;
  shortageBags: number;
  shortageMt: number;
}

export interface SelectedDoTarget {
  doId?: string;
  doNumber: string;
  category: string;
  targetBags: number;
  targetMt: number;
  recipient: string;
}

export interface DoDistributionPayload {
  doItems: SelectedDoTarget[];
  product: ProductCategory;
  date: string;
  note: string;
  markCompleted?: boolean;
  allocations: DoAllocationInput[];
}

export function useGrainStore() {
  const [transactions, setTransactions] = useState<GrainTransaction[]>(() => {
    const initialized = localStorage.getItem(STORAGE_KEY_INIT);
    if (!initialized) {
      // Check if legacy v1 data exists
      const legacy = safeLoadJson<Array<Record<string, unknown>>>(LEGACY_KEY_TX, []);
      if (legacy.length > 0) {
        const migrated = legacy.map((item) => ({
          ...(item as unknown as GrainTransaction),
          product: normalizeProduct(String(item.product || 'paddy')),
        }));
        localStorage.setItem(STORAGE_KEY_TX, JSON.stringify(migrated));
        localStorage.setItem(STORAGE_KEY_INIT, '1');
        return migrated;
      }
      const starter = createStarterTransactions();
      localStorage.setItem(STORAGE_KEY_TX, JSON.stringify(starter));
      localStorage.setItem(STORAGE_KEY_INIT, '1');
      return starter;
    }
    const loaded = safeLoadJson<Array<Record<string, unknown>>>(STORAGE_KEY_TX, []);
    return loaded.map((item) => ({
      ...(item as unknown as GrainTransaction),
      khamalNo: String(item.khamalNo || '').replace(/^খামার-/, 'খামাল-'),
      channel: String(item.channel || '')
        .replace(/বাবত/g, 'বাবদ')
        .replace(/খামার/g, 'খামাল')
        .replace(/ইনভয়েস/g, 'ইনভয়েস'),
      note: String(item.note || '')
        .replace(/খামার/g, 'খামাল')
        .replace(/সিদ্ধ/g, 'সেদ্ধ'),
      product: normalizeProduct(String(item.product || 'paddy')),
    }));
  });

  const [deliveryOrders, setDeliveryOrders] = useState<DeliveryOrder[]>(() => {
    const saved = safeLoadJson<DeliveryOrder[] | null>(STORAGE_KEY_DOS, null);
    if (!saved) {
      const starterDos = createStarterDeliveryOrders();
      localStorage.setItem(STORAGE_KEY_DOS, JSON.stringify(starterDos));
      return starterDos;
    }
    return saved;
  });

  const [channels, setChannels] = useState<ChannelConfig>(() => {
    const saved = safeLoadJson<Partial<ChannelConfig> | null>(STORAGE_KEY_CHANNELS, null);
    if (!saved) return DEFAULT_CHANNELS;
    const fixArr = (arr: string[]) =>
      arr.map((c) => c.replace(/বাবত/g, 'বাবদ').replace(/ইনভয়েস/g, 'ইনভয়েস'));
    const fixGroup = (
      g: { receipt: string[]; distribution: string[] } | undefined,
      def: { receipt: string[]; distribution: string[] }
    ) => (g ? { receipt: fixArr(g.receipt), distribution: fixArr(g.distribution) } : def);
    return {
      paddy: fixGroup(saved.paddy, DEFAULT_CHANNELS.paddy),
      rice: fixGroup(saved.rice, DEFAULT_CHANNELS.rice),
      wheat: fixGroup(saved.wheat, DEFAULT_CHANNELS.wheat),
      bosta_50: fixGroup(saved.bosta_50, DEFAULT_CHANNELS.bosta_50),
      bosta_30: fixGroup(saved.bosta_30, DEFAULT_CHANNELS.bosta_30),
    };
  });

  const [customGodowns, setCustomGodowns] = useState<string[]>(() =>
    safeLoadJson<string[]>(STORAGE_KEY_GODOWNS, DEFAULT_GODOWNS)
  );

  const [externalSyncConfig, setExternalSyncConfig] = useState<ExternalSyncConfig>(() => {
    const saved = safeLoadJson<Partial<ExternalSyncConfig>>(STORAGE_KEY_EXT_SYNC, {});
    let resolvedAutoSync = false;
    try {
      if (localStorage.getItem(STORAGE_KEY_MANUAL_SYNC_MIGRATED) === '1') {
        resolvedAutoSync = Boolean(saved.autoSync);
      } else {
        localStorage.setItem(STORAGE_KEY_MANUAL_SYNC_MIGRATED, '1');
        resolvedAutoSync = false;
      }
    } catch {
      resolvedAutoSync = false;
    }
    return {
      ...DEFAULT_EXTERNAL_SYNC,
      ...saved,
      autoSync: resolvedAutoSync,
      externalAppUrl:
        saved.externalAppUrl && saved.externalAppUrl.trim()
          ? saved.externalAppUrl.trim()
          : DEFAULT_MAIN_APPS_SCRIPT_URL,
      enabled: saved.enabled !== undefined ? saved.enabled : true,
    };
  });
  const [isSyncingDos, setIsSyncingDos] = useState(false);

  const [gasData, setGasData] = useState<GasAppData | null>(() =>
    safeLoadJson<GasAppData | null>(STORAGE_KEY_GAS_CACHE, null)
  );
  const [gasBridgeStatus, setGasBridgeStatus] = useState<GasBridgeStatus>(() =>
    safeLoadJson<GasAppData | null>(STORAGE_KEY_GAS_CACHE, null) ? 'connected' : 'idle'
  );
  const [gasBridgeMessage, setGasBridgeMessage] = useState<string>(() =>
    safeLoadJson<GasAppData | null>(STORAGE_KEY_GAS_CACHE, null)
      ? 'সংরক্ষিত ডেটা লোড হয়েছে — শুধু রিফ্রেশ করলে নতুন আপডেট আসবে'
      : ''
  );
  const [selectedFY, setSelectedFY] = useState<string | null>(() => {
    try {
      return localStorage.getItem(STORAGE_KEY_SELECTED_FY) || null;
    } catch {
      return null;
    }
  });
  const [isSubmittingGas, setIsSubmittingGas] = useState(false);

  // Direct Google Sheets + Firebase Auth state (access token is kept ONLY in memory)
  const [googleSheetsConfig, setGoogleSheetsConfig] = useState<GoogleSheetsConfig>(() => {
    const saved = safeLoadJson<Partial<GoogleSheetsConfig>>(STORAGE_KEY_GSHEETS, {});
    return {
      ...DEFAULT_GOOGLE_SHEETS_CONFIG,
      ...saved,
      excludeDoNos: Array.isArray(saved.excludeDoNos)
        ? saved.excludeDoNos
        : DEFAULT_GOOGLE_SHEETS_CONFIG.excludeDoNos,
    };
  });
  const [googleUser, setGoogleUser] = useState<User | null>(null);
  const [googleAccessTokenState, setGoogleAccessTokenState] = useState<string | null>(() =>
    getGoogleAccessToken()
  );
  const [isGoogleSigningIn, setIsGoogleSigningIn] = useState(false);
  const [googleAuthError, setGoogleAuthError] = useState<string | null>(null);
  const [availableSpreadsheets, setAvailableSpreadsheets] = useState<DriveSpreadsheetFile[]>([]);
  const [isLoadingSpreadsheets, setIsLoadingSpreadsheets] = useState(false);
  const [mainSheetTabs, setMainSheetTabs] = useState<string[]>(() =>
    safeLoadJson<string[]>(STORAGE_KEY_MAIN_TABS, [])
  );
  const [dataSourceMode, setDataSourceMode] = useState<'google_sheets' | 'apps_script' | 'local'>(
    () => {
      try {
        const savedMode = localStorage.getItem(STORAGE_KEY_DATA_SOURCE);
        if (savedMode === 'google_sheets' || savedMode === 'apps_script' || savedMode === 'local') {
          return savedMode;
        }
        const hasGas = Boolean(safeLoadJson<GasAppData | null>(STORAGE_KEY_GAS_CACHE, null));
        if (hasGas) {
          const savedSheets = safeLoadJson<Partial<GoogleSheetsConfig>>(STORAGE_KEY_GSHEETS, {});
          return savedSheets.mainSpreadsheetId ? 'google_sheets' : 'apps_script';
        }
      } catch {
        // Ignore storage error
      }
      return 'local';
    }
  );

  // Mandatory confirmation dialog state for Google Sheets writes & deletes
  const [pendingSheetConfirm, setPendingSheetConfirm] =
    useState<SheetWriteConfirmRequest | null>(null);
  const confirmResolverRef = useRef<((accepted: boolean) => void) | null>(null);

  const requestSheetConfirm = useCallback(
    (req: SheetWriteConfirmRequest): Promise<boolean> => {
      return new Promise((resolve) => {
        if (confirmResolverRef.current) {
          confirmResolverRef.current(false);
        }
        confirmResolverRef.current = resolve;
        setPendingSheetConfirm(req);
      });
    },
    []
  );

  const resolveSheetConfirm = useCallback((accepted: boolean) => {
    const fn = confirmResolverRef.current;
    confirmResolverRef.current = null;
    setPendingSheetConfirm(null);
    fn?.(accepted);
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_GSHEETS, JSON.stringify(googleSheetsConfig));
    } catch {
      // Storage quota safeguard
    }
  }, [googleSheetsConfig]);

  useEffect(() => {
    const unsub = initGoogleAuth(
      (user, token) => {
        setGoogleUser(user);
        setGoogleAccessTokenState(token);
      },
      () => {
        setGoogleUser(null);
        setGoogleAccessTokenState(null);
      }
    );
    return () => unsub();
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_TX, JSON.stringify(transactions));
    } catch {
      // Storage quota safeguard
    }
  }, [transactions]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_DOS, JSON.stringify(deliveryOrders));
    } catch {
      // Storage quota safeguard
    }
  }, [deliveryOrders]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_CHANNELS, JSON.stringify(channels));
    } catch {
      // Storage quota safeguard
    }
  }, [channels]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_GODOWNS, JSON.stringify(customGodowns));
    } catch {
      // Storage quota safeguard
    }
  }, [customGodowns]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_EXT_SYNC, JSON.stringify(externalSyncConfig));
    } catch {
      // Storage quota safeguard
    }
  }, [externalSyncConfig]);

  const [fortnightlySettings, setFortnightlySettings] = useState<FortnightlyReportSettings>(() => {
    const saved = safeLoadJson<Partial<FortnightlyReportSettings>>(
      STORAGE_KEY_FORTNIGHTLY_SETTINGS,
      {}
    );
    return {
      ...DEFAULT_FORTNIGHTLY_REPORT_SETTINGS,
      ...saved,
    };
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_FORTNIGHTLY_SETTINGS, JSON.stringify(fortnightlySettings));
    } catch {
      // Storage quota safeguard
    }
  }, [fortnightlySettings]);

  useEffect(() => {
    try {
      if (gasData) {
        localStorage.setItem(STORAGE_KEY_GAS_CACHE, JSON.stringify(gasData));
      }
    } catch {
      // Storage quota safeguard
    }
  }, [gasData]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_DATA_SOURCE, dataSourceMode);
    } catch {
      // Storage quota safeguard
    }
  }, [dataSourceMode]);

  useEffect(() => {
    try {
      if (selectedFY) {
        localStorage.setItem(STORAGE_KEY_SELECTED_FY, selectedFY);
      } else {
        localStorage.removeItem(STORAGE_KEY_SELECTED_FY);
      }
    } catch {
      // Storage quota safeguard
    }
  }, [selectedFY]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_MAIN_TABS, JSON.stringify(mainSheetTabs));
    } catch {
      // Storage quota safeguard
    }
  }, [mainSheetTabs]);

  // One-time non-destructive merge of expanded sample khamals & DOs for existing browser sessions
  useEffect(() => {
    try {
      if (localStorage.getItem(STORAGE_KEY_SAMPLE_SEED) === '1') return;
      const starterTx = createStarterTransactions();
      setTransactions((prev) => {
        const existingKeys = new Set(
          prev.map((t) => `${t.product}::${t.godownNo}::${t.khamalNo}`)
        );
        const missing = starterTx.filter(
          (s) => !existingKeys.has(`${s.product}::${s.godownNo}::${s.khamalNo}`)
        );
        return missing.length > 0 ? [...prev, ...missing] : prev;
      });
      const starterDos = createStarterDeliveryOrders();
      const oldStarterIds = new Set(['do-s2', 'do-s14', 'do-s15', 'do-s16', 'do-s17', 'do-s18', 'do-s19', 'do-s20', 'do-s21', 'do-s22']);
      setDeliveryOrders((prev) => {
        const withoutOldWheatStarters = prev.filter(
          (d) => !oldStarterIds.has(d.id) || d.deliveredMt > 0 || d.status === 'distributed'
        );
        const existingDos = new Set(
          withoutOldWheatStarters.map((d) => `${d.product}::${d.doNumber}`)
        );
        const missing = starterDos.filter(
          (s) => !existingDos.has(`${s.product}::${s.doNumber}`)
        );
        return [...withoutOldWheatStarters, ...missing];
      });
      setChannels((prev) => ({
        ...prev,
        wheat: {
          ...prev.wheat,
          distribution: Array.from(
            new Set([
              'কাবিখা গম',
              'ইপি গম',
              'ওএমএস সাধারণ গম',
              ...prev.wheat.distribution.filter(
                (c) => !['জিআর', 'বিডব্লিউবি', 'ভিজিএফ মৎস্য', 'ভিজিএফ ঈদ', 'ওএমএস (OMS)'].includes(c)
              ),
            ])
          ),
        },
      }));
      localStorage.setItem(STORAGE_KEY_SAMPLE_SEED, '1');
    } catch {
      // Storage safeguard
    }
  }, []);

  // Derive pending & distributed DOs: prefer live Google Apps Script when connected
  const gasPendingDos = useMemo<DeliveryOrder[]>(() => {
    if (gasBridgeStatus !== 'connected' || !gasData) return [];
    const nowIso = new Date().toISOString();
    return (gasData.availableDOs || []).map((d, idx) => {
      const remMt = parseGasNumber(d.remainingMT);
      const totalMt = parseGasNumber(d.totalMT ?? d.remainingMT);
      const deliveredMt = Math.max(0, Number((totalMt - remMt).toFixed(4)));
      const estTotalBags = d.bags ? Math.round(parseGasNumber(d.bags)) : Math.round(totalMt * 20);
      const estDelBags =
        totalMt > 0 ? Math.round((deliveredMt / totalMt) * estTotalBags) : 0;
      const who = [d.union, d.recipient].filter(Boolean).join(' - ');
      const cat = d.khath || 'বিডব্লিউবি';

      return {
        id: `gas-do-${d.doNo}-${idx}`,
        externalId: d.doNo,
        doNumber: String(d.doNo),
        product: inferDefaultProductFromCategory(cat),
        category: cat,
        totalBags: estTotalBags,
        totalMt,
        deliveredBags: estDelBags,
        deliveredMt,
        recipient: who,
        date: d.date || todayIsoDate(),
        source: 'apps_script',
        status: 'pending',
        createdAt: nowIso,
      };
    });
  }, [gasBridgeStatus, gasData]);

  const gasDistributedDos = useMemo<DeliveryOrder[]>(() => {
    if (gasBridgeStatus !== 'connected' || !gasData) return [];
    const nowIso = new Date().toISOString();
    const khamalProdMap = new Map(
      (gasData.masterGrain || []).map((m) => [String(m.khamalId), itemNameBnToProduct(m.item)])
    );
    return (gasData.issueList || [])
      .slice()
      .reverse()
      .map((r, idx) => {
        const cat = r.khath || '-';
        const inferred =
          (r.khamalId ? khamalProdMap.get(String(r.khamalId)) : undefined) ||
          inferDefaultProductFromCategory(cat);
        return {
          id: `gas-iss-${r.id || idx}`,
          externalId: r.doNo,
          doNumber: String(r.doNo || '-'),
          product: inferred,
          category: cat,
          totalBags: Math.round(parseGasNumber(r.bags)),
          totalMt: parseGasNumber(r.weight),
          deliveredBags: Math.round(parseGasNumber(r.bags)),
          deliveredMt: parseGasNumber(r.weight),
          recipient: r.reference || '',
          date: r.date || todayIsoDate(),
          source: 'apps_script',
          status: 'distributed',
          distributedAt: r.date || nowIso,
          distributedFrom: r.khamalId ? [`খামাল ${r.khamalId}`] : [],
          createdAt: nowIso,
        };
      });
  }, [gasBridgeStatus, gasData]);

  const pendingDos = useMemo(() => {
    if (gasBridgeStatus === 'connected' && gasData) {
      return gasPendingDos;
    }
    return deliveryOrders.filter((d) => isDoPending(d));
  }, [gasBridgeStatus, gasData, gasPendingDos, deliveryOrders]);

  const distributedDos = useMemo(() => {
    if (gasBridgeStatus === 'connected' && gasData) {
      return gasDistributedDos;
    }
    return deliveryOrders.filter((d) => !isDoPending(d));
  }, [gasBridgeStatus, gasData, gasDistributedDos, deliveryOrders]);

  const updateExternalSyncConfig = useCallback((patch: Partial<ExternalSyncConfig>) => {
    setExternalSyncConfig((prev) => ({ ...prev, ...patch }));
  }, []);

  const updateGoogleSheetsConfig = useCallback((patch: Partial<GoogleSheetsConfig>) => {
    setGoogleSheetsConfig((prev) => ({ ...prev, ...patch }));
  }, []);

  const mergeLiveCategories = useCallback((cats: Record<string, string[]>) => {
    setChannels((prev) => ({
      ...prev,
      rice: {
        ...prev.rice,
        receipt: cats['চাল']?.length ? cats['চাল'] : prev.rice.receipt,
        distribution: cats['চাল']?.length ? cats['চাল'] : prev.rice.distribution,
      },
      paddy: {
        ...prev.paddy,
        receipt: cats['ধান']?.length ? cats['ধান'] : prev.paddy.receipt,
        distribution: cats['ধান']?.length ? cats['ধান'] : prev.paddy.distribution,
      },
      wheat: {
        ...prev.wheat,
        receipt: cats['গম']?.length ? cats['গম'] : prev.wheat.receipt,
        distribution: cats['গম']?.length ? cats['গম'] : prev.wheat.distribution,
      },
    }));
  }, []);

  const syncExternalDos = useCallback(
    async (
      overrideConfig?: Partial<ExternalSyncConfig>,
      fyOverride?: string | null,
      overrideSheets?: {
        accessToken?: string | null;
        sheetsConfig?: GoogleSheetsConfig;
      }
    ): Promise<{ ok: boolean; added: number; error?: string; needsBridge?: boolean }> => {
      const cfg = { ...externalSyncConfig, ...overrideConfig };
      const sCfg = overrideSheets?.sheetsConfig || googleSheetsConfig;
      const token =
        overrideSheets?.accessToken !== undefined
          ? overrideSheets.accessToken
          : googleAccessTokenState || getGoogleAccessToken();
      const targetUrl = cfg.enabled ? cfg.externalAppUrl.trim() : '';
      const fyToFetch = fyOverride !== undefined ? fyOverride : selectedFY;

      setIsSyncingDos(true);
      try {
        // Priority 1: Direct Google Sheets API (NO Code.gs editing required!)
        if (sCfg.enabled && token && extractSpreadsheetId(sCfg.mainSpreadsheetId)) {
          try {
            const { data, meta } = await fetchGasAppDataFromSheets(token, sCfg, fyToFetch);
            setGasData(data);
            setMainSheetTabs(meta.sheetTitles);
            if (!sCfg.mainSpreadsheetName || sCfg.mainSpreadsheetName !== meta.title) {
              setGoogleSheetsConfig((prev) => ({ ...prev, mainSpreadsheetName: meta.title }));
            }
            setGasBridgeStatus('connected');
            setDataSourceMode('google_sheets');
            setGoogleAuthError(null);
            setGasBridgeMessage(
              `${data.settings?.lsdName || meta.title} — Google Sheets থেকে সংরক্ষিত`
            );
            if (data.fy?.name && fyOverride === undefined && !selectedFY) {
              setSelectedFY(data.fy.name);
            }
            if (data.settings?.categories) {
              mergeLiveCategories(data.settings.categories);
            }
            setExternalSyncConfig((prev) => ({
              ...prev,
              lastSyncAt: new Date().toISOString(),
              lastSyncStatus: 'ok',
              lastSyncMessage: `Google Sheets: ${(data.availableDOs || []).length}টি পেন্ডিং ডিও · ${(data.grainData || []).length}টি খামাল`,
            }));
            return { ok: true, added: (data.availableDOs || []).length };
          } catch (sheetErr) {
            if (sheetErr instanceof GoogleAuthExpiredError) {
              clearGoogleAccessToken();
              setGoogleAccessTokenState(null);
              setGoogleAuthError(sheetErr.message);
            } else {
              const errMsg =
                sheetErr instanceof Error ? sheetErr.message : 'Google Sheet পড়া যায়নি।';
              setGoogleAuthError(errMsg);
              const hasCached = Boolean(safeLoadJson<GasAppData | null>(STORAGE_KEY_GAS_CACHE, null));
              setGasBridgeStatus(hasCached ? 'connected' : 'error');
              setGasBridgeMessage(
                hasCached
                  ? 'সংরক্ষিত Google ডেটা প্রদর্শিত হচ্ছে (অনলাইন আপডেট ব্যর্থ হয়েছে)'
                  : errMsg
              );
              return { ok: false, added: 0, error: errMsg };
            }
          }
        }

        // If user has saved Google Sheets data and no active token yet (app reopened offline/cached), preserve cache!
        const hasCachedData = Boolean(safeLoadJson<GasAppData | null>(STORAGE_KEY_GAS_CACHE, null));
        if (hasCachedData && sCfg.enabled && extractSpreadsheetId(sCfg.mainSpreadsheetId) && !token) {
          setGasBridgeStatus('connected');
          setGasBridgeMessage('সংরক্ষিত ডেটা চালু আছে — শুধু রিফ্রেশ করলে আপডেট আসবে');
          return { ok: true, added: 0 };
        }

        if (targetUrl) {
          const gasRes = await callGasAction<GasAppData>(targetUrl, 'getAppData', {
            fy: fyToFetch || '',
          });

          if (gasRes.ok && gasRes.data && typeof gasRes.data === 'object' && 'dashboard' in gasRes.data) {
            const data = gasRes.data;
            setGasData(data);
            setGasBridgeStatus('connected');
            setDataSourceMode('apps_script');
            setGasBridgeMessage(`${data.settings?.lsdName || 'এলএসডি'} — গুগল অ্যাপ ডেটা সংরক্ষিত`);
            if (data.fy?.name && fyOverride === undefined && !selectedFY) {
              setSelectedFY(data.fy.name);
            }

            if (data.settings?.categories) {
              mergeLiveCategories(data.settings.categories);
            }

            setExternalSyncConfig((prev) => ({
              ...prev,
              lastSyncAt: new Date().toISOString(),
              lastSyncStatus: 'ok',
              lastSyncMessage: `${(data.availableDOs || []).length}টি পেন্ডিং ডিও · ${(data.grainData || []).length}টি রানিং খামাল`,
            }));
            return { ok: true, added: (data.availableDOs || []).length };
          }

          let gasBridgeFailure: {
            needsBridge?: boolean;
            error?: string;
          } | null = null;

          if (gasRes.code === 'HTML_NOT_JSON') {
            const hasCached = Boolean(safeLoadJson<GasAppData | null>(STORAGE_KEY_GAS_CACHE, null));
            setGasBridgeStatus(hasCached ? 'connected' : 'needs_bridge');
            setGasBridgeMessage(
              hasCached
                ? 'সংরক্ষিত ডেটা চালু আছে — শুধু রিফ্রেশ করলে আপডেট আসবে'
                : gasRes.error || 'মেইন অ্যাপে Code.gs JSON ব্রিজ কোড যুক্ত করা প্রয়োজন।'
            );
            gasBridgeFailure = { needsBridge: true, error: gasRes.error };
          } else if (!gasRes.ok && targetUrl.includes('script.google.com')) {
            const hasCached = Boolean(safeLoadJson<GasAppData | null>(STORAGE_KEY_GAS_CACHE, null));
            setGasBridgeStatus(hasCached ? 'connected' : 'error');
            setGasBridgeMessage(
              hasCached
                ? 'সংরক্ষিত ডেটা প্রদর্শিত হচ্ছে — শুধু রিফ্রেশ করলে নতুন আপডেট আসবে'
                : gasRes.error || 'মেইন ওয়েব অ্যাপে সংযোগ করা যায়নি।'
            );
            gasBridgeFailure = { error: gasRes.error };
          }

          if (gasBridgeFailure) {
            // Even without Code.gs bridge, still pull any DOs pushed via Zapier / external webhook
            let webhookAdded = 0;
            const isAndroidOffline =
              typeof window !== 'undefined' &&
              window.location.hostname === 'appassets.androidplatform.net';
            if (!isAndroidOffline) {
              try {
                const pullRes = await fetch('/api/external-sync/pull', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    url: '',
                    apiSecret: cfg.apiSecret || '',
                  }),
                });
                const pullData = (await pullRes.json()) as {
                  ok: boolean;
                  deliveryOrders?: DeliveryOrder[];
                };
                if (pullRes.ok && pullData.ok && Array.isArray(pullData.deliveryOrders)) {
                  const incomingList = pullData.deliveryOrders;
                  if (incomingList.length > 0) {
                    setDeliveryOrders((prev) => {
                      const next = [...prev];
                      for (const incoming of incomingList) {
                        const matchIdx = next.findIndex(
                          (existing) =>
                            (incoming.externalId &&
                              existing.externalId &&
                              existing.externalId === incoming.externalId) ||
                            (existing.doNumber.trim().toLowerCase() ===
                              incoming.doNumber.trim().toLowerCase() &&
                              existing.product === incoming.product)
                        );
                        if (matchIdx >= 0) {
                          const existing = next[matchIdx];
                          const keepDistributed =
                            !isDoPending(existing) || incoming.status === 'distributed';
                          next[matchIdx] = {
                            ...existing,
                            status: keepDistributed ? 'distributed' : 'pending',
                          };
                        } else {
                          next.unshift(incoming);
                          webhookAdded += 1;
                        }
                      }
                      return next;
                    });
                  }
                  if (incomingList.length > 0) {
                    setExternalSyncConfig((prev) => ({
                      ...prev,
                      lastSyncAt: new Date().toISOString(),
                      lastSyncStatus: 'ok',
                      lastSyncMessage: `ওয়েব-হুক থেকে ${incomingList.length}টি ডিও সিঙ্ক হয়েছে`,
                    }));
                    return { ok: true, added: webhookAdded };
                  }
                }
              } catch {
                // Ignore pull error and surface original bridge message below
              }
            }

            setExternalSyncConfig((prev) => ({
              ...prev,
              lastSyncAt: new Date().toISOString(),
              lastSyncStatus: 'error',
              lastSyncMessage: gasBridgeFailure.needsBridge
                ? 'Code.gs JSON ব্রিজ অপেক্ষমাণ'
                : gasBridgeFailure.error,
            }));
            return {
              ok: false,
              added: webhookAdded,
              needsBridge: gasBridgeFailure.needsBridge,
              error: gasBridgeFailure.error,
            };
          }
        }

        // Generic external JSON endpoint fallback (non-Apps-Script URLs)
        const isAndroidOfflineOrigin =
          typeof window !== 'undefined' &&
          window.location.hostname === 'appassets.androidplatform.net';

        let fetchedOrders: DeliveryOrder[] = [];
        if (isAndroidOfflineOrigin && targetUrl) {
          const res = await fetch(targetUrl, { method: 'GET', redirect: 'follow' });
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          const json = await res.json();
          const norm = normalizeExternalDoList(json);
          const nowIso = new Date().toISOString();
          fetchedOrders = norm.map((item) => ({
            id: `ext-${item.externalId}`,
            externalId: item.externalId,
            doNumber: item.doNumber,
            product: item.product,
            category: item.category,
            totalBags: item.totalBags,
            totalMt: item.totalMt,
            deliveredBags: item.deliveredBags,
            deliveredMt: item.deliveredMt,
            recipient: item.recipient,
            date: item.date,
            source: 'external_app',
            status: item.status,
            createdAt: nowIso,
          }));
        } else if (!isAndroidOfflineOrigin) {
          const res = await fetch('/api/external-sync/pull', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              url: '',
              apiSecret: cfg.apiSecret || '',
            }),
          });
          const data = (await res.json()) as {
            ok: boolean;
            deliveryOrders?: DeliveryOrder[];
          };
          if (res.ok && data.ok && Array.isArray(data.deliveryOrders)) {
            fetchedOrders = data.deliveryOrders;
          }
        }

        let addedCount = 0;
        if (fetchedOrders.length > 0) {
          setDeliveryOrders((prev) => {
            const next = [...prev];
            for (const incoming of fetchedOrders) {
              const matchIdx = next.findIndex(
                (existing) =>
                  (incoming.externalId &&
                    existing.externalId &&
                    existing.externalId === incoming.externalId) ||
                  (existing.doNumber.trim().toLowerCase() ===
                    incoming.doNumber.trim().toLowerCase() &&
                    existing.product === incoming.product)
              );
              if (matchIdx >= 0) {
                const existing = next[matchIdx];
                const keepDistributed = !isDoPending(existing) || incoming.status === 'distributed';
                next[matchIdx] = {
                  ...existing,
                  status: keepDistributed ? 'distributed' : 'pending',
                };
              } else {
                next.unshift(incoming);
                addedCount += 1;
              }
            }
            return next;
          });
        }

        return { ok: true, added: addedCount };
      } catch (err) {
        const message =
          err instanceof Error ? err.message : 'মেইন ওয়েব অ্যাপের সাথে সিঙ্ক করা যায়নি।';
        const hasCached = Boolean(safeLoadJson<GasAppData | null>(STORAGE_KEY_GAS_CACHE, null));
        setGasBridgeStatus(hasCached ? 'connected' : 'error');
        setGasBridgeMessage(
          hasCached ? 'অফলাইন/ক্যাশ মোড — সর্বশেষ ওয়েব অ্যাপ ডেটা প্রদর্শিত হচ্ছে' : message
        );
        return { ok: false, added: 0, error: message };
      } finally {
        setIsSyncingDos(false);
      }
    },
    [externalSyncConfig, googleSheetsConfig, googleAccessTokenState, selectedFY, mergeLiveCategories]
  );

  const refreshSpreadsheetsList = useCallback(
    async (tokenOverride?: string | null): Promise<DriveSpreadsheetFile[]> => {
      const token = tokenOverride || googleAccessTokenState || getGoogleAccessToken();
      if (!token) return [];
      setIsLoadingSpreadsheets(true);
      try {
        const files = await listUserSpreadsheets(token);
        setAvailableSpreadsheets(files);
        return files;
      } catch (err) {
        if (err instanceof GoogleAuthExpiredError) {
          clearGoogleAccessToken();
          setGoogleAccessTokenState(null);
        }
        setGoogleAuthError(
          err instanceof Error ? err.message : 'Google Drive শিট তালিকা আনা যায়নি।'
        );
        return [];
      } finally {
        setIsLoadingSpreadsheets(false);
      }
    },
    [googleAccessTokenState]
  );

  const handleGoogleSignIn = useCallback(async (): Promise<{ ok: boolean; error?: string }> => {
    setIsGoogleSigningIn(true);
    setGoogleAuthError(null);
    try {
      const { user, accessToken } = await googleSignIn();
      setGoogleUser(user);
      setGoogleAccessTokenState(accessToken);

      const files = await listUserSpreadsheets(accessToken).catch(() => [] as DriveSpreadsheetFile[]);
      setAvailableSpreadsheets(files);

      let nextConfig = { ...googleSheetsConfig, enabled: true };
      if (!extractSpreadsheetId(nextConfig.mainSpreadsheetId) && files.length > 0) {
        const detected = await autoDetectUserSpreadsheets(accessToken, files);
        if (detected.main) {
          nextConfig = {
            ...nextConfig,
            mainSpreadsheetId: detected.main.file.id,
            mainSpreadsheetName: detected.main.meta.title,
          };
          setMainSheetTabs(detected.main.meta.sheetTitles);
        }
        if (detected.externalDo && !extractSpreadsheetId(nextConfig.externalDoSpreadsheetId)) {
          nextConfig = {
            ...nextConfig,
            externalDoSpreadsheetId: detected.externalDo.file.id,
            externalDoSpreadsheetName: detected.externalDo.meta.title,
          };
        }
      } else if (extractSpreadsheetId(nextConfig.mainSpreadsheetId)) {
        try {
          const meta = await getSpreadsheetMetadata(accessToken, nextConfig.mainSpreadsheetId);
          setMainSheetTabs(meta.sheetTitles);
          nextConfig = { ...nextConfig, mainSpreadsheetName: meta.title };
        } catch {
          // Ignore metadata failure here; syncExternalDos will surface exact error
        }
      }

      setGoogleSheetsConfig(nextConfig);
      if (extractSpreadsheetId(nextConfig.mainSpreadsheetId)) {
        await syncExternalDos(undefined, undefined, {
          accessToken,
          sheetsConfig: nextConfig,
        });
      }
      return { ok: true };
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Google Sign-In ব্যর্থ হয়েছে।';
      setGoogleAuthError(msg);
      return { ok: false, error: msg };
    } finally {
      setIsGoogleSigningIn(false);
    }
  }, [googleSheetsConfig, syncExternalDos]);

  const handleGoogleSignOut = useCallback(async () => {
    await googleLogout();
    setGoogleUser(null);
    setGoogleAccessTokenState(null);
    setAvailableSpreadsheets([]);
    if (dataSourceMode === 'google_sheets') {
      setDataSourceMode('local');
    }
  }, [dataSourceMode]);

  const selectSpreadsheetsAndSync = useCallback(
    async (patch: Partial<GoogleSheetsConfig>) => {
      const nextConfig: GoogleSheetsConfig = {
        ...googleSheetsConfig,
        ...patch,
        enabled: patch.enabled !== undefined ? patch.enabled : true,
        mainSpreadsheetId: extractSpreadsheetId(
          patch.mainSpreadsheetId !== undefined
            ? patch.mainSpreadsheetId
            : googleSheetsConfig.mainSpreadsheetId
        ),
        externalDoSpreadsheetId: extractSpreadsheetId(
          patch.externalDoSpreadsheetId !== undefined
            ? patch.externalDoSpreadsheetId
            : googleSheetsConfig.externalDoSpreadsheetId
        ),
      };
      setGoogleSheetsConfig(nextConfig);
      const token = googleAccessTokenState || getGoogleAccessToken();
      if (token && nextConfig.mainSpreadsheetId) {
        return syncExternalDos(undefined, undefined, {
          accessToken: token,
          sheetsConfig: nextConfig,
        });
      }
      return { ok: false, added: 0, error: 'প্রথমে Google Sign-In করুন এবং Spreadsheet ID দিন।' };
    },
    [googleSheetsConfig, googleAccessTokenState, syncExternalDos]
  );

  // Hydrate initial Web App seed inside bundled Android APK if present
  useEffect(() => {
    const isAndroidOffline =
      typeof window !== 'undefined' &&
      window.location.hostname === 'appassets.androidplatform.net';
    if (!isAndroidOffline) return;

    let cancelled = false;
    (async () => {
      try {
        const res = await fetch('/web-seed.json');
        if (!res.ok) return;
        const seed = (await res.json()) as {
          externalAppUrl?: string;
          apiSecret?: string;
          gasData?: GasAppData | null;
          fortnightlySettings?: Partial<FortnightlyReportSettings>;
          googleSheetsConfig?: Partial<GoogleSheetsConfig>;
        };
        if (cancelled) return;

        if (seed.externalAppUrl && !localStorage.getItem(STORAGE_KEY_EXT_SYNC)) {
          setExternalSyncConfig((prev) => ({
            ...prev,
            enabled: true,
            externalAppUrl: seed.externalAppUrl!.trim(),
            apiSecret: seed.apiSecret ?? prev.apiSecret,
          }));
        }
        if (seed.googleSheetsConfig && !localStorage.getItem(STORAGE_KEY_GSHEETS)) {
          setGoogleSheetsConfig((prev) => ({
            ...prev,
            ...seed.googleSheetsConfig,
          }));
        }
        if (seed.fortnightlySettings && !localStorage.getItem(STORAGE_KEY_FORTNIGHTLY_SETTINGS)) {
          setFortnightlySettings((prev) => ({
            ...prev,
            ...seed.fortnightlySettings,
          }));
        }
        if (seed.gasData && !localStorage.getItem(STORAGE_KEY_GAS_CACHE)) {
          setGasData(seed.gasData);
          setGasBridgeStatus('connected');
          setGasBridgeMessage('ওয়েব অ্যাপ থেকে সংরক্ষিত সকল তথ্য লোড হয়েছে');
        }
      } catch {
        // Ignore if web-seed.json is absent
      }
    })();

    return () => {
      cancelled = true;
    };
  }, []);

  // Sync ONLY if no saved data exists yet, or when user explicitly turns on background autoSync
  useEffect(() => {
    const hasSavedGasCache = Boolean(safeLoadJson<GasAppData | null>(STORAGE_KEY_GAS_CACHE, null));
    if (!hasSavedGasCache && externalSyncConfig.enabled) {
      void syncExternalDos();
    }
    if (!externalSyncConfig.enabled || !externalSyncConfig.autoSync) return;
    const ms = Math.max(15, externalSyncConfig.syncIntervalSec || 60) * 1000;
    const timer = window.setInterval(() => {
      void syncExternalDos();
    }, ms);
    return () => window.clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    externalSyncConfig.enabled,
    externalSyncConfig.autoSync,
    externalSyncConfig.externalAppUrl,
    externalSyncConfig.syncIntervalSec,
  ]);

  const manualRefreshData = useCallback(async (): Promise<{
    ok: boolean;
    added: number;
    error?: string;
  }> => {
    const token = googleAccessTokenState || getGoogleAccessToken();
    const sheetId = extractSpreadsheetId(googleSheetsConfig.mainSpreadsheetId);
    if ((dataSourceMode === 'google_sheets' || Boolean(sheetId)) && !token) {
      const signInRes = await handleGoogleSignIn();
      if (!signInRes.ok) {
        return { ok: false, added: 0, error: signInRes.error };
      }
      return { ok: true, added: 0 };
    }
    return syncExternalDos();
  }, [
    googleAccessTokenState,
    googleSheetsConfig.mainSpreadsheetId,
    dataSourceMode,
    handleGoogleSignIn,
    syncExternalDos,
  ]);

  const changeFiscalYear = useCallback(
    async (fyName: string) => {
      setSelectedFY(fyName);
      await syncExternalDos(undefined, fyName);
    },
    [syncExternalDos]
  );

  const dispatchRemoteWrite = useCallback(
    async (
      action: string,
      payload: Record<string, unknown>
    ): Promise<{ ok: boolean; message?: string; error?: string }> => {
      const token = googleAccessTokenState || getGoogleAccessToken();
      const sheetId = extractSpreadsheetId(googleSheetsConfig.mainSpreadsheetId);
      if (googleSheetsConfig.enabled && sheetId) {
        if (!token) {
          return {
            ok: false,
            error:
              'Google Sheet-এ তথ্য সেভ করতে প্রথমে উপরের «গুগল দিয়ে লগইন করুন» বাটনে একবার সাইন-ইন করুন।',
          };
        }
        return writeActionToSheets(token, sheetId, action, payload);
      }
      const targetUrl = externalSyncConfig.externalAppUrl.trim() || DEFAULT_MAIN_APPS_SCRIPT_URL;
      const res = await callGasAction(targetUrl, action, payload);
      if (!res.ok) {
        return { ok: false, error: res.error || 'অ্যাপ স্ক্রিপ্টে ডেটা সেভ করা যায়নি।' };
      }
      return { ok: true, message: res.message };
    },
    [googleAccessTokenState, googleSheetsConfig, externalSyncConfig.externalAppUrl]
  );

  const runGasWriteAction = useCallback(
    async (
      action: string,
      payload: Record<string, unknown>,
      confirmMeta?: SheetWriteConfirmRequest
    ): Promise<{ ok: boolean; message?: string; error?: string }> => {
      const token = googleAccessTokenState || getGoogleAccessToken();
      const sheetId = extractSpreadsheetId(googleSheetsConfig.mainSpreadsheetId);
      const usingDirectSheets = Boolean(googleSheetsConfig.enabled && token && sheetId);

      if (usingDirectSheets) {
        const isDelete = action === 'deleteRecord' || action === 'deleteFiscalYear';
        const sheetNameLabel =
          googleSheetsConfig.mainSpreadsheetName || 'Google Spreadsheet';
        const accepted = await requestSheetConfirm(
          confirmMeta || {
            title: isDelete
              ? 'Google Sheet থেকে তথ্য মুছে ফেলা নিশ্চিত করুন'
              : 'Google Sheet-এ তথ্য সংরক্ষণ নিশ্চিত করুন',
            description: isDelete
              ? 'এই কাজটি সম্পন্ন হলে আপনার Google Sheet থেকে নির্বাচিত রেকর্ডটি মুছে যাবে।'
              : 'নিচের তথ্যটি সরাসরি আপনার Google Sheet-এ লেখা হবে।',
            spreadsheetName: sheetNameLabel,
            targetSheets: [String(payload.sheetName || 'Settings')],
            details: Object.entries(payload)
              .slice(0, 5)
              .map(([k, v]) => `${k}: ${typeof v === 'object' ? JSON.stringify(v) : String(v)}`),
            isDestructive: isDelete,
          }
        );
        if (!accepted) {
          return { ok: false, error: 'ব্যবহারকারী বাতিল করেছেন।' };
        }
      }

      setIsSubmittingGas(true);
      try {
        const res = await dispatchRemoteWrite(action, payload);
        if (!res.ok) {
          return { ok: false, error: res.error || 'ডেটা সংরক্ষণ করা যায়নি।' };
        }
        await syncExternalDos();
        return { ok: true, message: res.message || 'সফলভাবে সংরক্ষিত হয়েছে।' };
      } finally {
        setIsSubmittingGas(false);
      }
    },
    [
      googleAccessTokenState,
      googleSheetsConfig,
      requestSheetConfirm,
      dispatchRemoteWrite,
      syncExternalDos,
    ]
  );

  const godownList = useMemo(() => {
    const set = new Set<string>(customGodowns);
    transactions.forEach((tx) => {
      if (tx.godownNo.trim()) set.add(tx.godownNo.trim());
    });
    if (gasBridgeStatus === 'connected' && gasData) {
      (gasData.grainData || []).forEach((g) => {
        if (g.godown) set.add(String(g.godown));
      });
      (gasData.emptyBagData || []).forEach((e) => {
        if (e.godown) set.add(String(e.godown));
      });
    }
    return Array.from(set).sort((a, b) => a.localeCompare(b, 'bn'));
  }, [customGodowns, transactions, gasBridgeStatus, gasData]);

  // Aggregate Khamal stock positions by (godownNo + khamalNo + product)
  const khamalStocks = useMemo<KhamalStockItem[]>(() => {
    if (gasBridgeStatus === 'connected' && gasData) {
      const rows: KhamalStockItem[] = [];
      const masterByKhamal = new Map(
        (gasData.masterGrain || []).map((m) => [String(m.khamalId), m])
      );

      for (const g of gasData.grainData || []) {
        const prod = itemNameBnToProduct(g.item);
        const master = masterByKhamal.get(String(g.khamalId));
        const initBags = master ? Math.round(parseGasNumber(master.initBags)) : Math.round(parseGasNumber(g.recordBags));
        const initMt = master ? parseGasNumber(master.initWeight) : parseGasNumber(g.recordWeight);
        const curBags = Math.round(parseGasNumber(g.recordBags));
        const curMt = parseGasNumber(g.recordWeight);
        const shBags = Math.round(parseGasNumber(g.discrepancyBags));
        const shMt = parseGasNumber(g.discrepancyWeight);

        rows.push({
          key: `${g.godown}::${g.khamalId}::${prod}`,
          godownNo: String(g.godown || '০১'),
          khamalNo: String(g.khamalId),
          product: prod,
          receiptBags: initBags,
          receiptMt: Number(initMt.toFixed(4)),
          distBags: Math.max(0, initBags - curBags - shBags),
          distMt: Math.max(0, Number((initMt - curMt - shMt).toFixed(4))),
          shortageBags: shBags,
          shortageMt: Number(shMt.toFixed(4)),
          currentBags: curBags,
          currentMt: Number(curMt.toFixed(4)),
          channels: [g.category, g.remarks || ''].filter(Boolean),
          lastDate: master?.entryDate || todayIsoDate(),
          txCount: 1,
        });
      }

      for (const m of gasData.masterGrain || []) {
        const prod = itemNameBnToProduct(m.item);
        const already = rows.some(
          (r) => r.khamalNo === String(m.khamalId) && r.product === prod
        );
        if (already) continue;
        const initBags = Math.round(parseGasNumber(m.initBags));
        const initMt = parseGasNumber(m.initWeight);
        rows.push({
          key: `${m.godown}::${m.khamalId}::${prod}`,
          godownNo: String(m.godown || '০১'),
          khamalNo: String(m.khamalId),
          product: prod,
          receiptBags: initBags,
          receiptMt: Number(initMt.toFixed(4)),
          distBags: initBags,
          distMt: Number(initMt.toFixed(4)),
          shortageBags: 0,
          shortageMt: 0,
          currentBags: 0,
          currentMt: 0,
          channels: [m.category, m.remarks || ''].filter(Boolean),
          lastDate: m.entryDate || todayIsoDate(),
          txCount: 1,
        });
      }

      for (const eb of gasData.emptyBagData || []) {
        const prod = itemNameBnToProduct(eb.bagType);
        const curBags = Math.round(parseGasNumber(eb.recordBags));
        rows.push({
          key: `${eb.godown}::${eb.bagType}::${prod}`,
          godownNo: String(eb.godown || '০১'),
          khamalNo: String(eb.bagType),
          product: prod,
          receiptBags: curBags,
          receiptMt: 0,
          distBags: 0,
          distMt: 0,
          shortageBags: 0,
          shortageMt: 0,
          currentBags: curBags,
          currentMt: 0,
          channels: ['খালি বস্তা'],
          lastDate: todayIsoDate(),
          txCount: 1,
        });
      }

      return rows;
    }

    const map = new Map<string, KhamalStockItem>();
    const channelSets = new Map<string, Set<string>>();

    for (const tx of transactions) {
      const g = tx.godownNo.trim();
      const k = tx.khamalNo.trim();
      const key = `${g}::${k}::${tx.product}`;

      let item = map.get(key);
      if (!item) {
        item = {
          key,
          godownNo: g,
          khamalNo: k,
          product: tx.product,
          receiptBags: 0,
          receiptMt: 0,
          distBags: 0,
          distMt: 0,
          shortageBags: 0,
          shortageMt: 0,
          currentBags: 0,
          currentMt: 0,
          channels: [],
          lastDate: tx.date,
          txCount: 0,
        };
        map.set(key, item);
        channelSets.set(key, new Set());
      }

      if (tx.type === 'receipt') {
        item.receiptBags += tx.bags;
        item.receiptMt = Number((item.receiptMt + tx.metricTons).toFixed(4));
      } else if (tx.type === 'distribution') {
        item.distBags += tx.bags;
        item.distMt = Number((item.distMt + tx.metricTons).toFixed(4));
      } else if (tx.type === 'shortage') {
        item.shortageBags += tx.bags;
        item.shortageMt = Number((item.shortageMt + tx.metricTons).toFixed(4));
      }

      item.currentBags = item.receiptBags - item.distBags - item.shortageBags;
      item.currentMt = Number((item.receiptMt - item.distMt - item.shortageMt).toFixed(4));
      if (tx.date > item.lastDate) item.lastDate = tx.date;
      item.txCount += 1;
      if (tx.channel.trim()) {
        channelSets.get(key)?.add(tx.channel.trim());
      }
    }

    return Array.from(map.values())
      .map((item) => ({
        ...item,
        channels: Array.from(channelSets.get(item.key) || []),
      }))
      .sort((a, b) => {
        const gCmp = a.godownNo.localeCompare(b.godownNo, 'bn');
        if (gCmp !== 0) return gCmp;
        return a.khamalNo.localeCompare(b.khamalNo, 'bn');
      });
  }, [transactions, gasBridgeStatus, gasData]);

  const productTotals = useMemo(() => {
    const makeEmpty = () => ({
      currentBags: 0,
      currentMt: 0,
      receiptBags: 0,
      receiptMt: 0,
      distBags: 0,
      distMt: 0,
      shortageBags: 0,
      shortageMt: 0,
      activeKhamals: 0,
    });
    const summary: Record<ProductCategory, ReturnType<typeof makeEmpty>> = {
      paddy: makeEmpty(),
      rice: makeEmpty(),
      wheat: makeEmpty(),
      bosta_50: makeEmpty(),
      bosta_30: makeEmpty(),
    };

    if (gasBridgeStatus === 'connected' && gasData?.dashboard?.itemSummary) {
      const itemSum = gasData.dashboard.itemSummary;
      const mapItem = (bnKey: string, prod: ProductCategory) => {
        const o = itemSum[bnKey];
        if (!o) return;
        const initB = Math.round(parseGasNumber(o.initBags));
        const initW = parseGasNumber(o.initWeight);
        const issB = Math.round(parseGasNumber(o.issuedBags));
        const issW = parseGasNumber(o.issuedWeight);
        const discB = Math.round(parseGasNumber(o.discBags));
        const discW = parseGasNumber(o.discWeight);
        summary[prod].receiptBags = initB;
        summary[prod].receiptMt = Number(initW.toFixed(4));
        summary[prod].distBags = issB;
        summary[prod].distMt = Number(issW.toFixed(4));
        summary[prod].shortageBags = discB;
        summary[prod].shortageMt = Number(discW.toFixed(4));
        summary[prod].currentBags = initB - issB - discB;
        summary[prod].currentMt = Number((initW - issW - discW).toFixed(4));
      };
      mapItem('ধান', 'paddy');
      mapItem('চাল', 'rice');
      mapItem('গম', 'wheat');

      for (const k of khamalStocks) {
        if (k.currentBags > 0 || k.currentMt > 0) {
          summary[k.product].activeKhamals += 1;
        }
        if (k.product === 'bosta_50' || k.product === 'bosta_30') {
          summary[k.product].currentBags += k.currentBags;
          summary[k.product].receiptBags += k.receiptBags;
        }
      }
      return summary;
    }

    for (const k of khamalStocks) {
      const s = summary[k.product];
      s.receiptBags += k.receiptBags;
      s.receiptMt = Number((s.receiptMt + k.receiptMt).toFixed(4));
      s.distBags += k.distBags;
      s.distMt = Number((s.distMt + k.distMt).toFixed(4));
      s.shortageBags += k.shortageBags;
      s.shortageMt = Number((s.shortageMt + k.shortageMt).toFixed(4));
      s.currentBags += k.currentBags;
      s.currentMt = Number((s.currentMt + k.currentMt).toFixed(4));
      if (k.currentBags > 0 || k.currentMt > 0) {
        s.activeKhamals += 1;
      }
    }

    return summary;
  }, [khamalStocks, gasBridgeStatus, gasData]);

  const getKhamalBalance = useCallback(
    (godownNo: string, khamalNo: string, product: ProductCategory) => {
      const key = `${godownNo.trim()}::${khamalNo.trim()}::${product}`;
      const match = khamalStocks.find((k) => k.key === key);
      return {
        bags: match?.currentBags ?? 0,
        metricTons: match?.currentMt ?? 0,
        exists: Boolean(match),
      };
    },
    [khamalStocks]
  );

  // Batch Receipt (or simple direct batch distribution)
  const addBatchTransactions = useCallback(
    (payload: BatchInputPayload): { ok: boolean; error?: string; count?: number } => {
      const godown = payload.godownNo.trim();
      const channel = payload.channel.trim();
      if (!godown) {
        return { ok: false, error: 'অনুগ্রহ করে গুদাম নং লিখুন।' };
      }
      if (!channel) {
        return { ok: false, error: 'অনুগ্রহ করে চ্যানেল/খাত নির্বাচন করুন।' };
      }
      if (payload.items.length === 0) {
        return { ok: false, error: 'কমপক্ষে একটি খামাল এন্ট্রি যোগ করুন।' };
      }

      const seenCheck = new Map<string, { bags: number; mt: number }>();
      for (let i = 0; i < payload.items.length; i++) {
        const row = payload.items[i];
        const khamal = row.khamalNo.trim();
        if (!khamal) {
          return { ok: false, error: `সারি #${i + 1}-এ খামাল নং খালি আছে।` };
        }
        if (row.bags <= 0 && row.metricTons <= 0) {
          return { ok: false, error: `${khamal}-এর বস্তা বা মেট্রিক টন ০-এর বেশি হতে হবে।` };
        }

        if (payload.type === 'distribution') {
          const prevAdded = seenCheck.get(khamal) || { bags: 0, mt: 0 };
          const avail = getKhamalBalance(godown, khamal, payload.product);
          const totalDistBags = prevAdded.bags + row.bags;
          const totalDistMt = Number((prevAdded.mt + row.metricTons).toFixed(4));
          const tracksW = PRODUCT_MAP[payload.product].tracksWeight;

          if (
            tracksW
              ? totalDistMt > avail.metricTons + 0.0005
              : totalDistBags > avail.bags + 0.0001
          ) {
            return {
              ok: false,
              error: `${godown} / ${khamal}-এ পর্যাপ্ত মজুদ নেই (বর্তমান মজুদ: ${avail.metricTons.toFixed(3)} মে.টন, ${avail.bags} বস্তা)।`,
            };
          }
          seenCheck.set(khamal, { bags: totalDistBags, mt: totalDistMt });
        }
      }

      const batchId = `batch-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      const nowIso = new Date().toISOString();

      const created: GrainTransaction[] = payload.items.map((item, idx) => ({
        id: `tx-${Date.now()}-${idx}-${Math.random().toString(36).slice(2, 6)}`,
        batchId,
        type: payload.type,
        product: payload.product,
        godownNo: godown,
        khamalNo: item.khamalNo.trim(),
        bags: Math.round(item.bags),
        metricTons: Number(item.metricTons.toFixed(4)),
        channel,
        referenceNo: payload.referenceNo.trim(),
        date: payload.date || todayIsoDate(),
        note: payload.note.trim(),
        createdAt: nowIso,
      }));

      setTransactions((prev) => [...created, ...prev]);
      setCustomGodowns((prev) => (prev.includes(godown) ? prev : [...prev, godown]));

      return { ok: true, count: created.length };
    },
    [getKhamalBalance]
  );

  // Add or update a DO entry
  const addDeliveryOrder = useCallback(
    (input: {
      doNumber: string;
      product: ProductCategory;
      category: string;
      totalBags: number;
      totalMt: number;
      recipient: string;
      date: string;
    }): { ok: boolean; error?: string; order?: DeliveryOrder } => {
      const doNum = input.doNumber.trim();
      if (!doNum) {
        return { ok: false, error: 'অনুগ্রহ করে ডিও নম্বর লিখুন।' };
      }
      if (!input.category.trim()) {
        return { ok: false, error: 'বিতরণের ক্যাটাগরি নির্বাচন করুন।' };
      }
      if (input.totalBags <= 0 && input.totalMt <= 0) {
        return { ok: false, error: 'ডিও-র পরিমাণ (বস্তা বা মে.টন) ০-এর বেশি হতে হবে।' };
      }

      const newOrder: DeliveryOrder = {
        id: `do-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        doNumber: doNum,
        product: input.product,
        category: input.category.trim(),
        totalBags: Math.round(input.totalBags),
        totalMt: Number(input.totalMt.toFixed(4)),
        deliveredBags: 0,
        deliveredMt: 0,
        recipient: input.recipient.trim(),
        date: input.date || todayIsoDate(),
        source: 'manual',
        status: 'pending',
        createdAt: new Date().toISOString(),
      };

      setDeliveryOrders((prev) => [newOrder, ...prev]);
      return { ok: true, order: newOrder };
    },
    []
  );

  const deleteDeliveryOrder = useCallback((id: string) => {
    setDeliveryOrders((prev) => prev.filter((d) => d.id !== id));
  }, []);

  const markDoAsDistributed = useCallback(
    (id: string) => {
      const nowIso = new Date().toISOString();
      let targetOrder: DeliveryOrder | undefined;
      setDeliveryOrders((prev) =>
        prev.map((d) => {
          if (d.id !== id) return d;
          targetOrder = {
            ...d,
            deliveredBags: d.totalBags,
            deliveredMt: d.totalMt,
            status: 'distributed',
            distributedAt: d.distributedAt || nowIso,
          };
          return targetOrder;
        })
      );

      if (targetOrder) {
        const order = targetOrder as DeliveryOrder;
        if (window.location.hostname !== 'appassets.androidplatform.net') {
          void fetch('/api/external-dos/mark-distributed', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              items: [
                {
                  id: order.id,
                  externalId: order.externalId,
                  doNumber: order.doNumber,
                  product: order.product,
                  deliveredBags: order.totalBags,
                  deliveredMt: order.totalMt,
                  distributedAt: nowIso,
                },
              ],
            }),
          }).catch(() => {});
        }
      }
    },
    []
  );

  // Execute Multi-DO Distribution across 1 or more Khamals WITH Khamal Shortage deduction!
  const executeDoDistribution = useCallback(
    (
      payload: DoDistributionPayload
    ): { ok: boolean; error?: string; khamalCount?: number; doCount?: number } => {
      if (!payload.doItems || payload.doItems.length === 0) {
        return { ok: false, error: 'কমপক্ষে একটি ডিও নম্বর নির্বাচন করুন বা লিখুন।' };
      }
      for (const item of payload.doItems) {
        if (!item.doNumber.trim()) {
          return { ok: false, error: 'ডিও নম্বর খালি রাখা যাবে না।' };
        }
        if (!item.category.trim()) {
          return { ok: false, error: `${item.doNumber}-এর বিতরণের ক্যাটাগরি নির্বাচন করুন।` };
        }
      }
      if (payload.allocations.length === 0) {
        return { ok: false, error: 'কমপক্ষে একটি খামাল নির্বাচন করুন।' };
      }

      // Validate each khamal allocation strictly by MT for grain products (bags for bag-only products)
      const tracksWeightProduct = PRODUCT_MAP[payload.product].tracksWeight;
      const perKhamalUsed = new Map<string, { bags: number; mt: number }>();
      for (const alloc of payload.allocations) {
        const key = `${alloc.godownNo.trim()}::${alloc.khamalNo.trim()}`;
        const prevUsed = perKhamalUsed.get(key) || { bags: 0, mt: 0 };
        const avail = getKhamalBalance(alloc.godownNo, alloc.khamalNo, payload.product);

        const rowOutBags = alloc.deliveredBags + alloc.shortageBags;
        const rowOutMt = Number((alloc.deliveredMt + alloc.shortageMt).toFixed(4));

        if (tracksWeightProduct ? rowOutMt <= 0 : rowOutBags <= 0) {
          return {
            ok: false,
            error: `${alloc.khamalNo}-এ ডেলিভারি বা শর্টেজ পরিমাণ ০-এর বেশি হতে হবে।`,
          };
        }

        if (
          tracksWeightProduct
            ? prevUsed.mt + rowOutMt > avail.metricTons + 0.0005
            : prevUsed.bags + rowOutBags > avail.bags + 0.0001
        ) {
          return {
            ok: false,
            error: `${alloc.godownNo} / ${alloc.khamalNo}-এ বর্তমান মজুদ ${avail.metricTons.toFixed(3)} মে.টন (${avail.bags} বস্তা) — ডেলিভারি + শর্টেজ এর চেয়ে বেশি হতে পারবে না।`,
          };
        }

        perKhamalUsed.set(key, {
          bags: prevUsed.bags + rowOutBags,
          mt: Number((prevUsed.mt + rowOutMt).toFixed(4)),
        });
      }

      const batchId = `do-batch-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      const nowIso = new Date().toISOString();
      const txDate = payload.date || todayIsoDate();
      const createdTxs: GrainTransaction[] = [];
      const tracksWeight = PRODUCT_MAP[payload.product].tracksWeight;

      // Pool remaining quantities from each selected khamal to distribute sequentially across selected DOs
      const pools = payload.allocations.map((a) => ({
        godownNo: a.godownNo.trim(),
        khamalNo: a.khamalNo.trim(),
        remBags: Math.round(a.deliveredBags),
        remMt: Number(a.deliveredMt.toFixed(4)),
      }));

      const perDoStats = payload.doItems.map(() => ({
        bags: 0,
        mt: 0,
        khamals: new Set<string>(),
      }));

      payload.doItems.forEach((doItem, doIdx) => {
        const isLastDo = doIdx === payload.doItems.length - 1;
        let needMt = isLastDo
          ? Number.POSITIVE_INFINITY
          : doItem.targetMt > 0
            ? doItem.targetMt
            : Number.POSITIVE_INFINITY;
        let needBags = isLastDo
          ? Number.POSITIVE_INFINITY
          : doItem.targetBags > 0
            ? doItem.targetBags
            : Number.POSITIVE_INFINITY;

        const cleanDoNum = doItem.doNumber.trim();
        const cleanCat = doItem.category.trim();

        pools.forEach((pool, pIdx) => {
          if (pool.remMt <= 0.0001 && pool.remBags <= 0) return;
          if (tracksWeight && needMt <= 0.0001 && !isLastDo) return;
          if (!tracksWeight && needBags <= 0 && !isLastDo) return;

          const takeMt = tracksWeight
            ? isLastDo
              ? pool.remMt
              : Number(Math.min(pool.remMt, needMt).toFixed(4))
            : 0;

          let takeBags = 0;
          if (isLastDo) {
            takeBags = pool.remBags;
          } else if (tracksWeight && pool.remMt > 0) {
            if (needBags !== Number.POSITIVE_INFINITY) {
              takeBags = Math.min(pool.remBags, Math.round(needBags));
            } else {
              takeBags = Math.min(
                pool.remBags,
                Math.round((takeMt / pool.remMt) * pool.remBags)
              );
            }
          } else {
            takeBags = Math.min(pool.remBags, needBags);
          }

          if (takeBags <= 0 && takeMt <= 0.0001) return;

          pool.remMt = Math.max(0, Number((pool.remMt - takeMt).toFixed(4)));
          pool.remBags = Math.max(0, pool.remBags - takeBags);
          if (!isLastDo) {
            needMt = Math.max(0, Number((needMt - takeMt).toFixed(4)));
            needBags = Math.max(0, needBags - takeBags);
          }

          perDoStats[doIdx].bags += takeBags;
          perDoStats[doIdx].mt = Number((perDoStats[doIdx].mt + takeMt).toFixed(4));
          perDoStats[doIdx].khamals.add(`${pool.godownNo} / ${pool.khamalNo}`);

          createdTxs.push({
            id: `tx-dist-${Date.now()}-${doIdx}-${pIdx}-${Math.random().toString(36).slice(2, 5)}`,
            batchId,
            type: 'distribution',
            product: payload.product,
            godownNo: pool.godownNo,
            khamalNo: pool.khamalNo,
            bags: takeBags,
            metricTons: takeMt,
            channel: cleanCat,
            doNumber: cleanDoNum,
            referenceNo: cleanDoNum,
            date: txDate,
            note:
              payload.note.trim() ||
              (doItem.recipient ? `প্রাপক: ${doItem.recipient}` : ''),
            createdAt: nowIso,
          });
        });
      });

      // Record khamal shortages once per khamal
      const joinedDoNums = payload.doItems.map((d) => d.doNumber.trim()).join(', ');
      const primaryCategory = payload.doItems[0].category.trim();
      payload.allocations.forEach((alloc, idx) => {
        if (alloc.shortageBags > 0 || alloc.shortageMt > 0) {
          createdTxs.push({
            id: `tx-short-${Date.now()}-${idx}-${Math.random().toString(36).slice(2, 5)}`,
            batchId,
            type: 'shortage',
            product: payload.product,
            godownNo: alloc.godownNo.trim(),
            khamalNo: alloc.khamalNo.trim(),
            bags: Math.round(alloc.shortageBags),
            metricTons: Number(alloc.shortageMt.toFixed(4)),
            channel: `খামাল শর্টেজ (${primaryCategory})`,
            doNumber: joinedDoNums,
            referenceNo: joinedDoNums,
            date: txDate,
            note: `ডিও নং ${joinedDoNums} বিতরণের সময় খামাল শর্টেজ কর্তন`,
            createdAt: nowIso,
          });
        }
      });

      setTransactions((prev) => [...createdTxs, ...prev]);

      // Update existing DO records and create new ones for ad-hoc entries
      const distributedForRemoteSync: Array<{
        id?: string;
        externalId?: string;
        doNumber: string;
        product: ProductCategory;
        deliveredBags: number;
        deliveredMt: number;
        distributedAt: string;
        distributedFrom: string[];
      }> = [];

      setDeliveryOrders((prev) => {
        let next = [...prev];

        payload.doItems.forEach((doItem, idx) => {
          const stat = perDoStats[idx];
          const khamalNames = Array.from(stat.khamals);

          if (doItem.doId) {
            next = next.map((d) => {
              if (d.id !== doItem.doId) return d;
              const newDelBags = d.deliveredBags + stat.bags;
              const newDelMt = Number((d.deliveredMt + stat.mt).toFixed(4));
              const fulfilled =
                Boolean(payload.markCompleted) ||
                (tracksWeight && d.totalMt > 0
                  ? newDelMt >= d.totalMt - 0.0001
                  : newDelBags >= d.totalBags);
              const mergedKhamals = Array.from(
                new Set([...(d.distributedFrom || []), ...khamalNames])
              );

              const updatedOrder: DeliveryOrder = {
                ...d,
                deliveredBags: newDelBags,
                deliveredMt: newDelMt,
                status: fulfilled ? 'distributed' : 'pending',
                distributedAt: fulfilled ? nowIso : d.distributedAt,
                distributedFrom: mergedKhamals,
              };

              if (fulfilled) {
                distributedForRemoteSync.push({
                  id: updatedOrder.id,
                  externalId: updatedOrder.externalId,
                  doNumber: updatedOrder.doNumber,
                  product: updatedOrder.product,
                  deliveredBags: updatedOrder.deliveredBags,
                  deliveredMt: updatedOrder.deliveredMt,
                  distributedAt: nowIso,
                  distributedFrom: mergedKhamals,
                });
              }

              return updatedOrder;
            });
          } else {
            const totalB = Math.round(doItem.targetBags || stat.bags);
            const totalM = Number((doItem.targetMt || stat.mt).toFixed(4));
            const fulfilled =
              Boolean(payload.markCompleted) ||
              (tracksWeight && totalM > 0
                ? stat.mt >= totalM - 0.0001
                : stat.bags >= totalB);
            const newDo: DeliveryOrder = {
              id: `do-${Date.now()}-${idx}`,
              doNumber: doItem.doNumber.trim(),
              product: payload.product,
              category: doItem.category.trim(),
              totalBags: totalB,
              totalMt: totalM,
              deliveredBags: stat.bags,
              deliveredMt: stat.mt,
              recipient: doItem.recipient.trim(),
              date: txDate,
              source: 'manual',
              status: fulfilled ? 'distributed' : 'pending',
              distributedAt: fulfilled ? nowIso : undefined,
              distributedFrom: khamalNames,
              createdAt: nowIso,
            };
            next = [newDo, ...next];
          }
        });

        return next;
      });

      // Notify server & external web app in background so distributed DOs stay out of pending
      if (
        distributedForRemoteSync.length > 0 &&
        typeof window !== 'undefined' &&
        window.location.hostname !== 'appassets.androidplatform.net'
      ) {
        void fetch('/api/external-dos/mark-distributed', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ items: distributedForRemoteSync }),
        }).catch(() => {});

        if (
          externalSyncConfig.enabled &&
          externalSyncConfig.pushDistributedStatus &&
          externalSyncConfig.externalAppUrl.trim()
        ) {
          void fetch('/api/external-sync/push-status', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              url: externalSyncConfig.externalAppUrl.trim(),
              apiSecret: externalSyncConfig.apiSecret || '',
              distributedDos: distributedForRemoteSync,
            }),
          }).catch(() => {});
        }
      }

      return {
        ok: true,
        khamalCount: payload.allocations.length,
        doCount: payload.doItems.length,
      };
    },
    [getKhamalBalance, externalSyncConfig]
  );

  const deleteTransaction = useCallback((id: string) => {
    setTransactions((prev) => prev.filter((tx) => tx.id !== id));
  }, []);

  const addChannel = useCallback(
    (product: ProductCategory, mode: ChannelMode, name: string): boolean => {
      const clean = name.trim();
      if (!clean) return false;
      setChannels((prev) => {
        const list = prev[product][mode];
        if (list.includes(clean)) return prev;
        return {
          ...prev,
          [product]: {
            ...prev[product],
            [mode]: [...list, clean],
          },
        };
      });
      return true;
    },
    []
  );

  const renameChannel = useCallback(
    (product: ProductCategory, mode: ChannelMode, oldName: string, newName: string) => {
      const clean = newName.trim();
      if (!clean) return;
      setChannels((prev) => ({
        ...prev,
        [product]: {
          ...prev[product],
          [mode]: prev[product][mode].map((c) => (c === oldName ? clean : c)),
        },
      }));
    },
    []
  );

  const removeChannel = useCallback(
    (product: ProductCategory, mode: ChannelMode, name: string) => {
      setChannels((prev) => ({
        ...prev,
        [product]: {
          ...prev[product],
          [mode]: prev[product][mode].filter((c) => c !== name),
        },
      }));
    },
    []
  );

  const resetDefaultChannels = useCallback(() => {
    setChannels(DEFAULT_CHANNELS);
  }, []);

  const loadSampleData = useCallback(() => {
    setTransactions(createStarterTransactions());
    setDeliveryOrders(createStarterDeliveryOrders());
    localStorage.setItem(STORAGE_KEY_INIT, '1');
    localStorage.setItem(STORAGE_KEY_SAMPLE_SEED, '1');
  }, []);

  const clearAllData = useCallback(() => {
    setTransactions([]);
    setDeliveryOrders([]);
    setGasData(null);
    setGasBridgeStatus('idle');
    setGasBridgeMessage('');
    setDataSourceMode('local');
    try {
      localStorage.removeItem(STORAGE_KEY_GAS_CACHE);
      localStorage.removeItem(STORAGE_KEY_DATA_SOURCE);
      localStorage.removeItem(STORAGE_KEY_SELECTED_FY);
      localStorage.removeItem(STORAGE_KEY_MAIN_TABS);
    } catch {
      // Ignore storage removal errors
    }
    localStorage.setItem(STORAGE_KEY_INIT, '1');
    localStorage.setItem(STORAGE_KEY_SAMPLE_SEED, '1');
  }, []);

  const updateFortnightlySettings = useCallback(
    (patch: Partial<FortnightlyReportSettings>) => {
      setFortnightlySettings((prev) => ({ ...prev, ...patch }));
    },
    []
  );

  const resetFortnightlySettings = useCallback(() => {
    setFortnightlySettings(DEFAULT_FORTNIGHTLY_REPORT_SETTINGS);
  }, []);

  const exportBackupJson = useCallback(() => {
    const payload = {
      app: 'KhaddoStock',
      version: 2,
      exportedAt: new Date().toISOString(),
      channels,
      customGodowns,
      deliveryOrders,
      transactions,
      fortnightlySettings,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `khaddo-stock-backup-${todayIsoDate()}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }, [channels, customGodowns, deliveryOrders, transactions, fortnightlySettings]);

  const importBackupJson = useCallback((jsonText: string): { ok: boolean; error?: string } => {
    try {
      const parsed = JSON.parse(jsonText);
      if (!parsed || !Array.isArray(parsed.transactions)) {
        return { ok: false, error: 'সঠিক ব্যাকআপ JSON ফাইল নয়।' };
      }
      setTransactions(
        parsed.transactions.map((t: Record<string, unknown>) => ({
          ...(t as unknown as GrainTransaction),
          product: normalizeProduct(String(t.product || 'paddy')),
        }))
      );
      if (parsed.channels) setChannels((prev) => ({ ...prev, ...parsed.channels }));
      if (Array.isArray(parsed.customGodowns)) setCustomGodowns(parsed.customGodowns);
      if (Array.isArray(parsed.deliveryOrders)) setDeliveryOrders(parsed.deliveryOrders);
      if (parsed.fortnightlySettings && typeof parsed.fortnightlySettings === 'object') {
        setFortnightlySettings({
          ...DEFAULT_FORTNIGHTLY_REPORT_SETTINGS,
          ...parsed.fortnightlySettings,
        });
      }
      localStorage.setItem(STORAGE_KEY_INIT, '1');
      return { ok: true };
    } catch {
      return { ok: false, error: 'ফাইলটি পড়া যায়নি। সঠিক JSON ফাইল নির্বাচন করুন।' };
    }
  }, []);

  const exportCsvReport = useCallback((rows: GrainTransaction[]) => {
    const productNames = Object.fromEntries(PRODUCTS.map((p) => [p.id, p.nameBn]));
    const typeLabel = (t: GrainTransaction['type']) =>
      t === 'receipt' ? 'প্রাপ্তি' : t === 'distribution' ? 'বিতরণ' : 'খামাল শর্টেজ';
    const headers = [
      'তারিখ',
      'ধরন',
      'পণ্য',
      'গুদাম নং',
      'খামাল নং',
      'চ্যানেল / খাত',
      'ডিও নম্বর',
      'পরিমাণ (বস্তা)',
      'পরিমাণ (মেট্রিক টন)',
      'রেফারেন্স নং',
      'মন্তব্য',
    ];
    const escapeCsv = (val: string | number | undefined) => {
      const str = String(val ?? '');
      if (/[",\n]/.test(str)) {
        return `"${str.replace(/"/g, '""')}"`;
      }
      return str;
    };
    const lines = [
      headers.map(escapeCsv).join(','),
      ...rows.map((tx) =>
        [
          tx.date,
          typeLabel(tx.type),
          productNames[tx.product] || tx.product,
          tx.godownNo,
          tx.khamalNo,
          tx.channel,
          tx.doNumber || '',
          tx.bags,
          tx.metricTons.toFixed(3),
          tx.referenceNo,
          tx.note,
        ]
          .map(escapeCsv)
          .join(',')
      ),
    ];
    const bom = '\uFEFF';
    const blob = new Blob([bom + lines.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `food-grain-ledger-${todayIsoDate()}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }, []);

  // Direct Google Sheets / Apps Script write-through helpers
  const submitGasReceiptBatch = useCallback(
    async (
      payload: BatchInputPayload & { uniqueId?: string }
    ): Promise<{ ok: boolean; count?: number; message?: string; error?: string }> => {
      if (gasBridgeStatus !== 'connected') {
        return addBatchTransactions(payload);
      }

      const isBag = payload.product === 'bosta_50' || payload.product === 'bosta_30';
      const token = googleAccessTokenState || getGoogleAccessToken();
      const usingDirectSheets = Boolean(
        googleSheetsConfig.enabled && token && extractSpreadsheetId(googleSheetsConfig.mainSpreadsheetId)
      );

      if (usingDirectSheets) {
        const pName = PRODUCT_MAP[payload.product].nameBn;
        const accepted = await requestSheetConfirm({
          title: `Google Sheet-এ ${pName} প্রাপ্তি সংরক্ষণ নিশ্চিত করুন`,
          description: `আপনার Google Sheet-এ ${payload.items.length}টি নতুন ${
            isBag ? 'খালি বস্তা' : 'খামাল'
          } সারি যুক্ত করা হবে।`,
          spreadsheetName: googleSheetsConfig.mainSpreadsheetName || 'Google Spreadsheet',
          targetSheets: [isBag ? 'Empty_Bags' : 'Khamal_Master'],
          details: payload.items.slice(0, 6).map((row) =>
            isBag
              ? `গুদাম ${payload.godownNo} · ${row.khamalNo}: ${row.bags} বস্তা`
              : `গুদাম ${payload.godownNo} · খামাল ${row.khamalNo}: ${row.bags} বস্তা / ${Number(row.metricTons).toFixed(3)} মে.টন`
          ),
        });
        if (!accepted) return { ok: false, error: 'ব্যবহারকারী বাতিল করেছেন।' };
      }

      setIsSubmittingGas(true);
      try {
        let lastMsg = '';
        for (let i = 0; i < payload.items.length; i++) {
          const row = payload.items[i];
          if (isBag) {
            const res = await dispatchRemoteWrite('addEmptyBagMaster', {
              godown: payload.godownNo.trim(),
              bagType: productToItemNameBn(payload.product),
              bags: Math.round(row.bags),
              khamalNo: row.khamalNo.trim(),
              entryDate: payload.date || todayIsoDate(),
            });
            if (!res.ok) return { ok: false, error: res.error };
            lastMsg = res.message || lastMsg;
          } else {
            const res = await dispatchRemoteWrite('addMasterKhamal', {
              khamalId: row.khamalNo.trim(),
              uniqueId: payload.uniqueId || '',
              godown: payload.godownNo.trim(),
              category: payload.channel.trim(),
              item: productToItemNameBn(payload.product),
              bags: Math.round(row.bags),
              weight: Number(row.metricTons.toFixed(3)),
              entryDate: payload.date || todayIsoDate(),
              remarks: payload.note.trim() || payload.channel.trim(),
              sourceType: payload.channel.trim(),
            });
            if (!res.ok) return { ok: false, error: res.error };
            lastMsg = res.message || lastMsg;
          }
        }
        await syncExternalDos();
        return { ok: true, count: payload.items.length, message: lastMsg || 'খামাল যুক্ত হয়েছে।' };
      } finally {
        setIsSubmittingGas(false);
      }
    },
    [
      gasBridgeStatus,
      addBatchTransactions,
      googleAccessTokenState,
      googleSheetsConfig,
      requestSheetConfirm,
      dispatchRemoteWrite,
      syncExternalDos,
    ]
  );

  const executeDoDistributionAsync = useCallback(
    async (
      payload: DoDistributionPayload
    ): Promise<{ ok: boolean; error?: string; khamalCount?: number; doCount?: number; message?: string }> => {
      if (gasBridgeStatus !== 'connected') {
        return executeDoDistribution(payload);
      }
      if (!payload.doItems?.length) {
        return { ok: false, error: 'কমপক্ষে একটি ডিও সিলেক্ট করুন।' };
      }
      if (!payload.allocations?.length) {
        return { ok: false, error: 'কমপক্ষে একটি খামাল নির্বাচন করুন।' };
      }

      const token = googleAccessTokenState || getGoogleAccessToken();
      const usingDirectSheets = Boolean(
        googleSheetsConfig.enabled && token && extractSpreadsheetId(googleSheetsConfig.mainSpreadsheetId)
      );

      if (usingDirectSheets) {
        const totalOutMt = payload.allocations.reduce((s, a) => s + a.deliveredMt, 0);
        const totalOutBags = payload.allocations.reduce((s, a) => s + a.deliveredBags, 0);
        const totalShortMt = payload.allocations.reduce((s, a) => s + a.shortageMt, 0);
        const accepted = await requestSheetConfirm({
          title: 'Google Sheet-এ ডিও বিতরণ সংরক্ষণ নিশ্চিত করুন',
          description: `${payload.doItems.length}টি ডিও-এর বিপরীতে ${payload.allocations.length}টি খামাল থেকে বিতরণ ও শর্টেজ Google Sheet-এ লেখা হবে।`,
          spreadsheetName: googleSheetsConfig.mainSpreadsheetName || 'Google Spreadsheet',
          targetSheets: ['Transactions'],
          details: [
            `ডিও নম্বর: ${payload.doItems.map((d) => d.doNumber).join(', ')}`,
            `মোট বিতরণ: ${totalOutMt.toFixed(3)} মে.টন (${totalOutBags} বস্তা)`,
            ...(totalShortMt > 0 ? [`মোট শর্টেজ কর্তন: ${totalShortMt.toFixed(3)} মে.টন`] : []),
            `তারিখ: ${payload.date || todayIsoDate()}`,
          ],
        });
        if (!accepted) return { ok: false, error: 'ব্যবহারকারী বাতিল করেছেন।' };
      }

      setIsSubmittingGas(true);
      try {
        // Split selected DOs sequentially across the selected khamals and call addTransactionsBatch per khamal
        const pools = payload.allocations.map((a) => ({
          khamalId: a.khamalNo.trim(),
          godownNo: a.godownNo.trim(),
          remMt: Number(a.deliveredMt.toFixed(4)),
          remBags: Math.round(a.deliveredBags),
          shortageBags: Math.round(a.shortageBags),
          shortageMt: Number(a.shortageMt.toFixed(4)),
          items: [] as Array<{ doNo: string; khath: string; bags: number; weight: number }>,
        }));

        payload.doItems.forEach((doItem, doIdx) => {
          const isLastDo = doIdx === payload.doItems.length - 1;
          let needMt = isLastDo
            ? Number.POSITIVE_INFINITY
            : doItem.targetMt > 0
              ? doItem.targetMt
              : Number.POSITIVE_INFINITY;
          let needBags = isLastDo
            ? Number.POSITIVE_INFINITY
            : doItem.targetBags > 0
              ? doItem.targetBags
              : Number.POSITIVE_INFINITY;

          for (const pool of pools) {
            if (pool.remMt <= 0.0001 && pool.remBags <= 0) continue;
            if (!isLastDo && needMt <= 0.0001) break;

            const takeMt = isLastDo
              ? pool.remMt
              : Number(Math.min(pool.remMt, needMt).toFixed(3));
            let takeBags = 0;
            if (isLastDo) {
              takeBags = pool.remBags;
            } else if (pool.remMt > 0) {
              takeBags =
                needBags !== Number.POSITIVE_INFINITY
                  ? Math.min(pool.remBags, Math.round(needBags))
                  : Math.min(pool.remBags, Math.round((takeMt / pool.remMt) * pool.remBags));
            }
            if (takeMt <= 0.0001 && takeBags <= 0) continue;

            pool.remMt = Math.max(0, Number((pool.remMt - takeMt).toFixed(4)));
            pool.remBags = Math.max(0, pool.remBags - takeBags);
            if (!isLastDo) {
              needMt = Math.max(0, Number((needMt - takeMt).toFixed(4)));
              needBags = Math.max(0, needBags - takeBags);
            }

            pool.items.push({
              doNo: doItem.doNumber.trim(),
              khath: doItem.category.trim(),
              bags: takeBags,
              weight: Number(takeMt.toFixed(3)),
            });
          }
        });

        let lastMsg = '';
        const refText = payload.note.trim();
        const txDate = payload.date || todayIsoDate();

        for (const pool of pools) {
          if (pool.items.length > 0) {
            const res = await dispatchRemoteWrite('addTransactionsBatch', {
              khamalId: pool.khamalId,
              issueDate: txDate,
              reference: refText,
              items: pool.items,
            });
            if (!res.ok) return { ok: false, error: res.error };
            lastMsg = res.message || lastMsg;
          }

          if (pool.shortageMt > 0 || pool.shortageBags > 0) {
            const discRes = await dispatchRemoteWrite('addDiscrepancy', {
              khamalId: pool.khamalId,
              bags: pool.shortageBags,
              weight: Number(pool.shortageMt.toFixed(3)),
              discDate: txDate,
              remarks: `ডিও বিতরণ (${payload.doItems.map((d) => d.doNumber).join(', ')}) সময় ঘাটতি`,
            });
            if (!discRes.ok) return { ok: false, error: discRes.error };
          }
        }

        await syncExternalDos();
        return {
          ok: true,
          khamalCount: payload.allocations.length,
          doCount: payload.doItems.length,
          message: lastMsg || 'বিতরণ সংরক্ষিত হয়েছে।',
        };
      } finally {
        setIsSubmittingGas(false);
      }
    },
    [
      gasBridgeStatus,
      executeDoDistribution,
      googleAccessTokenState,
      googleSheetsConfig,
      requestSheetConfirm,
      dispatchRemoteWrite,
      syncExternalDos,
    ]
  );

  const submitGasDispatch = useCallback(
    async (input: {
      type: 'Invoice' | 'Mill';
      khamalId: string;
      docNo: string;
      party: string;
      bags: number;
      weight: number;
      issueDate: string;
      reference: string;
      allocations?: Array<{ godownNo?: string; khamalId: string; bags: number; weight: number }>;
    }): Promise<{ ok: boolean; message?: string; error?: string }> => {
      const splits =
        input.allocations && input.allocations.length > 0
          ? input.allocations.filter((a) => a.bags > 0 || a.weight > 0)
          : [{ khamalId: input.khamalId, bags: input.bags, weight: input.weight }];

      if (splits.length === 0) {
        return { ok: false, error: 'কমপক্ষে একটি খামাল থেকে পরিমাণ নির্ধারণ করুন।' };
      }

      if (gasBridgeStatus !== 'connected') {
        const nowIso = new Date().toISOString();
        const txDate = input.issueDate || todayIsoDate();
        const batchId = `disp-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
        const created: GrainTransaction[] = [];

        for (const sp of splits) {
          const matchK = khamalStocks.find(
            (k) =>
              k.khamalNo === sp.khamalId &&
              (!sp.godownNo || k.godownNo === sp.godownNo) &&
              !PRODUCT_MAP[k.product].isBagProduct
          );
          if (!matchK) {
            return { ok: false, error: `খামাল ${sp.khamalId} খুঁজে পাওয়া যায়নি।` };
          }
          if (sp.weight > matchK.currentMt + 0.0005) {
            return {
              ok: false,
              error: `${matchK.godownNo} / ${matchK.khamalNo}-এ পর্যাপ্ত মজুদ নেই (বর্তমান: ${matchK.currentMt.toFixed(3)} মে.টন, ${matchK.currentBags} বস্তা)।`,
            };
          }

          created.push({
            id: `tx-disp-${Date.now()}-${created.length}-${Math.random().toString(36).slice(2, 5)}`,
            batchId,
            type: 'distribution',
            product: matchK.product,
            godownNo: matchK.godownNo,
            khamalNo: matchK.khamalNo,
            bags: Math.round(sp.bags),
            metricTons: Number(sp.weight.toFixed(4)),
            channel:
              input.type === 'Mill'
                ? 'মিলার বরাদ্দ (ছাঁটাই)'
                : 'ইনভয়েস / বদলি প্রেরণ',
            doNumber: input.docNo.trim(),
            dispatchType: input.type,
            docNo: input.docNo.trim(),
            party: input.party.trim(),
            referenceNo: input.docNo.trim(),
            date: txDate,
            note: [input.party.trim(), input.reference.trim()].filter(Boolean).join(' · '),
            createdAt: nowIso,
          });
        }

        setTransactions((prev) => [...created, ...prev]);
        return {
          ok: true,
          message:
            input.type === 'Mill'
              ? `${splits.length}টি খামাল থেকে মিলে ধান ক্রাশিং প্রেরণ সংরক্ষিত হয়েছে।`
              : `${splits.length}টি খামাল থেকে ইনভয়েস প্রেরণ সংরক্ষিত হয়েছে।`,
        };
      }

      const token = googleAccessTokenState || getGoogleAccessToken();
      const usingDirectSheets = Boolean(
        googleSheetsConfig.enabled && token && extractSpreadsheetId(googleSheetsConfig.mainSpreadsheetId)
      );

      if (usingDirectSheets) {
        const accepted = await requestSheetConfirm({
          title: `Google Sheet-এ ${input.type === 'Mill' ? 'মিল ক্রাশিং' : 'ইনভয়েস'} প্রেরণ নিশ্চিত করুন`,
          description: `${splits.length}টি খামাল থেকে প্রেরণ রেকর্ড আপনার Google Sheet-এ যুক্ত করা হবে।`,
          spreadsheetName: googleSheetsConfig.mainSpreadsheetName || 'Google Spreadsheet',
          targetSheets: ['Transactions'],
          details: [
            `নথি/ইনভয়েস নং: ${input.docNo || '-'}`,
            `প্রাপক/মিল: ${input.party || '-'}`,
            ...splits.slice(0, 5).map((s) => `খামাল ${s.khamalId}: ${s.weight.toFixed(3)} মে.টন (${s.bags} বস্তা)`),
          ],
        });
        if (!accepted) return { ok: false, error: 'ব্যবহারকারী বাতিল করেছেন।' };
      }

      setIsSubmittingGas(true);
      try {
        let lastMsg = '';
        for (const sp of splits) {
          const res = await dispatchRemoteWrite('addDispatch', {
            type: input.type,
            khamalId: sp.khamalId,
            docNo: input.docNo,
            party: input.party,
            bags: Math.round(sp.bags),
            weight: Number(sp.weight.toFixed(3)),
            issueDate: input.issueDate,
            reference: input.reference,
          });
          if (!res.ok) return { ok: false, error: res.error };
          lastMsg = res.message || lastMsg;
        }
        await syncExternalDos();
        return { ok: true, message: lastMsg || 'প্রেরণ সংরক্ষিত হয়েছে।' };
      } finally {
        setIsSubmittingGas(false);
      }
    },
    [
      gasBridgeStatus,
      khamalStocks,
      googleAccessTokenState,
      googleSheetsConfig,
      requestSheetConfirm,
      dispatchRemoteWrite,
      syncExternalDos,
    ]
  );

  const submitGasEmptyBagIssue = useCallback(
    async (input: {
      godown: string;
      bagType: string;
      bags: number;
      khamalNo: string;
      issueDate: string;
    }): Promise<{ ok: boolean; message?: string; error?: string }> => {
      if (gasBridgeStatus !== 'connected') {
        const prod: ProductCategory = input.bagType.includes('৩০') ? 'bosta_30' : 'bosta_50';
        const matchK = khamalStocks.find(
          (k) => k.product === prod && k.godownNo === input.godown.trim()
        );
        const khamalLabel = matchK?.khamalNo || input.khamalNo.trim() || input.bagType;
        const avail = getKhamalBalance(input.godown, khamalLabel, prod);
        if (matchK && input.bags > avail.bags) {
          return {
            ok: false,
            error: `${input.godown} / ${khamalLabel}-এ পর্যাপ্ত বস্তা নেই (বর্তমান: ${avail.bags}টি)।`,
          };
        }
        const nowIso = new Date().toISOString();
        setTransactions((prev) => [
          {
            id: `tx-bag-out-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
            batchId: `bag-out-${Date.now()}`,
            type: 'distribution',
            product: prod,
            godownNo: input.godown.trim(),
            khamalNo: khamalLabel,
            bags: Math.round(input.bags),
            metricTons: 0,
            channel: 'বিতরণের সাথে প্রেরণ',
            referenceNo: input.khamalNo.trim(),
            date: input.issueDate || todayIsoDate(),
            note: `${input.bagType} বিতরণ`,
            createdAt: nowIso,
          },
          ...prev,
        ]);
        return { ok: true, message: 'খালি বস্তা বিতরণ সংরক্ষিত হয়েছে।' };
      }

      return runGasWriteAction('addEmptyBagIssue', input, {
        title: 'Google Sheet-এ খালি বস্তা বিতরণ নিশ্চিত করুন',
        description: 'খালি বস্তা বিতরণের তথ্যটি আপনার Google Sheet-এ যুক্ত হবে।',
        spreadsheetName: googleSheetsConfig.mainSpreadsheetName || 'Google Spreadsheet',
        targetSheets: ['Bag_Transactions'],
        details: [
          `গুদাম: ${input.godown}`,
          `বস্তার ধরন: ${input.bagType}`,
          `বস্তা সংখ্যা: ${input.bags}`,
          `তারিখ: ${input.issueDate}`,
        ],
      });
    },
    [gasBridgeStatus, khamalStocks, getKhamalBalance, runGasWriteAction, googleSheetsConfig.mainSpreadsheetName]
  );

  const buildShortageCascadePlan = useCallback(
    (
      khamalKeyOrId: string,
      shortBags: number,
      shortWeight: number,
      preferredNextKeys?: string[]
    ): {
      sourceKey: string;
      sourceGodown: string;
      sourceKhamalNo: string;
      product: ProductCategory;
      currentStockBags: number;
      currentStockMt: number;
      requestedShortageBags: number;
      requestedShortageMt: number;
      overdrawBags: number;
      overdrawMt: number;
      shifts: Array<{
        kind: 'do' | 'dispatch' | 'local_dist';
        recordId: string;
        gasRowIdx?: number;
        gasId?: string;
        label: string;
        originalBags: number;
        originalMt: number;
        shiftBags: number;
        shiftMt: number;
        targetGodown: string;
        targetKhamalNo: string;
        date: string;
      }>;
      unallocatedMt: number;
      unallocatedBags: number;
      candidateNextKhamals: KhamalStockItem[];
    } | null => {
      const source =
        khamalStocks.find((k) => k.key === khamalKeyOrId) ||
        khamalStocks.find(
          (k) => k.khamalNo === khamalKeyOrId && !PRODUCT_MAP[k.product].isBagProduct
        ) ||
        khamalStocks.find((k) => k.khamalNo === khamalKeyOrId);

      if (!source) return null;

      const cleanBags = Math.max(0, Math.round(shortBags));
      const cleanMt = Math.max(0, Number(shortWeight.toFixed(4)));
      const overdrawMt = Math.max(0, Number((cleanMt - source.currentMt).toFixed(4)));
      const overdrawBags = Math.max(0, cleanBags - source.currentBags);

      const rawCandidates = khamalStocks.filter(
        (k) =>
          k.product === source.product &&
          k.key !== source.key &&
          (k.currentMt > 0.0001 || k.currentBags > 0)
      );

      const orderedCandidates: KhamalStockItem[] = [];
      if (preferredNextKeys && preferredNextKeys.length > 0) {
        for (const pk of preferredNextKeys) {
          const found = rawCandidates.find((c) => c.key === pk || c.khamalNo === pk);
          if (found && !orderedCandidates.some((o) => o.key === found.key)) {
            orderedCandidates.push(found);
          }
        }
      }
      for (const c of rawCandidates) {
        if (!orderedCandidates.some((o) => o.key === c.key)) {
          orderedCandidates.push(c);
        }
      }

      const shifts: Array<{
        kind: 'do' | 'dispatch' | 'local_dist';
        recordId: string;
        gasRowIdx?: number;
        gasId?: string;
        label: string;
        originalBags: number;
        originalMt: number;
        shiftBags: number;
        shiftMt: number;
        targetGodown: string;
        targetKhamalNo: string;
        date: string;
      }> = [];

      let remShiftMt = overdrawMt;
      let remShiftBags = overdrawBags;

      if (overdrawMt > 0.0001 || overdrawBags > 0) {
        const nextPools = orderedCandidates.map((c) => ({
          godownNo: c.godownNo,
          khamalNo: c.khamalNo,
          remMt: c.currentMt,
          remBags: c.currentBags,
        }));

        interface OutgoingRec {
          kind: 'do' | 'dispatch' | 'local_dist';
          recordId: string;
          gasRowIdx?: number;
          gasId?: string;
          label: string;
          bags: number;
          mt: number;
          date: string;
        }

        const outgoing: OutgoingRec[] = [];

        if (gasBridgeStatus === 'connected' && gasData) {
          (gasData.issueList || [])
            .filter((r) => String(r.khamalId) === source.khamalNo)
            .forEach((r) => {
              outgoing.push({
                kind: 'do',
                recordId: `gas-iss-${r.id}`,
                gasRowIdx: r.rowIdx,
                gasId: r.id,
                label: `ডিও ${r.doNo} (${r.khath})`,
                bags: Math.round(parseGasNumber(r.bags)),
                mt: parseGasNumber(r.weight),
                date: r.date || todayIsoDate(),
              });
            });

          (gasData.dispatchList || [])
            .filter((d) => String(d.khamalId) === source.khamalNo)
            .forEach((d) => {
              outgoing.push({
                kind: 'dispatch',
                recordId: `gas-disp-${d.id}`,
                gasRowIdx: d.rowIdx,
                gasId: d.id,
                label: `${d.type === 'Mill' ? 'মিল ক্রাশিং' : 'ইনভয়েস'} ${d.docNo} (${d.party})`,
                bags: Math.round(parseGasNumber(d.bags)),
                mt: parseGasNumber(d.weight),
                date: d.date || todayIsoDate(),
              });
            });
          outgoing.reverse();
        } else {
          transactions
            .filter(
              (tx) =>
                tx.type === 'distribution' &&
                tx.product === source.product &&
                tx.godownNo === source.godownNo &&
                tx.khamalNo === source.khamalNo
            )
            .forEach((tx) => {
              const label = tx.dispatchType
                ? `${tx.dispatchType === 'Mill' ? 'মিল ক্রাশিং' : 'ইনভয়েস'} ${tx.docNo || tx.doNumber || ''} (${tx.party || tx.channel})`
                : `ডিও ${tx.doNumber || '-'} (${tx.channel})`;
              outgoing.push({
                kind: 'local_dist',
                recordId: tx.id,
                label,
                bags: tx.bags,
                mt: tx.metricTons,
                date: tx.date,
              });
            });
        }

        for (const rec of outgoing) {
          if (remShiftMt <= 0.0001 && remShiftBags <= 0) break;
          let recRemMt = rec.mt;
          let recRemBags = rec.bags;

          for (const pool of nextPools) {
            if (remShiftMt <= 0.0001 && remShiftBags <= 0) break;
            if (recRemMt <= 0.0001 && recRemBags <= 0) break;
            if (pool.remMt <= 0.0001 && pool.remBags <= 0) continue;

            const takeMt =
              remShiftMt > 0.0001
                ? Number(Math.min(remShiftMt, recRemMt, pool.remMt).toFixed(4))
                : 0;
            const takeBags =
              remShiftBags > 0
                ? Math.min(remShiftBags, recRemBags, pool.remBags)
                : 0;

            if (takeMt <= 0.0001 && takeBags <= 0) continue;

            remShiftMt = Math.max(0, Number((remShiftMt - takeMt).toFixed(4)));
            remShiftBags = Math.max(0, remShiftBags - takeBags);
            recRemMt = Math.max(0, Number((recRemMt - takeMt).toFixed(4)));
            recRemBags = Math.max(0, recRemBags - takeBags);
            pool.remMt = Math.max(0, Number((pool.remMt - takeMt).toFixed(4)));
            pool.remBags = Math.max(0, pool.remBags - takeBags);

            shifts.push({
              kind: rec.kind,
              recordId: rec.recordId,
              gasRowIdx: rec.gasRowIdx,
              gasId: rec.gasId,
              label: rec.label,
              originalBags: rec.bags,
              originalMt: rec.mt,
              shiftBags: takeBags,
              shiftMt: takeMt,
              targetGodown: pool.godownNo,
              targetKhamalNo: pool.khamalNo,
              date: rec.date,
            });
          }
        }
      }

      return {
        sourceKey: source.key,
        sourceGodown: source.godownNo,
        sourceKhamalNo: source.khamalNo,
        product: source.product,
        currentStockBags: source.currentBags,
        currentStockMt: source.currentMt,
        requestedShortageBags: cleanBags,
        requestedShortageMt: cleanMt,
        overdrawBags,
        overdrawMt,
        shifts,
        unallocatedMt: remShiftMt,
        unallocatedBags: remShiftBags,
        candidateNextKhamals: rawCandidates,
      };
    },
    [khamalStocks, gasBridgeStatus, gasData, transactions]
  );

  const submitGasDiscrepancy = useCallback(
    async (input: {
      khamalKey?: string;
      khamalId: string;
      bags: number;
      weight: number;
      discDate: string;
      remarks: string;
      preferredNextKeys?: string[];
      autoCascade?: boolean;
    }): Promise<{ ok: boolean; message?: string; error?: string }> => {
      const lookupKey = input.khamalKey || input.khamalId;
      const plan = buildShortageCascadePlan(
        lookupKey,
        input.bags,
        input.weight,
        input.preferredNextKeys
      );

      if (!plan) {
        return { ok: false, error: `খামাল ${input.khamalId} পাওয়া যায়নি।` };
      }

      const needsCascade = plan.overdrawMt > 0.0001 || plan.overdrawBags > 0;
      if (needsCascade && input.autoCascade !== false) {
        if (plan.unallocatedMt > 0.0005 || plan.unallocatedBags > 0) {
          return {
            ok: false,
            error: `খামাল ${plan.sourceKhamalNo}-এ ঘাটতি (${plan.overdrawMt.toFixed(3)} মে.টন / ${plan.overdrawBags} বস্তা) অ্যাডজাস্ট করার জন্য পরবর্তী খামালে বা পূর্বের বিতরণে পর্যাপ্ত সমন্বয়যোগ্য পরিমাণ নেই।`,
          };
        }
      }

      if (gasBridgeStatus !== 'connected') {
        const nowIso = new Date().toISOString();
        const txDate = input.discDate || todayIsoDate();
        const batchId = `short-cascade-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`;

        setTransactions((prev) => {
          let next = [...prev];

          // Apply shifts to existing distributions/dispatches
          if (needsCascade && input.autoCascade !== false) {
            const addedForTargets: GrainTransaction[] = [];

            // Group reductions per source transaction recordId
            const redByTx = new Map<string, { bags: number; mt: number }>();
            for (const sh of plan.shifts) {
              const cur = redByTx.get(sh.recordId) || { bags: 0, mt: 0 };
              redByTx.set(sh.recordId, {
                bags: cur.bags + sh.shiftBags,
                mt: Number((cur.mt + sh.shiftMt).toFixed(4)),
              });

              const origTx = next.find((t) => t.id === sh.recordId);
              if (origTx) {
                addedForTargets.push({
                  ...origTx,
                  id: `tx-casc-${Date.now()}-${addedForTargets.length}-${Math.random().toString(36).slice(2, 5)}`,
                  batchId,
                  godownNo: sh.targetGodown,
                  khamalNo: sh.targetKhamalNo,
                  bags: sh.shiftBags,
                  metricTons: sh.shiftMt,
                  note: `${origTx.note ? origTx.note + ' · ' : ''}খামাল ${plan.sourceKhamalNo} ঘাটতি সমন্বয়`,
                  createdAt: nowIso,
                });
              }
            }

            next = next
              .map((tx) => {
                const red = redByTx.get(tx.id);
                if (!red) return tx;
                const newBags = Math.max(0, tx.bags - red.bags);
                const newMt = Math.max(0, Number((tx.metricTons - red.mt).toFixed(4)));
                if (newBags === 0 && newMt <= 0.0001) return null;
                return { ...tx, bags: newBags, metricTons: newMt };
              })
              .filter((t): t is GrainTransaction => t !== null);

            next = [...addedForTargets, ...next];
          }

          // Add the shortage transaction itself on source khamal
          const shortageTx: GrainTransaction = {
            id: `tx-short-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
            batchId,
            type: 'shortage',
            product: plan.product,
            godownNo: plan.sourceGodown,
            khamalNo: plan.sourceKhamalNo,
            bags: plan.requestedShortageBags,
            metricTons: plan.requestedShortageMt,
            channel: 'খামাল ঘাটতি (শর্টেজ)',
            referenceNo: '',
            date: txDate,
            note: input.remarks.trim() || 'খামাল ঘাটতি',
            createdAt: nowIso,
          };

          return [shortageTx, ...next];
        });

        // Also update distributedFrom lists on DOs when cascade happens
        if (needsCascade && input.autoCascade !== false && plan.shifts.length > 0) {
          const targetLabels = Array.from(
            new Set(plan.shifts.map((s) => `${s.targetGodown} / ${s.targetKhamalNo}`))
          );
          setDeliveryOrders((prev) =>
            prev.map((d) => {
              const touched = plan.shifts.some((s) => s.label.includes(d.doNumber));
              if (!touched) return d;
              return {
                ...d,
                distributedFrom: Array.from(
                  new Set([...(d.distributedFrom || []), ...targetLabels])
                ),
              };
            })
          );
        }

        const cascadeCount = plan.shifts.length;
        return {
          ok: true,
          message:
            cascadeCount > 0
              ? `ঘাটতি সংরক্ষিত ও ${cascadeCount}টি বিতরণ পরবর্তী খামালে অ্যাডজাস্ট হয়েছে।`
              : 'খামাল ঘাটতি সংরক্ষিত হয়েছে।',
        };
      }

      // Live Google Sheets / Apps Script mode: record discrepancy + update affected rows + add shifted rows on next khamal(s)
      const token = googleAccessTokenState || getGoogleAccessToken();
      const usingDirectSheets = Boolean(
        googleSheetsConfig.enabled && token && extractSpreadsheetId(googleSheetsConfig.mainSpreadsheetId)
      );
      if (usingDirectSheets) {
        const accepted = await requestSheetConfirm({
          title: 'Google Sheet-এ খামাল ঘাটতি (ও সমন্বয়) নিশ্চিত করুন',
          description:
            plan.shifts.length > 0
              ? `খামাল ${plan.sourceKhamalNo}-এ ঘাটতি রেকর্ড করে ${plan.shifts.length}টি পূর্বের বিতরণ পরবর্তী খামালে স্থানান্তর করা হবে।`
              : `খামাল ${plan.sourceKhamalNo}-এ ঘাটতি রেকর্ড সরাসরি Google Sheet-এ লেখা হবে।`,
          spreadsheetName: googleSheetsConfig.mainSpreadsheetName || 'Google Spreadsheet',
          targetSheets: ['Transactions'],
          isDestructive: plan.shifts.length > 0,
          details: [
            `খামাল: ${plan.sourceKhamalNo} · ঘাটতি: ${plan.requestedShortageMt.toFixed(3)} মে.টন (${plan.requestedShortageBags} বস্তা)`,
            ...plan.shifts
              .slice(0, 4)
              .map((sh) => `${sh.label} → খামাল ${sh.targetKhamalNo} (${sh.shiftMt.toFixed(3)} মে.টন)`),
          ],
        });
        if (!accepted) return { ok: false, error: 'ব্যবহারকারী বাতিল করেছেন।' };
      }

      setIsSubmittingGas(true);
      try {
        const discRes = await dispatchRemoteWrite('addDiscrepancy', {
          khamalId: plan.sourceKhamalNo,
          bags: plan.requestedShortageBags,
          weight: Number(plan.requestedShortageMt.toFixed(3)),
          discDate: input.discDate || todayIsoDate(),
          remarks: input.remarks.trim() || 'খামাল ঘাটতি',
        });
        if (!discRes.ok) return { ok: false, error: discRes.error };

        if (needsCascade && input.autoCascade !== false && plan.shifts.length > 0 && gasData) {
          // Aggregate reductions per GAS source row
          const redByGasId = new Map<string, { bags: number; mt: number }>();
          for (const sh of plan.shifts) {
            const cur = redByGasId.get(sh.recordId) || { bags: 0, mt: 0 };
            redByGasId.set(sh.recordId, {
              bags: cur.bags + sh.shiftBags,
              mt: Number((cur.mt + sh.shiftMt).toFixed(4)),
            });
          }

          // Update or delete reduced DO rows
          for (const r of gasData.issueList || []) {
            const key = `gas-iss-${r.id}`;
            const red = redByGasId.get(key);
            if (!red) continue;
            const newBags = Math.max(0, Math.round(parseGasNumber(r.bags)) - red.bags);
            const newWeight = Math.max(
              0,
              Number((parseGasNumber(r.weight) - red.mt).toFixed(3))
            );
            if (newBags === 0 && newWeight <= 0.0005) {
              await dispatchRemoteWrite('deleteRecord', {
                sheetName: 'Transactions',
                rowIdx: r.rowIdx,
                expectedId: r.id,
              });
            } else {
              await dispatchRemoteWrite('updateTransaction', {
                rowIdx: r.rowIdx,
                id: r.id,
                doNo: r.doNo,
                khath: r.khath,
                khamalId: r.khamalId,
                bags: newBags,
                weight: newWeight,
                issueDate: r.date || input.discDate || todayIsoDate(),
                reference: r.reference || '',
              });
            }
          }

          // Update or delete reduced Dispatch (Invoice/Mill) rows
          for (const d of gasData.dispatchList || []) {
            const key = `gas-disp-${d.id}`;
            const red = redByGasId.get(key);
            if (!red) continue;
            const newBags = Math.max(0, Math.round(parseGasNumber(d.bags)) - red.bags);
            const newWeight = Math.max(
              0,
              Number((parseGasNumber(d.weight) - red.mt).toFixed(3))
            );
            if (newBags === 0 && newWeight <= 0.0005) {
              await dispatchRemoteWrite('deleteRecord', {
                sheetName: 'Transactions',
                rowIdx: d.rowIdx,
                expectedId: d.id,
              });
            } else {
              await dispatchRemoteWrite('updateDispatch', {
                rowIdx: d.rowIdx,
                id: d.id,
                type: d.type,
                khamalId: d.khamalId,
                docNo: d.docNo,
                party: d.party,
                bags: newBags,
                weight: newWeight,
                issueDate: d.date || input.discDate || todayIsoDate(),
                reference: d.reference || '',
              });
            }
          }

          // Insert shifted deliveries onto target next khamal(s)
          for (const sh of plan.shifts) {
            if (sh.kind === 'do') {
              const orig = (gasData.issueList || []).find((r) => `gas-iss-${r.id}` === sh.recordId);
              if (orig) {
                await dispatchRemoteWrite('addTransactionsBatch', {
                  khamalId: sh.targetKhamalNo,
                  issueDate: orig.date || input.discDate || todayIsoDate(),
                  reference: `${orig.reference ? orig.reference + ' ' : ''}(খামাল ${plan.sourceKhamalNo} ঘাটতি সমন্বয়)`,
                  items: [
                    {
                      doNo: orig.doNo,
                      khath: orig.khath,
                      bags: sh.shiftBags,
                      weight: Number(sh.shiftMt.toFixed(3)),
                    },
                  ],
                });
              }
            } else if (sh.kind === 'dispatch') {
              const orig = (gasData.dispatchList || []).find(
                (d) => `gas-disp-${d.id}` === sh.recordId
              );
              if (orig) {
                await dispatchRemoteWrite('addDispatch', {
                  type: orig.type,
                  khamalId: sh.targetKhamalNo,
                  docNo: orig.docNo,
                  party: orig.party,
                  bags: sh.shiftBags,
                  weight: Number(sh.shiftMt.toFixed(3)),
                  issueDate: orig.date || input.discDate || todayIsoDate(),
                  reference: `${orig.reference ? orig.reference + ' ' : ''}(খামাল ${plan.sourceKhamalNo} ঘাটতি সমন্বয়)`,
                });
              }
            }
          }
        }

        await syncExternalDos();
        return {
          ok: true,
          message:
            plan.shifts.length > 0
              ? `ঘাটতি সংরক্ষিত ও ${plan.shifts.length}টি বিতরণ পরবর্তী খামালে অ্যাডজাস্ট হয়েছে।`
              : discRes.message || 'ঘাটতি সংরক্ষিত হয়েছে।',
        };
      } finally {
        setIsSubmittingGas(false);
      }
    },
    [
      buildShortageCascadePlan,
      gasBridgeStatus,
      gasData,
      googleAccessTokenState,
      googleSheetsConfig,
      requestSheetConfirm,
      dispatchRemoteWrite,
      syncExternalDos,
    ]
  );

  const deleteGasRecord = useCallback(
    async (sheetName: string, rowIdx: number, expectedId = '') => {
      return runGasWriteAction(
        'deleteRecord',
        { sheetName, rowIdx, expectedId },
        {
          title: 'Google Sheet থেকে রেকর্ড মুছে ফেলা নিশ্চিত করুন',
          description: `আপনার Google Sheet-এর "${sheetName}" ট্যাব থেকে সারি #${rowIdx} স্থায়ীভাবে মুছে ফেলা হবে।`,
          spreadsheetName: googleSheetsConfig.mainSpreadsheetName || 'Google Spreadsheet',
          targetSheets: [sheetName],
          details: [
            `সারি নম্বর (Row): ${rowIdx}`,
            ...(expectedId ? [`রেকর্ড আইডি: ${expectedId}`] : []),
          ],
          isDestructive: true,
          confirmLabel: 'হ্যাঁ, মুছে ফেলুন',
        }
      );
    },
    [runGasWriteAction, googleSheetsConfig.mainSpreadsheetName]
  );

  const saveGasInstitution = useCallback(
    async (input: { lsdName: string; upazila: string; district: string; officer: string }) => {
      return runGasWriteAction('saveInstitution', input, {
        title: 'Google Sheet-এ প্রতিষ্ঠানের তথ্য আপডেট করুন',
        description: 'নিচের প্রতিষ্ঠানের তথ্য আপনার Google Sheet-এর Settings ট্যাবে সংরক্ষিত হবে।',
        spreadsheetName: googleSheetsConfig.mainSpreadsheetName || 'Google Spreadsheet',
        targetSheets: ['Settings'],
        details: [
          `এলএসডি: ${input.lsdName}`,
          `উপজেলা/জেলা: ${input.upazila}, ${input.district}`,
          `কর্মকর্তা: ${input.officer}`,
        ],
      });
    },
    [runGasWriteAction, googleSheetsConfig.mainSpreadsheetName]
  );

  const saveGasCategories = useCallback(
    async (categoriesMap: Record<string, string[]>) => {
      return runGasWriteAction('saveCategories', categoriesMap, {
        title: 'Google Sheet-এ ক্যাটাগরি তালিকা আপডেট করুন',
        description: 'নতুন পণ্য ক্যাটাগরি তালিকা Settings ট্যাবে সংরক্ষিত হবে।',
        spreadsheetName: googleSheetsConfig.mainSpreadsheetName || 'Google Spreadsheet',
        targetSheets: ['Settings'],
        details: Object.entries(categoriesMap).map(
          ([k, v]) => `${k}: ${v.length}টি খাত`
        ),
      });
    },
    [runGasWriteAction, googleSheetsConfig.mainSpreadsheetName]
  );

  const addGasFiscalYear = useCallback(
    async (input: { name: string; start: string; end: string; makeActive: boolean }) => {
      return runGasWriteAction('addFiscalYear', input, {
        title: 'Google Sheet-এ নতুন অর্থবছর যুক্ত করুন',
        description: 'Settings ট্যাবে নতুন অর্থবছর যুক্ত হবে।',
        spreadsheetName: googleSheetsConfig.mainSpreadsheetName || 'Google Spreadsheet',
        targetSheets: ['Settings'],
        details: [`অর্থবছর: ${input.name}`, `সময়কাল: ${input.start} — ${input.end}`],
      });
    },
    [runGasWriteAction, googleSheetsConfig.mainSpreadsheetName]
  );

  const setActiveGasFiscalYear = useCallback(
    async (name: string) => {
      return runGasWriteAction(
        'setActiveFY',
        { name },
        {
          title: 'সক্রিয় অর্থবছর পরিবর্তন নিশ্চিত করুন',
          description: `Google Sheet-এ ডিফল্ট অর্থবছর "${name}" হিসেবে সেট করা হবে।`,
          spreadsheetName: googleSheetsConfig.mainSpreadsheetName || 'Google Spreadsheet',
          targetSheets: ['Settings'],
          details: [`নতুন সক্রিয় অর্থবছর: ${name}`],
        }
      );
    },
    [runGasWriteAction, googleSheetsConfig.mainSpreadsheetName]
  );

  const deleteGasFiscalYear = useCallback(
    async (name: string) => {
      if (selectedFY === name) setSelectedFY(null);
      return runGasWriteAction(
        'deleteFiscalYear',
        { name },
        {
          title: 'অর্থবছর তালিকা থেকে বাদ দিন',
          description: `অর্থবছর "${name}" তালিকা থেকে মুছে যাবে (মূল লেনদেন ডেটা অক্ষত থাকবে)।`,
          spreadsheetName: googleSheetsConfig.mainSpreadsheetName || 'Google Spreadsheet',
          targetSheets: ['Settings'],
          details: [`অর্থবছর: ${name}`],
          isDestructive: true,
          confirmLabel: 'হ্যাঁ, বাদ দিন',
        }
      );
    },
    [runGasWriteAction, selectedFY, googleSheetsConfig.mainSpreadsheetName]
  );

  return {
    transactions,
    deliveryOrders,
    pendingDos,
    distributedDos,
    externalSyncConfig,
    isSyncingDos,
    isSubmittingGas,
    gasData,
    gasBridgeStatus,
    gasBridgeMessage,
    selectedFY,
    changeFiscalYear,
    updateExternalSyncConfig,
    syncExternalDos,
    manualRefreshData,
    googleSheetsConfig,
    updateGoogleSheetsConfig,
    googleUser,
    hasGoogleToken: Boolean(googleAccessTokenState),
    isGoogleSigningIn,
    googleAuthError,
    availableSpreadsheets,
    isLoadingSpreadsheets,
    mainSheetTabs,
    dataSourceMode,
    handleGoogleSignIn,
    handleGoogleSignOut,
    refreshSpreadsheetsList,
    selectSpreadsheetsAndSync,
    pendingSheetConfirm,
    resolveSheetConfirm,
    submitGasReceiptBatch,
    executeDoDistributionAsync,
    submitGasDispatch,
    submitGasEmptyBagIssue,
    buildShortageCascadePlan,
    submitGasDiscrepancy,
    deleteGasRecord,
    saveGasInstitution,
    saveGasCategories,
    addGasFiscalYear,
    setActiveGasFiscalYear,
    deleteGasFiscalYear,
    channels,
    godownList,
    khamalStocks,
    productTotals,
    getKhamalBalance,
    addBatchTransactions,
    addDeliveryOrder,
    deleteDeliveryOrder,
    markDoAsDistributed,
    executeDoDistribution,
    deleteTransaction,
    addChannel,
    renameChannel,
    removeChannel,
    resetDefaultChannels,
    loadSampleData,
    clearAllData,
    exportBackupJson,
    importBackupJson,
    exportCsvReport,
    fortnightlySettings,
    updateFortnightlySettings,
    resetFortnightlySettings,
  };
}
